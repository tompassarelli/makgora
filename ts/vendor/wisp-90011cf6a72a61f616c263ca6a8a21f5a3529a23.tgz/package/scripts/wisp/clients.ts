import { Context, Effect, Layer } from "effect";
import type { Platform } from "../platform/services";
import * as desktop from "../warcraft/desktop";
import type { Frame } from "./frameProbe";
export { DesktopFailure, type Ink, type Region, type Word, type InputAction, waitFor } from "../warcraft/desktop";

export type Client = Pick<desktop.Client, "name" | "documents" | "menuReportPort">;

export const clientUnit = (name: string) => `wisp-client-${name}.service`;

export class Clients extends Context.Service<Clients, {

  readonly all: readonly [Client, ...Client[]];
  readonly preflight: (client: Client) => Effect.Effect<void, desktop.DesktopFailure>;
  readonly read: (client: Client, region?: desktop.Region, ink?: desktop.Ink) => Effect.Effect<string, desktop.DesktopFailure>;

  readonly capture: (client: Client) => Effect.Effect<Frame, desktop.DesktopFailure>;
  readonly words: (client: Client, ink?: desktop.Ink) => Effect.Effect<readonly desktop.Word[], desktop.DesktopFailure>;
  readonly click: (client: Client, x: number, y: number) => Effect.Effect<void, desktop.DesktopFailure>;
  readonly keys: (client: Client, ...names: string[]) => Effect.Effect<void, desktop.DesktopFailure>;
  readonly typeText: (client: Client, value: string) => Effect.Effect<void, desktop.DesktopFailure>;
  readonly batch: (client: Client, actions: readonly desktop.InputAction[]) => Effect.Effect<void, desktop.DesktopFailure>;
}>()("wisp/Clients") {
  static readonly layer = (path: string) => Layer.effect(Clients, connect(path));
}

export const waitForText = (client: Client, what: string, pattern: RegExp, region?: desktop.Region, ink: desktop.Ink = "light", seconds = 20) =>
  Effect.gen(function*() {
    const clients = yield* Clients;
    return yield* desktop.waitFor(client, what, seconds, clients.read(client, region, ink).pipe(Effect.map(desktop.textMatching(pattern))));
  });

const connect = (path: string) => Effect.gen(function*() {
  const platform = yield* Effect.context<Platform>();
  const [first, ...others] = yield* desktop.loadClients(path);
  if (first === undefined) return yield* new desktop.DesktopFailure({ operation: "decode clients file", client: path, cause: "no clients" });
  const sessions = new Map([first, ...others].map((session) => [session.name, session]));
  const session = (client: Client) => {
    const found = sessions.get(client.name);
    return found === undefined
      ? Effect.fail(new desktop.DesktopFailure({ operation: "find client", client: client.name, cause: "not in the clients file" }))
      : Effect.succeed(found);
  };
  const on = <A, E>(effect: Effect.Effect<A, E, Platform>) => effect.pipe(Effect.provideContext(platform));
  return Clients.of({
    all: [first, ...others],
    preflight: (client) => Effect.flatMap(session(client), (value) => on(desktop.preflight(value))),
    read: (client, region, ink = "light") => Effect.flatMap(session(client), (value) => on(desktop.read(value, region, ink))),
    capture: (client) => Effect.flatMap(session(client), (value) => on(desktop.capture(value))),
    words: (client, ink = "light") => Effect.flatMap(session(client), (value) => on(desktop.words(value, ink))),
    click: (client, x, y) => Effect.flatMap(session(client), (value) => on(desktop.click(value, x, y))),
    keys: (client, ...names) => Effect.flatMap(session(client), (value) => on(desktop.keys(value, ...names))),
    typeText: (client, value) => Effect.flatMap(session(client), (target) => on(desktop.typeText(target, value))),
    batch: (client, actions) => Effect.flatMap(session(client), (target) => on(desktop.batch(target, actions))),
  });
});
