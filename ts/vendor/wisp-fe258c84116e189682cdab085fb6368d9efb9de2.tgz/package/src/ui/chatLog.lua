local ____lualib = require("lualib_bundle")
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayReverse = ____lualib.__TS__ArrayReverse
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____intMath = require("src.sim.intMath")
____exports.createChatLog = function(capacity) return {lines = {}, capacity = capacity, clock = 0.0, revision = 0} end
local HEX = "0123456789abcdef"
local function hexByte(value)
    return __TS__StringCharAt(
        HEX,
        ____intMath.idiv(value, 16)
    ) .. __TS__StringCharAt(
        HEX,
        ____intMath.imod(value, 16)
    )
end
____exports.colourCode = function(rgb) return (("|cff" .. hexByte(____intMath.idiv(rgb, 65536))) .. hexByte(____intMath.imod(
    ____intMath.idiv(rgb, 256),
    256
))) .. hexByte(____intMath.imod(rgb, 256)) end
local function liftChannel(channel, percent)
    return channel + ____intMath.idiv((255 - channel) * percent, 100)
end
--- `rgb` moved `percent` of the way to white, so a saturated player colour reads on a dark backdrop.
____exports.lighten = function(rgb, percent) return liftChannel(
    ____intMath.idiv(rgb, 65536),
    percent
) * 65536 + liftChannel(
    ____intMath.imod(
        ____intMath.idiv(rgb, 256),
        256
    ),
    percent
) * 256 + liftChannel(
    ____intMath.imod(rgb, 256),
    percent
) end
--- Battle.net names carry a `#1234` tag that chat never shows.
function ____exports.chatName(name)
    local tag = (string.find(name, "#", nil, true) or 0) - 1
    return tag > 0 and __TS__StringSubstring(name, 0, tag) or name
end
function ____exports.addChatLine(log, rgb, name, text)
    local ____log_lines_0 = log.lines
    ____log_lines_0[#____log_lines_0 + 1] = {
        rgb = rgb,
        name = ____exports.chatName(name),
        text = text,
        born = log.clock
    }
    while #log.lines > log.capacity do
        table.remove(log.lines, 1)
    end
    log.revision = log.revision + 1
end
function ____exports.advanceChat(log, seconds)
    log.clock = __wispF32Add(log.clock, seconds)
end
____exports.chatAge = function(log, born) return __wispF32Subtract(log.clock, born) end
--- Warcraft's Friz Quadrata (`Fonts\FRIZQT__.TTF`), fitted to native captures at a 10-pixel font, where glyphs
-- render widest for their size, and rounded up: Warcraft wraps a row that overruns its frame and hides the rest.
____exports.FRIZ_QUADRATA_WIDTHS = {
    space = 0xb33333p-25,
    narrow = 0x51eb85p-24,
    short = 0xf5c28fp-25,
    lower = 0xb33333p-24,
    wideLower = 1.0,
    upper = 0x70a3d7p-23,
    wideUpper = 0x8f5c29p-23,
    other = 0xcccccdp-24
}
local NARROW_GLYPHS = "ijlI.,:;'!|`"
local SHORT_GLYPHS = "frt-()[]\""
function ____exports.glyphWidth(glyph, widths)
    if glyph == " " then
        return widths.space
    end
    if __TS__StringIncludes(NARROW_GLYPHS, glyph) then
        return widths.narrow
    end
    if __TS__StringIncludes(SHORT_GLYPHS, glyph) then
        return widths.short
    end
    if glyph == "m" or glyph == "w" then
        return widths.wideLower
    end
    if glyph == "M" or glyph == "W" then
        return widths.wideUpper
    end
    if glyph >= "a" and glyph <= "z" then
        return widths.lower
    end
    if glyph >= "A" and glyph <= "Z" then
        return widths.upper
    end
    return widths.other
end
--- The width of `text` in units of the font size.
function ____exports.textWidth(text, widths)
    local width = 0.0
    do
        local index = 0
        while index < #text do
            width = __wispF32Add(
                width,
                ____exports.glyphWidth(
                    __TS__StringCharAt(text, index),
                    widths
                )
            )
            index = index + 1
        end
    end
    return width
end
local function fittingLength(word, room, widths)
    local width = 0.0
    do
        local index = 0
        while index < #word do
            width = __wispF32Add(
                width,
                ____exports.glyphWidth(
                    __TS__StringCharAt(word, index),
                    widths
                )
            )
            if width > room then
                return math.max(1, index)
            end
            index = index + 1
        end
    end
    return #word
end
--- Splits `text` at spaces into pieces no wider than `first` for the first piece and `width` after it,
-- in units of the font size; a word wider than its row is cut.
function ____exports.wrapChat(text, first, width, widths)
    local pieces = {}
    local current = ""
    local used = 0.0
    for ____, word in ipairs(__TS__StringSplit(text, " ")) do
        do
            local rest = word
            local restWidth = ____exports.textWidth(rest, widths)
            local room = #pieces == 0 and first or width
            local joined = #current == 0 and restWidth or __wispF32Add(
                __wispF32Add(used, widths.space),
                restWidth
            )
            if joined <= room then
                current = #current == 0 and rest or (current .. " ") .. rest
                used = joined
                goto __continue28
            end
            if #current > 0 then
                pieces[#pieces + 1] = current
            end
            do
                local cutRoom = #pieces == 0 and first or width
                while restWidth > cutRoom do
                    local cut = fittingLength(rest, cutRoom, widths)
                    pieces[#pieces + 1] = __TS__StringSubstring(rest, 0, cut)
                    rest = __TS__StringSubstring(rest, cut)
                    restWidth = ____exports.textWidth(rest, widths)
                    cutRoom = width
                end
            end
            current = rest
            used = restWidth
        end
        ::__continue28::
    end
    if #current > 0 or #pieces == 0 then
        pieces[#pieces + 1] = current
    end
    return pieces
end
--- One row per wrapped piece: the first holds the coloured name, later ones start at the row's left edge.
function ____exports.chatRows(line, width, widths)
    local first = __wispF32Subtract(
        width,
        ____exports.textWidth(line.name .. ": ", widths)
    )
    local pieces = ____exports.wrapChat(line.text, first, width, widths)
    return __TS__ArrayMap(
        pieces,
        function(____, piece, index) return {
            text = index == 0 and ((____exports.colourCode(line.rgb) .. line.name) .. "|r: ") .. piece or piece,
            born = line.born
        } end
    )
end
--- The last `count` rows of the lines younger than `seconds`, oldest first; `seconds` below 0 keeps every line.
function ____exports.visibleChatRows(log, count, width, widths, seconds)
    local rows = {}
    do
        local index = #log.lines - 1
        while index >= 0 and #rows < count do
            do
                local line = log.lines[index + 1]
                if line == nil or seconds >= 0.0 and ____exports.chatAge(log, line.born) >= seconds then
                    goto __continue39
                end
                local lineRows = ____exports.chatRows(line, width, widths)
                do
                    local row = #lineRows - 1
                    while row >= 0 and #rows < count do
                        rows[#rows + 1] = lineRows[row + 1]
                        row = row - 1
                    end
                end
            end
            ::__continue39::
            index = index - 1
        end
    end
    return __TS__ArrayReverse(rows)
end
--- Full opacity until `fade` seconds before the line expires after `seconds`, then a straight ramp to 0.
function ____exports.chatOpacity(age, seconds, fade)
    if seconds < 0.0 then
        return 1.0
    end
    local left = __wispF32Subtract(seconds, age)
    if left >= fade then
        return 1.0
    end
    return left <= 0.0 and 0.0 or __wispF32Divide(left, fade)
end
return ____exports
