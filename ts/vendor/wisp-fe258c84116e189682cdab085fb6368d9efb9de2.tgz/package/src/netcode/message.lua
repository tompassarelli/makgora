local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____codec = require("src.netcode.codec")
local ____wire = require("src.netcode.wire")
____exports.MESSAGE_MAX_BYTES = 200
____exports.MESSAGE_MAX_FRAMES = 64
function ____exports.encodeMessage(codec, firstFrame, lastFrame, rowAt)
    local head = ____wire.varint(firstFrame)
    local scratch = codec.neutral()
    local previous = rowAt(firstFrame)
    local body = codec.write(
        previous,
        codec.neutral()
    )
    local skipped = 0
    local last = firstFrame
    local function fits(frames, extra)
        return #head + #____wire.varint(frames) + #body + extra <= ____exports.MESSAGE_MAX_BYTES
    end
    do
        local frame = firstFrame + 1
        while frame <= lastFrame and frame - firstFrame < ____exports.MESSAGE_MAX_FRAMES do
            local row = rowAt(frame)
            local frames = frame - firstFrame + 1
            if ____codec.holds(codec, row, previous, scratch) then
                if not fits(frames, 0) then
                    break
                end
                skipped = skipped + 1
            else
                local record = ____wire.varint(skipped) .. codec.write(row, previous)
                if not fits(frames, #record) then
                    break
                end
                body = body .. record
                skipped = 0
                previous = row
            end
            last = frame
            frame = frame + 1
        end
    end
    return {
        wire = (head .. ____wire.varint(last - firstFrame + 1)) .. body,
        lastFrame = last
    }
end
function ____exports.decodeMessage(codec, wire, rows)
    if #wire > ____exports.MESSAGE_MAX_BYTES or #rows < ____exports.MESSAGE_MAX_FRAMES then
        return nil
    end
    local reader = ____wire.wireReader(wire, 0)
    local firstFrame = ____wire.readVarint(reader, ____wire.WIRE_MAX_VALUE)
    local count = ____wire.readVarint(reader, ____exports.MESSAGE_MAX_FRAMES)
    if firstFrame == nil or count == nil or firstFrame < 1 or count < 1 or firstFrame > ____wire.WIRE_MAX_VALUE - (count - 1) then
        return nil
    end
    local scratch = codec.neutral()
    if not codec.read(
        reader,
        codec.neutral(),
        ____lookup.at(rows, 0)
    ) then
        return nil
    end
    local previous = ____lookup.at(rows, 0)
    local filled = 1
    while not ____wire.atEnd(reader) do
        local skipped = ____wire.readVarint(reader, ____exports.MESSAGE_MAX_FRAMES)
        if skipped == nil or filled + skipped >= count then
            return nil
        end
        do
            local index = 0
            while index < skipped do
                local ____codec_hold_3 = codec.hold
                local ____at_2 = ____lookup.at
                local ____rows_1 = rows
                local ____filled_0 = filled
                filled = ____filled_0 + 1
                ____codec_hold_3(
                    ____at_2(____rows_1, ____filled_0),
                    previous
                )
                index = index + 1
            end
        end
        local row = ____lookup.at(rows, filled)
        if not codec.read(reader, previous, row) or ____codec.holds(codec, row, previous, scratch) then
            return nil
        end
        filled = filled + 1
        previous = row
    end
    while filled < count do
        local ____codec_hold_7 = codec.hold
        local ____at_6 = ____lookup.at
        local ____rows_5 = rows
        local ____filled_4 = filled
        filled = ____filled_4 + 1
        ____codec_hold_7(
            ____at_6(____rows_5, ____filled_4),
            previous
        )
    end
    return {firstFrame = firstFrame, count = count}
end
return ____exports
