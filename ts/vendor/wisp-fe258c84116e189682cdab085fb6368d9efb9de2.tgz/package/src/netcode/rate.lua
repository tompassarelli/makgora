local ____exports = {}
____exports.FULL_SPEED_FPS = 60
____exports.SLOW_FPS = 55
____exports.SATURATED_BUSY_MS = 750
____exports.SUSTAIN_SECONDS = 2
____exports.machineRate = function() return {fps = -1, slow = false, slowSeconds = 0, fastSeconds = 0} end
____exports.secondFps = function(frames, seconds) return seconds <= 0 and ____exports.FULL_SPEED_FPS or math.min(
    ____exports.FULL_SPEED_FPS,
    math.floor(frames / seconds + 0x1p-1)
) end
____exports.saturatedSecond = function(fps, busyMs) return fps < ____exports.SLOW_FPS and busyMs >= ____exports.SATURATED_BUSY_MS end
function ____exports.noteMachineSecond(rate, fps, busyMs)
    rate.fps = fps
    if ____exports.saturatedSecond(fps, busyMs) then
        rate.fastSeconds = 0
        rate.slowSeconds = rate.slowSeconds + 1
        if rate.slowSeconds >= ____exports.SUSTAIN_SECONDS then
            rate.slow = true
        end
    else
        rate.slowSeconds = 0
        rate.fastSeconds = rate.fastSeconds + 1
        if rate.fastSeconds >= ____exports.SUSTAIN_SECONDS then
            rate.slow = false
        end
    end
end
return ____exports
