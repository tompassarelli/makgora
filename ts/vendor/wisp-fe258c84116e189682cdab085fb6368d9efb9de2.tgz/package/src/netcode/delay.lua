local ____exports = {}
local ____intMath = require("src.sim.intMath")
____exports.DEFAULT_DELAY = 2
____exports.ROLLBACK_BUDGET = 4
____exports.HIGH_DELAY_FRAMES = 8
____exports.TIME_SYNC_INTERVAL = 60
function ____exports.delayPolicy(window, ceiling, budget, floor)
    if budget == nil then
        budget = ____exports.ROLLBACK_BUDGET
    end
    if floor == nil then
        floor = ____exports.DEFAULT_DELAY
    end
    return {
        floor = floor,
        ceiling = math.max(floor, ceiling),
        window = window,
        budget = math.min(budget, window - 1)
    }
end
____exports.rttEstimate = function() return {samples = 0, smoothed8 = 0} end
function ____exports.resetRtt(estimate)
    estimate.samples = 0
    estimate.smoothed8 = 0
end
function ____exports.observeRtt(estimate, rttMs)
    local sample = math.max(
        0,
        math.min(
            10000,
            math.floor(rttMs)
        )
    )
    estimate.smoothed8 = estimate.samples == 0 and sample * 8 or estimate.smoothed8 + sample - estimate.smoothed8 // 8
    estimate.samples = math.min(estimate.samples + 1, 1000000)
end
____exports.smoothedRttMs = function(estimate) return estimate.smoothed8 // 8 end
____exports.oneWayFrames = function(rttMs) return math.max(0, (rttMs * 3 + 99) // 100) end
local function clampDelay(policy, delay)
    return math.min(
        policy.ceiling,
        math.max(policy.floor, delay)
    )
end
local function delayForRtt(policy, rttMs)
    return clampDelay(
        policy,
        ____exports.oneWayFrames(rttMs) - policy.budget
    )
end
function ____exports.autoDelay(policy, estimate)
    return estimate.samples == 0 and policy.floor or delayForRtt(
        policy,
        ____exports.smoothedRttMs(estimate)
    )
end
function ____exports.nextDelay(policy, estimate, current)
    local target = ____exports.autoDelay(policy, estimate)
    if target >= current then
        return target
    end
    local lowered = estimate.samples == 0 and target or delayForRtt(
        policy,
        ____exports.smoothedRttMs(estimate) + 34
    )
    return lowered < current and lowered or clampDelay(policy, current)
end
function ____exports.connectionPoor(policy, estimate, delay)
    return estimate.samples > 0 and ____exports.oneWayFrames(____exports.smoothedRttMs(estimate)) > policy.budget + delay
end
____exports.highDelay = function(delay) return delay >= ____exports.HIGH_DELAY_FRAMES end
function ____exports.agreedDelay(requests, fallback)
    if fallback == nil then
        fallback = ____exports.DEFAULT_DELAY
    end
    local agreed = -1
    for ____, request in ipairs(requests) do
        agreed = math.max(agreed, request)
    end
    return agreed < 0 and fallback or agreed
end
____exports.AUTO_DELAY = -1
____exports.chosenDelay = function(requests, manual) return manual == ____exports.AUTO_DELAY and ____exports.agreedDelay(requests) or manual end
function ____exports.stepManualDelay(policy, manual, auto, direction)
    local from = manual == ____exports.AUTO_DELAY and auto or manual
    return math.min(
        policy.ceiling,
        math.max(0, from + direction)
    )
end
function ____exports.timeSyncWait(localAdvantage, remoteAdvantage, framesSinceWait)
    return framesSinceWait >= ____exports.TIME_SYNC_INTERVAL and localAdvantage - remoteAdvantage >= 2
end
____exports.HELD_ERROR_CALLBACKS = 2
____exports.DEEP_ERROR_PERCENT = 50
____exports.CLEAN_DEEP_PERCENT = 5
____exports.ERROR_WINDOW_SECONDS = 5
____exports.ERROR_SECONDS = 3
____exports.CLEAN_SECONDS = 30
____exports.delayCorrection = function(policy) return {value = policy.floor, windowSeconds = 0, errorSeconds = 0, cleanSeconds = 0} end
____exports.erroredSecond = function(second) return second.held >= ____exports.HELD_ERROR_CALLBACKS or second.deep * 100 > second.arrivals * ____exports.DEEP_ERROR_PERCENT end
____exports.cleanSecond = function(second) return second.held == 0 and second.arrivals > 0 and second.deep * 100 <= second.arrivals * ____exports.CLEAN_DEEP_PERCENT end
function ____exports.correctDelay(policy, correction, delay, second)
    local errored = ____exports.erroredSecond(second)
    correction.windowSeconds = correction.windowSeconds + 1
    if errored then
        correction.errorSeconds = correction.errorSeconds + 1
    end
    if correction.windowSeconds >= ____exports.ERROR_WINDOW_SECONDS then
        if correction.errorSeconds >= ____exports.ERROR_SECONDS then
            correction.value = clampDelay(
                policy,
                math.max(correction.value, delay) + 1
            )
        end
        correction.windowSeconds = 0
        correction.errorSeconds = 0
    end
    correction.cleanSeconds = ____exports.cleanSecond(second) and correction.cleanSeconds + 1 or 0
    if correction.cleanSeconds < ____exports.CLEAN_SECONDS then
        return
    end
    correction.cleanSeconds = 0
    correction.value = clampDelay(
        policy,
        math.min(correction.value, delay) - 1
    )
end
____exports.correctedDelay = function(policy, correction, pingDelay) return clampDelay(
    policy,
    math.max(pingDelay, correction.value)
) end
return ____exports
