local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____intMath = require("src.sim.intMath")
local ____frameRing = require("src.netcode.frameRing")
local ____ledger = require("src.netcode.ledger")
local ____message = require("src.netcode.message")
local ____wire = require("src.netcode.wire")
____exports.NET_SETTINGS = {delay = 2, window = 24, sendEvery = 6, catchUp = 6}
local HISTORY = 128
local NO_ROLLBACK = ____wire.WIRE_MAX_VALUE + 1
local function rows(codec, count)
    local made = {}
    do
        local index = 0
        while index < count do
            made[#made + 1] = codec.neutral()
            index = index + 1
        end
    end
    return made
end
function ____exports.createSession(sim, settings, players, ____local, initial)
    local codec = sim.codec
    local used = {}
    do
        local player = 0
        while player < players do
            used[#used + 1] = ____frameRing.frameRing(codec, HISTORY)
            player = player + 1
        end
    end
    local states = {}
    local stateFrames = {}
    do
        local slot = 0
        while slot < HISTORY do
            states[#states + 1] = initial
            stateFrames[#stateFrames + 1] = slot == 0 and 0 or -1
            slot = slot + 1
        end
    end
    return {
        players = players,
        ["local"] = ____local >= 0 and ____local < players and ____local or -1,
        ledger = ____ledger.inputLedger(codec, players, settings.delay),
        pending = ____frameRing.frameRing(codec, HISTORY),
        used = used,
        states = states,
        stateFrames = stateFrames,
        rows = rows(codec, players),
        frameRows = rows(codec, players),
        inbox = rows(codec, ____message.MESSAGE_MAX_FRAMES),
        confirmed = initial,
        confirmedFrame = 0,
        present = 0,
        callbacks = 0,
        rollbackFrom = NO_ROLLBACK,
        sentThrough = settings.delay,
        credit = 2 * settings.sendEvery,
        sinceSend = 0,
        pressWaiting = false,
        lastHadPress = false,
        stats = {
            rollbacks = 0,
            deepest = 0,
            held = 0,
            messages = 0,
            largest = 0,
            refused = 0
        }
    }
end
function ____exports.predictedAt(session, frame)
    local slot = frame % HISTORY
    local ____temp_0
    if session.stateFrames[slot + 1] == frame then
        ____temp_0 = session.states[slot + 1]
    else
        ____temp_0 = nil
    end
    return ____temp_0
end
function ____exports.predictedState(session)
    return ____lookup.at(session.states, session.present % HISTORY)
end
function ____exports.remoteThrough(session)
    local through = NO_ROLLBACK
    do
        local player = 0
        while player < session.players do
            local accepted = ____lookup.at(session.ledger.through, player)
            if player ~= session["local"] and ____ledger.isPlaying(session.ledger, player) and accepted < through then
                through = accepted
            end
            player = player + 1
        end
    end
    return through
end
function ____exports.receive(session, sim, sender, wire)
    if sender < 0 or sender >= session.players then
        return "wrongSender"
    end
    local codec = sim.codec
    local decoded = ____message.decodeMessage(codec, wire, session.inbox)
    local receipt = decoded == nil and "malformed" or ____ledger.acceptRows(
        codec,
        session.ledger,
        sender,
        decoded.firstFrame,
        session.inbox,
        decoded.count,
        session.confirmedFrame
    )
    if decoded == nil or receipt ~= "accepted" then
        local ____session_stats_1, ____refused_2 = session.stats, "refused"
        ____session_stats_1[____refused_2] = ____session_stats_1[____refused_2] + 1
        return receipt
    end
    if sender == session["local"] then
        return receipt
    end
    local used = ____lookup.at(session.used, sender)
    do
        local index = 0
        while index < decoded.count do
            local frame = decoded.firstFrame + index
            if frame > session.present or frame >= session.rollbackFrom then
                break
            end
            local ran = ____frameRing.ringRow(used, frame)
            if ran == nil or not codec.same(
                ran,
                ____lookup.at(session.inbox, index)
            ) then
                session.rollbackFrom = frame
                break
            end
            index = index + 1
        end
    end
    return receipt
end
function ____exports.leave(session, sim, player)
    if player < 0 or player >= session.players then
        return
    end
    local used = ____lookup.at(session.used, player)
    do
        local frame = ____ledger.leaveLedger(session.ledger, player) + 1
        while frame <= session.present and frame < session.rollbackFrom do
            local ran = ____frameRing.ringRow(used, frame)
            if ran == nil or not sim.codec.same(ran, session.ledger.idle) then
                session.rollbackFrom = frame
            end
            frame = frame + 1
        end
    end
end
local function bestRow(session, codec, player, frame)
    local accepted = ____ledger.acceptedRow(session.ledger, player, frame)
    if accepted ~= nil then
        return accepted
    end
    local scratch = ____lookup.at(session.rows, player)
    if player == session["local"] then
        local pending = ____frameRing.ringRow(session.pending, frame)
        if pending == nil then
            do
                local ____thrown = __TS__New(
                    Error,
                    "no local row for frame " .. tostring(frame)
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/netcode/session.ts:144"
                end
                error(____thrown, 0)
            end
        end
        return pending
    end
    local last = ____ledger.acceptedRow(
        session.ledger,
        player,
        ____lookup.at(session.ledger.through, player)
    )
    if last == nil then
        do
            local ____thrown = __TS__New(
                Error,
                ((("player " .. tostring(player)) .. " has no row to predict frame ") .. tostring(frame)) .. " from"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/netcode/session.ts:148"
            end
            error(____thrown, 0)
        end
    end
    codec.hold(scratch, last)
    return scratch
end
local function runFrame(session, sim, frame)
    local codec = sim.codec
    local before = ____exports.predictedAt(session, frame - 1)
    if before == nil then
        do
            local ____thrown = __TS__New(
                Error,
                ("frame " .. tostring(frame)) .. " needs a snapshot older than the rollback history"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/netcode/session.ts:156"
            end
            error(____thrown, 0)
        end
    end
    do
        local player = 0
        while player < session.players do
            local ring = ____lookup.at(session.used, player)
            ____frameRing.ringStore(
                codec,
                ring,
                frame,
                bestRow(session, codec, player, frame)
            )
            session.frameRows[player + 1] = ____lookup.at(ring.rows, frame % HISTORY)
            player = player + 1
        end
    end
    local state = sim.step(before, session.frameRows)
    local slot = frame % HISTORY
    session.states[slot + 1] = state
    session.stateFrames[slot + 1] = frame
    sim.predicted(state)
end
local function rollBack(session, sim)
    local from = session.rollbackFrom
    session.rollbackFrom = NO_ROLLBACK
    if from > session.present then
        return
    end
    local depth = session.present - from + 1
    local ____session_stats_3, ____rollbacks_4 = session.stats, "rollbacks"
    ____session_stats_3[____rollbacks_4] = ____session_stats_3[____rollbacks_4] + 1
    if depth > session.stats.deepest then
        session.stats.deepest = depth
    end
    do
        local frame = from
        while frame <= session.present do
            runFrame(session, sim, frame)
            frame = frame + 1
        end
    end
end
local function predict(session, sim, settings, sample)
    local codec = sim.codec
    local remote = ____exports.remoteThrough(session)
    do
        local ran = 0
        while ran < settings.catchUp and session.present < session.callbacks do
            local frame = session.present + 1
            if frame - remote > settings.window then
                local ____session_stats_5, ____held_6 = session.stats, "held"
                ____session_stats_5[____held_6] = ____session_stats_5[____held_6] + 1
                return
            end
            if session["local"] >= 0 then
                ____frameRing.ringStore(codec, session.pending, frame + settings.delay, sample)
                if codec.urgent(sample) then
                    session.pressWaiting = true
                end
                codec.hold(sample, sample)
            end
            runFrame(session, sim, frame)
            session.present = frame
            ran = ran + 1
        end
    end
end
local function confirm(session, sim)
    local known = ____ledger.knownThrough(session.ledger)
    local inputs = session.rows
    while session.confirmedFrame < known do
        local frame = session.confirmedFrame + 1
        do
            local player = 0
            while player < session.players do
                local row = ____ledger.acceptedRow(session.ledger, player, frame)
                if row == nil then
                    do
                        local ____thrown = __TS__New(
                            Error,
                            (("player " .. tostring(player)) .. " has no accepted row for frame ") .. tostring(frame)
                        )
                        if _G.__wispThrown ~= ____thrown then
                            _G.__wispThrown = ____thrown
                            _G.__wispThrowSite = "wisp/src/netcode/session.ts:205"
                        end
                        error(____thrown, 0)
                    end
                end
                sim.codec.copy(
                    ____lookup.at(inputs, player),
                    row
                )
                player = player + 1
            end
        end
        session.confirmed = sim.step(session.confirmed, inputs)
        session.confirmedFrame = frame
        sim.confirmed(session.confirmed)
    end
end
local function send(session, sim, settings)
    if session["local"] < 0 then
        return nil
    end
    session.sinceSend = session.sinceSend + 1
    session.credit = math.min(session.credit + 1, 2 * settings.sendEvery)
    local captured = session.present + settings.delay
    if session.sentThrough >= captured then
        return nil
    end
    local due = session.sinceSend >= settings.sendEvery or session.pressWaiting
    local allowed = session.credit >= settings.sendEvery or session.pressWaiting and session.lastHadPress and session.credit >= 0
    if not due or not allowed then
        return nil
    end
    local pending = session.pending
    local message = ____message.encodeMessage(
        sim.codec,
        session.sentThrough + 1,
        captured,
        function(frame)
            local row = ____frameRing.ringRow(pending, frame)
            if row == nil then
                do
                    local ____thrown = __TS__New(
                        Error,
                        "no local row for frame " .. tostring(frame)
                    )
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/netcode/session.ts:226"
                    end
                    error(____thrown, 0)
                end
            end
            return row
        end
    )
    session.sentThrough = message.lastFrame
    session.credit = session.credit - settings.sendEvery
    session.sinceSend = 0
    session.lastHadPress = session.pressWaiting
    session.pressWaiting = false
    local ____session_stats_7, ____messages_8 = session.stats, "messages"
    ____session_stats_7[____messages_8] = ____session_stats_7[____messages_8] + 1
    if #message.wire > session.stats.largest then
        session.stats.largest = #message.wire
    end
    return message.wire
end
function ____exports.tick(session, sim, settings, sample)
    session.callbacks = session.callbacks + 1
    rollBack(session, sim)
    predict(session, sim, settings, sample)
    confirm(session, sim)
    return send(session, sim, settings)
end
return ____exports
