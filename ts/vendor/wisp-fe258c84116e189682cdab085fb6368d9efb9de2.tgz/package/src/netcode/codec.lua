local ____exports = {}
function ____exports.holds(codec, row, previous, scratch)
    codec.hold(scratch, previous)
    return codec.same(row, scratch)
end
return ____exports
