local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____frameRing = require("src.netcode.frameRing")
____exports.FUTURE_LIMIT = 128
____exports.LEDGER_CAPACITY = 2 * ____exports.FUTURE_LIMIT
____exports.STILL_PLAYING = 2147483647
function ____exports.inputLedger(codec, players, seeded)
    local rings = {}
    local through = {}
    local goneAfter = {}
    local neutral = codec.neutral()
    do
        local player = 0
        while player < players do
            local ring = ____frameRing.frameRing(codec, ____exports.LEDGER_CAPACITY)
            do
                local frame = 1
                while frame <= seeded do
                    ____frameRing.ringStore(codec, ring, frame, neutral)
                    frame = frame + 1
                end
            end
            rings[#rings + 1] = ring
            through[#through + 1] = seeded
            goneAfter[#goneAfter + 1] = ____exports.STILL_PLAYING
            player = player + 1
        end
    end
    return {rings = rings, through = through, goneAfter = goneAfter, idle = neutral}
end
function ____exports.isPlaying(ledger, player)
    return ____lookup.at(ledger.goneAfter, player) == ____exports.STILL_PLAYING
end
function ____exports.knownThrough(ledger)
    local known = ____exports.STILL_PLAYING
    local latest = 0
    do
        local player = 0
        while player < #ledger.through do
            local through = ____lookup.at(ledger.through, player)
            if through > latest then
                latest = through
            end
            if ____exports.isPlaying(ledger, player) and through < known then
                known = through
            end
            player = player + 1
        end
    end
    return known == ____exports.STILL_PLAYING and latest or known
end
function ____exports.acceptedRow(ledger, player, frame)
    return frame > ____lookup.at(ledger.goneAfter, player) and ledger.idle or ____frameRing.ringRow(
        ____lookup.at(ledger.rings, player),
        frame
    )
end
function ____exports.leaveLedger(ledger, player)
    if ____exports.isPlaying(ledger, player) then
        ledger.goneAfter[player + 1] = ____lookup.at(ledger.through, player)
    end
    return ____lookup.at(ledger.goneAfter, player)
end
function ____exports.acceptRows(codec, ledger, sender, firstFrame, rows, count, confirmed)
    local ring = ledger.rings[sender + 1]
    if ring == nil then
        return "wrongSender"
    end
    if not ____exports.isPlaying(ledger, sender) then
        return "gone"
    end
    do
        local index = 0
        while index < count do
            local frame = firstFrame + index
            if frame > confirmed + ____exports.FUTURE_LIMIT then
                return "tooFarAhead"
            end
            if frame <= confirmed + ____exports.FUTURE_LIMIT - ____exports.LEDGER_CAPACITY then
                return "outOfHistory"
            end
            local stored = ____frameRing.ringRow(ring, frame)
            if stored ~= nil and not codec.same(
                stored,
                ____lookup.at(rows, index)
            ) then
                return "conflict"
            end
            index = index + 1
        end
    end
    do
        local index = 0
        while index < count do
            ____frameRing.ringStore(
                codec,
                ring,
                firstFrame + index,
                ____lookup.at(rows, index)
            )
            index = index + 1
        end
    end
    local through = ____lookup.at(ledger.through, sender)
    while ____frameRing.ringRow(ring, through + 1) ~= nil do
        through = through + 1
    end
    ledger.through[sender + 1] = through
    return "accepted"
end
return ____exports
