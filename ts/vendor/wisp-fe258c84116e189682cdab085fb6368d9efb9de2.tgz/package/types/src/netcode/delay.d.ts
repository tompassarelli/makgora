/** @noSelfInFile */
export declare const DEFAULT_DELAY = 2;
export declare const ROLLBACK_BUDGET = 4;
export declare const HIGH_DELAY_FRAMES = 8;
export declare const TIME_SYNC_INTERVAL = 60;
export interface DelayPolicy {
    readonly floor: number;
    readonly ceiling: number;
    readonly window: number;
    readonly budget: number;
}
export declare function delayPolicy(window: number, ceiling: number, budget?: number, floor?: number): DelayPolicy;
export interface RttEstimate {
    samples: number;
    smoothed8: number;
}
export declare const rttEstimate: () => RttEstimate;
export declare function resetRtt(estimate: RttEstimate): void;
export declare function observeRtt(estimate: RttEstimate, rttMs: number): void;
export declare const smoothedRttMs: (estimate: Readonly<RttEstimate>) => number;
export declare const oneWayFrames: (rttMs: number) => number;
export declare function autoDelay(policy: DelayPolicy, estimate: Readonly<RttEstimate>): number;
export declare function nextDelay(policy: DelayPolicy, estimate: Readonly<RttEstimate>, current: number): number;
export declare function connectionPoor(policy: DelayPolicy, estimate: Readonly<RttEstimate>, delay: number): boolean;
export declare const highDelay: (delay: number) => boolean;
export declare function agreedDelay(requests: readonly number[], fallback?: number): number;
export declare const AUTO_DELAY = -1;
export declare const chosenDelay: (requests: readonly number[], manual: number) => number;
export declare function stepManualDelay(policy: DelayPolicy, manual: number, auto: number, direction: -1 | 1): number;
export declare function timeSyncWait(localAdvantage: number, remoteAdvantage: number, framesSinceWait: number): boolean;
export declare const HELD_ERROR_CALLBACKS = 2;
export declare const DEEP_ERROR_PERCENT = 50;
export declare const CLEAN_DEEP_PERCENT = 5;
export declare const ERROR_WINDOW_SECONDS = 5;
export declare const ERROR_SECONDS = 3;
export declare const CLEAN_SECONDS = 30;
export interface DelayCorrection {
    value: number;
    windowSeconds: number;
    errorSeconds: number;
    cleanSeconds: number;
}
export interface MatchSecond {
    readonly held: number;
    readonly arrivals: number;
    readonly deep: number;
}
export declare const delayCorrection: (policy: DelayPolicy) => DelayCorrection;
export declare const erroredSecond: (second: MatchSecond) => boolean;
export declare const cleanSecond: (second: MatchSecond) => boolean;
export declare function correctDelay(policy: DelayPolicy, correction: DelayCorrection, delay: number, second: MatchSecond): void;
export declare const correctedDelay: (policy: DelayPolicy, correction: Readonly<DelayCorrection>, pingDelay: number) => number;
