local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__StringReplace = ____lualib.__TS__StringReplace
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local ____exports = {}
local ____frameStore = require("src.game.native.frameStore")
____exports.isFrame = function(value) return type(value) == "table" and value ~= nil and value.points ~= nil end
local function argb(color)
    return color < 0 and color + 4294967296 or color
end
local function pointName(value)
    local ____temp_2
    if type(value) == "number" then
        local ____opt_0 = ____frameStore.FRAME_POINTS[value + 1]
        ____temp_2 = ____opt_0 and ____opt_0[1] or ""
    else
        ____temp_2 = type(value) == "string" and value or ""
    end
    return ____temp_2
end
--- The frame calls of one running game on top of its frame tree: what the native backend and the emulated Warcraft natives both run.
____exports.FrameUi = __TS__Class()
local FrameUi = ____exports.FrameUi
FrameUi.name = "FrameUi"
function FrameUi.prototype.____constructor(self, tree, handle, gameUiOrigin, screen)
    self.tree = tree
    self.handle = handle
    self.gameUiOrigin = gameUiOrigin
    self.screen = screen
    self.memo = __TS__New(Map)
end
function FrameUi.prototype.memoized(self, key, name)
    if name == nil then
        name = ""
    end
    local known = self.memo:get(key)
    if known ~= nil then
        return known
    end
    local created = self.tree():add(
        self.handle("framehandle"),
        "",
        name,
        nil,
        0
    )
    self.memo:set(key, created)
    return created
end
function FrameUi.prototype.made(self, ____type, name, owner, context)
    return self.tree():add(
        self.handle("framehandle"),
        ____type,
        name,
        ____exports.isFrame(owner) and owner or nil,
        context
    )
end
function FrameUi.prototype.originFrame(self, ____type, index)
    local frame = self:memoized((("origin " .. tostring(____type)) .. " ") .. tostring(index))
    if ____type == self.gameUiOrigin() then
        self.tree().gameUi:add(frame)
    end
    return frame
end
function FrameUi.prototype.named(self, name, context)
    return self.tree():named(name, context) or self:memoized(
        (("name " .. name) .. " ") .. tostring(context),
        name
    )
end
function FrameUi.prototype.childCount(self, frame)
    return ____exports.isFrame(frame) and #self.tree():children(frame) or 0
end
function FrameUi.prototype.child(self, frame, index)
    local ____isFrame_result_3
    if ____exports.isFrame(frame) then
        ____isFrame_result_3 = self.tree():children(frame)[index + 1]
    else
        ____isFrame_result_3 = nil
    end
    return ____isFrame_result_3 or self:memoized((("child " .. tostring(frame.id)) .. " ") .. tostring(index))
end
function FrameUi.prototype.create(self, template, owner, context)
    return self.tree():create(
        function() return self.handle("framehandle") end,
        template,
        ____exports.isFrame(owner) and owner or nil,
        context
    )
end
function FrameUi.prototype.createSimple(self, template, owner, context)
    return self:made(template, template, owner, context)
end
function FrameUi.prototype.createByType(self, ____type, name, owner, inherits, context)
    local frame = self:made(____type, name, owner, context)
    frame.plain = inherits == ""
    return frame
end
function FrameUi.prototype.destroy(self, frame)
    if ____exports.isFrame(frame) then
        self.tree():destroy(frame)
    end
end
function FrameUi.prototype.name(self, frame)
    return ____exports.isFrame(frame) and frame.name or ""
end
function FrameUi.prototype.parent(self, frame)
    local ____isFrame_result_4
    if ____exports.isFrame(frame) then
        ____isFrame_result_4 = frame.parent
    else
        ____isFrame_result_4 = nil
    end
    return ____isFrame_result_4
end
function FrameUi.prototype.setText(self, frame, text)
    if ____exports.isFrame(frame) then
        frame.text = frame.textLimit >= 0 and __TS__StringSlice(text, 0, frame.textLimit) or text
    end
end
function FrameUi.prototype.text(self, frame)
    return ____exports.isFrame(frame) and frame.text or ""
end
function FrameUi.prototype.setTexture(self, frame, texture)
    if ____exports.isFrame(frame) then
        frame.texture = texture
    end
end
function FrameUi.prototype.setModel(self, frame, model, camera)
    if ____exports.isFrame(frame) then
        frame.model = model
        frame.modelCamera = camera
    end
end
function FrameUi.prototype.setSpriteAnimation(self, frame, animation)
    if ____exports.isFrame(frame) then
        frame.spriteAnimation = animation
    end
end
function FrameUi.prototype.setSpriteTime(self, frame, seconds)
    if ____exports.isFrame(frame) then
        frame.spriteTime = seconds
    end
end
function FrameUi.prototype.setVertexColor(self, frame, color)
    if ____exports.isFrame(frame) then
        frame.color = argb(color)
    end
end
function FrameUi.prototype.setTextColor(self, frame, color)
    if ____exports.isFrame(frame) then
        frame.textColor = argb(color)
    end
end
function FrameUi.prototype.setAlpha(self, frame, alpha)
    if ____exports.isFrame(frame) then
        frame.alpha = alpha
    end
end
function FrameUi.prototype.alpha(self, frame)
    return ____exports.isFrame(frame) and frame.alpha or 0
end
function FrameUi.prototype.setTextLimit(self, frame, size)
    if ____exports.isFrame(frame) then
        frame.textLimit = size
    end
end
function FrameUi.prototype.textLimit(self, frame)
    return ____exports.isFrame(frame) and frame.textLimit or 0
end
function FrameUi.prototype.setFont(self, frame, file, height, flags)
    if ____exports.isFrame(frame) then
        frame.font = {file = file, height = height, flags = flags}
    end
end
function FrameUi.prototype.setTextAlignment(self, frame, vertical, horizontal)
    if ____exports.isFrame(frame) then
        frame.alignment = {vertical = vertical, horizontal = horizontal}
    end
end
function FrameUi.prototype.setScale(self, frame, scale)
    if ____exports.isFrame(frame) then
        frame.scale = scale
    end
end
function FrameUi.prototype.setVisible(self, frame, visible)
    if ____exports.isFrame(frame) then
        frame.visible = visible
    end
end
function FrameUi.prototype.visible(self, frame)
    local ____isFrame_result_5
    if ____exports.isFrame(frame) then
        ____isFrame_result_5 = self.tree():shown(frame)
    else
        ____isFrame_result_5 = false
    end
    return ____isFrame_result_5
end
function FrameUi.prototype.setEnabled(self, frame, enabled)
    if ____exports.isFrame(frame) then
        frame.enabled = enabled
    end
end
function FrameUi.prototype.enabled(self, frame)
    local ____isFrame_result_6
    if ____exports.isFrame(frame) then
        ____isFrame_result_6 = frame.enabled
    else
        ____isFrame_result_6 = false
    end
    return ____isFrame_result_6
end
function FrameUi.prototype.setFocus(self, frame, focused)
    if ____exports.isFrame(frame) then
        self.tree():focus(frame, focused)
    end
end
function FrameUi.prototype.setLevel(self, frame, level)
    if ____exports.isFrame(frame) then
        frame.level = level
    end
end
function FrameUi.prototype.setSize(self, frame, width, height)
    if ____exports.isFrame(frame) then
        frame.width = width
        frame.height = height
    end
end
function FrameUi.prototype.setAbsPoint(self, frame, point, x, y)
    if ____exports.isFrame(frame) then
        frame.points:set(point, {x = x, y = y})
    end
end
function FrameUi.prototype.clearPoints(self, frame)
    if ____exports.isFrame(frame) then
        frame.points:clear()
        __TS__ArraySetLength(frame.anchors, 0)
    end
end
function FrameUi.prototype.setPoint(self, frame, point, relative, relativePoint, x, y)
    if not ____exports.isFrame(frame) or not ____exports.isFrame(relative) then
        return
    end
    local ownPoint = __TS__StringReplace(
        pointName(point),
        "FRAMEPOINT_",
        ""
    )
    do
        local index = #frame.anchors - 1
        while index >= 0 do
            local ____opt_7 = frame.anchors[index + 1]
            if (____opt_7 and ____opt_7.point) == ownPoint then
                __TS__ArraySplice(frame.anchors, index, 1)
            end
            index = index - 1
        end
    end
    local ____frame_anchors_9 = frame.anchors
    ____frame_anchors_9[#____frame_anchors_9 + 1] = {
        point = ownPoint,
        relative = relative,
        relativePoint = __TS__StringReplace(
            pointName(relativePoint),
            "FRAMEPOINT_",
            ""
        ),
        x = x,
        y = y
    }
end
function FrameUi.prototype.setAllPoints(self, frame, relative)
    if not ____exports.isFrame(frame) or not ____exports.isFrame(relative) then
        return false
    end
    frame.points:clear()
    __TS__ArraySetLength(frame.anchors, 0)
    for ____, point in ipairs({"TOPLEFT", "BOTTOMRIGHT"}) do
        local ____frame_anchors_10 = frame.anchors
        ____frame_anchors_10[#____frame_anchors_10 + 1] = {
            point = point,
            relative = relative,
            relativePoint = point,
            x = 0,
            y = 0
        }
    end
    return true
end
return ____exports
