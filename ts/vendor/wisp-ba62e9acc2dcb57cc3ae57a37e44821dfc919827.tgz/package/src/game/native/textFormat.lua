local ____lualib = require("lualib_bundle")
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__NumberToFixed = ____lualib.__TS__NumberToFixed
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__Number = ____lualib.__TS__Number
local ____exports = {}
local ____binary32 = require("src.sim.binary32")
local ____f32 = require("src.sim.f32")
local function isDigits(text)
    local start = __TS__StringStartsWith(text, "-") and 1 or 0
    if #text <= start then
        return false
    end
    do
        local index = start
        while index < #text do
            local code = __TS__StringCharCodeAt(text, index)
            if code < 48 or code > 57 then
                return false
            end
            index = index + 1
        end
    end
    return true
end
function ____exports.describeNumber(value)
    if value ~= value then
        return "nan"
    end
    if value == math.huge then
        return "inf"
    end
    if value == -math.huge then
        return "-inf"
    end
    if value == 0 then
        return "0"
    end
    local text = tostring(value)
    if isDigits(text) then
        return text
    end
    local mantissa = value
    local exponent = 0
    while mantissa ~= math.floor(mantissa) and exponent < 1100 do
        mantissa = mantissa * 2
        exponent = exponent + 1
    end
    return exponent == 0 and __TS__NumberToFixed(mantissa, 0) or (__TS__NumberToFixed(mantissa, 0) .. "p-") .. tostring(exponent)
end
local function leadingNumber(text, fraction)
    local start = 0
    while not fraction and start < #text and __TS__StringCharAt(text, start) == " " do
        start = start + 1
    end
    local ____end = start
    if ____end < #text and (__TS__StringCharAt(text, ____end) == "-" or __TS__StringCharAt(text, ____end) == "+") then
        ____end = ____end + 1
    end
    local digits = 0
    local point = false
    while ____end < #text do
        local character = __TS__StringCharAt(text, ____end)
        if character >= "0" and character <= "9" then
            digits = digits + 1
        elseif fraction and character == "." and not point then
            point = true
        else
            break
        end
        ____end = ____end + 1
    end
    if digits == 0 then
        return 0
    end
    local value = __TS__Number(__TS__StringSlice(text, start, ____end))
    return value == value and value or 0
end
function ____exports.fixed(value, digits)
    local real = ____binary32.roundToFloat32(value)
    if real ~= real or real == math.huge or real == -math.huge or real >= 1.0000000200408773e+21 or real <= -1.0000000200408773e+21 then
        return __TS__NumberToFixed(real, digits)
    end
    local expanded = __TS__NumberToFixed(real < 0 and -real or real, digits + 30)
    local point = (string.find(expanded, ".", nil, true) or 0) - 1
    local kept = __TS__StringSlice(expanded, 0, point) .. __TS__StringSlice(expanded, point + 1, point + 1 + digits)
    local rest = __TS__StringSlice(expanded, point + 1 + digits)
    local digitsText = kept
    if string.sub(rest, 1, 1) >= "5" then
        local carry = #digitsText - 1
        while carry >= 0 and __TS__StringCharAt(digitsText, carry) == "9" do
            carry = carry - 1
        end
        digitsText = carry < 0 and "1" .. string.rep(
            "0",
            math.floor(#digitsText)
        ) or (__TS__StringSlice(digitsText, 0, carry) .. string.char(__TS__StringCharCodeAt(digitsText, carry) + 1)) .. string.rep(
            "0",
            math.floor(#digitsText - carry - 1)
        )
    end
    local whole = __TS__StringSlice(digitsText, 0, #digitsText - digits)
    local text = digits > 0 and (whole .. ".") .. __TS__StringSlice(digitsText, #digitsText - digits) or whole
    return real < 0 and "-" .. text or text
end
function ____exports.fixedWidth(value, width, precision)
    local text = ____exports.fixed(value, precision > 0 and precision or 0)
    if precision <= 0 then
        text = text .. ".0"
    end
    while #text < width + 1 do
        text = " " .. text
    end
    return text
end
____exports.truncated = function(value) return value < 0 and math.ceil(value) or math.floor(value) end
____exports.parsedInteger = function(text) return ____exports.truncated(leadingNumber(text, false)) end
____exports.parsedReal = function(text) return leadingNumber(text, true) end
return ____exports
