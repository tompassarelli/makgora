local ____lualib = require("lualib_bundle")
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringCharCodeAt = ____lualib.__TS__StringCharCodeAt
local __TS__NumberToFixed = ____lualib.__TS__NumberToFixed
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__Number = ____lualib.__TS__Number
local Map = ____lualib.Map
local __TS__Class = ____lualib.__TS__Class
local Set = ____lualib.Set
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__StringTrim = ____lualib.__TS__StringTrim
local __TS__ObjectKeys = ____lualib.__TS__ObjectKeys
local WeakMap = ____lualib.WeakMap
local __TS__StringEndsWith = ____lualib.__TS__StringEndsWith
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__StringReplace = ____lualib.__TS__StringReplace
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__Spread = ____lualib.__TS__Spread
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local ____exports = {}
local isDigits, mixText, mixName, mixValue, isHandle, mix, nameHashes, INT32_LIMIT
local ____gameFiles = require("src.runtime.gameFiles")
local ____binary32 = require("src.sim.binary32")
local ____f32 = require("src.sim.f32")
local ____animation = require("src.headless.animation")
local ____frames = require("src.headless.frames")
local ____warcraft3Abilities = require("src.headless.warcraft3Abilities")
local ____warcraft3Natives = require("src.headless.warcraft3Natives")
local ____warcraft3Scenery = require("src.headless.warcraft3Scenery")
local ____textTags = require("src.headless.textTags")
local ____lightnings = require("src.headless.lightnings")
local ____warcraft3Inventory = require("src.headless.warcraft3Inventory")
local ____frameRate = require("src.headless.frameRate")
function isDigits(text)
    local start = __TS__StringStartsWith(text, "-") and 1 or 0
    if #text <= start then
        return false
    end
    do
        local index = start
        while index < #text do
            local code = __TS__StringCharCodeAt(text, index)
            if code < 48 or code > 57 then
                return false
            end
            index = index + 1
        end
    end
    return true
end
function ____exports.describeNumber(value)
    if value ~= value then
        return "nan"
    end
    if value == math.huge then
        return "inf"
    end
    if value == -math.huge then
        return "-inf"
    end
    if value == 0 then
        return "0"
    end
    local text = tostring(value)
    if isDigits(text) then
        return text
    end
    local mantissa = value
    local exponent = 0
    while mantissa ~= math.floor(mantissa) and exponent < 1100 do
        mantissa = mantissa * 2
        exponent = exponent + 1
    end
    return exponent == 0 and __TS__NumberToFixed(mantissa, 0) or (__TS__NumberToFixed(mantissa, 0) .. "p-") .. tostring(exponent)
end
function mixText(hash, text)
    local mixed = hash
    do
        local index = 0
        while index < #text do
            mixed = mix(
                mixed,
                __TS__StringCharCodeAt(text, index)
            )
            index = index + 1
        end
    end
    return mix(mixed, #text)
end
function mixName(hash, name)
    local named = nameHashes:get(name)
    if named == nil then
        named = mixText(0, name)
        nameHashes:set(name, named)
    end
    return mix(hash, named)
end
function mixValue(hash, value)
    if type(value) == "number" then
        if value == math.floor(value) and value >= -INT32_LIMIT and value < INT32_LIMIT then
            return mix(
                mix(hash, 1),
                math.floor(value)
            )
        end
        return mixText(
            mix(hash, 2),
            ____exports.describeNumber(value)
        )
    end
    if type(value) == "string" then
        return mixText(
            mix(hash, 3),
            value
        )
    end
    if type(value) == "boolean" then
        return mix(hash, value and 4 or 5)
    end
    if type(value) == "function" then
        return mix(hash, 6)
    end
    if isHandle(value) then
        return mix(
            mixName(
                mix(hash, 7),
                value.kind
            ),
            value.id
        )
    end
    return mix(hash, (value == nil or value == nil) and 8 or 9)
end
____exports.WISP_LOCAL_NATIVES = {
    GetLocalPlayer = "identifies the client; every local branch starts here",
    GetPlayerId = "names this client's files; no effect",
    BlzSendSyncData = "only the sending client calls it; its message reaches every client as an event",
    PreloadGenClear = "local file output",
    PreloadGenStart = "local file output",
    Preload = "local file output",
    PreloadGenEnd = "local file output",
    Preloader = "local file input, synchronized only through sync data",
    BlzGetAbilityTooltip = "FileIO's local file buffer",
    BlzSetAbilityTooltip = "FileIO's local file buffer",
    DisplayTextToPlayer = "a message on this client: reload results and error reports",
    BlzFrameSetText = "the frame meter's overlay: an existing frame's text on this client",
    BlzFrameSetVisible = "the frame meter's overlay: shows an existing frame on this client",
    TimerGetElapsed = "reads a timer; the reload acknowledgement only reports it",
    BlzGetLocalSpecialEffectX = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectY = "the scene report reads an effect's local position",
    BlzGetLocalSpecialEffectZ = "the scene report reads an effect's local position"
}
local function copyBlend(blend)
    local ____temp_0
    if blend == nil then
        ____temp_0 = nil
    else
        ____temp_0 = {
            from = __TS__ObjectAssign(
                {},
                blend.from,
                {subAnimations = {table.unpack(blend.from.subAnimations)}}
            ),
            remaining = blend.remaining
        }
    end
    return ____temp_0
end
local BLEND_MODES = {
    "BLEND_MODE_NONE",
    "BLEND_MODE_DONT_CARE",
    "BLEND_MODE_KEYALPHA",
    "BLEND_MODE_BLEND",
    "BLEND_MODE_ADDITIVE",
    "BLEND_MODE_MODULATE",
    "BLEND_MODE_MODULATE_2X"
}
function ____exports.assertSoundCue(log, expected)
    local count = 0
    for ____, cue in ipairs(log) do
        do
            if cue.event ~= "start" then
                goto __continue4
            end
            if expected.source ~= nil and cue.source ~= expected.source then
                goto __continue4
            end
            if expected.label ~= nil and cue.label ~= expected.label then
                goto __continue4
            end
            if expected.frame ~= nil and cue.frame ~= expected.frame then
                goto __continue4
            end
            count = count + 1
        end
        ::__continue4::
    end
    if count ~= (expected.count or 1) then
        do
            local ____thrown = __TS__New(
                Error,
                (((("sound cue " .. (expected.source or expected.label or "any")) .. ": expected ") .. tostring(expected.count or 1)) .. " starts, got ") .. tostring(count)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/client.ts:175"
            end
            error(____thrown, 0)
        end
    end
end
____exports.FRAMES_PER_SECOND = ____frameRate.FRAMES_PER_SECOND
--- The shortest repeating period: a zero period fires about 10,000 times a game second (wisp:docs/warsmash-notes.md#timers-and-frame-stepping).
local MIN_PERIOD = 0xd1b717p-37
local MIN_ONE_SHOT = 0x1p-10
local function frameEnd(frame)
    return ____binary32.divideFloat32(frame, ____frameRate.FRAMES_PER_SECOND)
end
local function after(at, length)
    local due = ____binary32.addFloat32TowardZero(at, length)
    return due > at and due or ____binary32.addFloat32TowardZero(at, at * 0x1p-23)
end
local CAMERA_FIELDS = {
    "CAMERA_FIELD_TARGET_DISTANCE",
    "CAMERA_FIELD_FARZ",
    "CAMERA_FIELD_ANGLE_OF_ATTACK",
    "CAMERA_FIELD_FIELD_OF_VIEW",
    "CAMERA_FIELD_ROLL",
    "CAMERA_FIELD_ROTATION",
    "CAMERA_FIELD_ZOFFSET",
    "CAMERA_FIELD_NEARZ",
    "CAMERA_FIELD_LOCAL_PITCH",
    "CAMERA_FIELD_LOCAL_YAW",
    "CAMERA_FIELD_LOCAL_ROLL",
    "CAMERA_FIELD_DEPTH_OF_FIELD_DISTANCE",
    "CAMERA_FIELD_DEPTH_OF_FIELD_SCALE",
    "CAMERA_FIELD_ZABSOLUTE"
}
local PLAYER_COLORS = __TS__ArrayMap(
    {
        "RED",
        "BLUE",
        "CYAN",
        "PURPLE",
        "YELLOW",
        "ORANGE",
        "GREEN",
        "PINK",
        "LIGHT_GRAY",
        "LIGHT_BLUE",
        "AQUA",
        "BROWN",
        "MAROON",
        "NAVY",
        "TURQUOISE",
        "VIOLET",
        "WHEAT",
        "PEACH",
        "MINT",
        "LAVENDER",
        "COAL",
        "SNOW",
        "EMERALD",
        "PEANUT",
        "BLACK"
    },
    function(____, name) return "PLAYER_COLOR_" .. name end
)
isHandle = function(value) return type(value) == "table" and value ~= nil and value.id ~= nil and value.kind ~= nil end
local function isFrame(value)
    return type(value) == "table" and value ~= nil and value.points ~= nil
end
local DEATH_CUTOFF = 0xcf5c29p-25
local RADIANS_PER_DEGREE = 0x8efa35p-29
local DEGREES_PER_RADIAN = 0xe52ee1p-18
local TURN = 0xc90fdbp-21
--- Two ulps above the binary32 nearest 1 / TURN, as 3.0.1 multiplies by it.
local TURNS_PER_RADIAN = 0xa2f985p-26
local function unitFacing(degrees)
    local radians = ____binary32.multiplyFloat32TowardZero(degrees, RADIANS_PER_DEGREE)
    if radians >= TURN or radians < -TURN then
        local turns = ____binary32.multiplyFloat32TowardZero(radians, TURNS_PER_RADIAN)
        radians = ____binary32.multiplyFloat32TowardZero(
            __wispF32Subtract(
                turns,
                math.floor(turns)
            ),
            TURN
        )
    elseif radians < 0 then
        radians = ____binary32.subtractFloat32TowardZero(TURN, -radians)
    end
    return ____binary32.multiplyFloat32TowardZero(radians, DEGREES_PER_RADIAN)
end
function ____exports.describeValue(value)
    if value == nil or value == nil then
        return "nil"
    end
    if type(value) == "number" then
        return ____exports.describeNumber(value)
    end
    if type(value) == "string" then
        return ("\"" .. value) .. "\""
    end
    if type(value) == "boolean" then
        return value and "true" or "false"
    end
    if type(value) == "function" then
        return "fn"
    end
    if isHandle(value) then
        return (value.kind .. "#") .. ____exports.describeNumber(value.id)
    end
    return "table"
end
function ____exports.describeCall(____bindingPattern0)
    local args
    local name
    name = ____bindingPattern0.name
    args = ____bindingPattern0.args
    local call = name .. "("
    do
        local index = 0
        while index < #args do
            if index > 0 then
                call = call .. ", "
            end
            call = call .. ____exports.describeValue(args[index + 1])
            index = index + 1
        end
    end
    return call .. ")"
end
function ____exports.sameCall(left, right)
    if left.name ~= right.name or #left.args ~= #right.args then
        return false
    end
    do
        local index = 0
        while index < #left.args do
            do
                local leftArg = left.args[index + 1]
                local rightArg = right.args[index + 1]
                if leftArg == rightArg then
                    goto __continue45
                end
                if type(leftArg) == "function" and type(rightArg) == "function" then
                    goto __continue45
                end
                if isHandle(leftArg) and isHandle(rightArg) then
                    if leftArg.id ~= rightArg.id or leftArg.kind ~= rightArg.kind then
                        return false
                    end
                    goto __continue45
                end
                if ____exports.describeValue(leftArg) ~= ____exports.describeValue(rightArg) then
                    return false
                end
            end
            ::__continue45::
            index = index + 1
        end
    end
    return true
end
local function leadingNumber(text, fraction)
    local start = 0
    while not fraction and start < #text and __TS__StringCharAt(text, start) == " " do
        start = start + 1
    end
    local ____end = start
    if ____end < #text and (__TS__StringCharAt(text, ____end) == "-" or __TS__StringCharAt(text, ____end) == "+") then
        ____end = ____end + 1
    end
    local digits = 0
    local point = false
    while ____end < #text do
        local character = __TS__StringCharAt(text, ____end)
        if character >= "0" and character <= "9" then
            digits = digits + 1
        elseif fraction and character == "." and not point then
            point = true
        else
            break
        end
        ____end = ____end + 1
    end
    if digits == 0 then
        return 0
    end
    local value = __TS__Number(__TS__StringSlice(text, start, ____end))
    return value == value and value or 0
end
local function fixed(value, digits)
    local real = ____binary32.roundToFloat32(value)
    if real ~= real or real == math.huge or real == -math.huge or real >= 1.0000000200408773e+21 or real <= -1.0000000200408773e+21 then
        return __TS__NumberToFixed(real, digits)
    end
    local expanded = __TS__NumberToFixed(real < 0 and -real or real, digits + 30)
    local point = (string.find(expanded, ".", nil, true) or 0) - 1
    local kept = __TS__StringSlice(expanded, 0, point) .. __TS__StringSlice(expanded, point + 1, point + 1 + digits)
    local rest = __TS__StringSlice(expanded, point + 1 + digits)
    local digitsText = kept
    if string.sub(rest, 1, 1) >= "5" then
        local carry = #digitsText - 1
        while carry >= 0 and __TS__StringCharAt(digitsText, carry) == "9" do
            carry = carry - 1
        end
        digitsText = carry < 0 and "1" .. string.rep(
            "0",
            math.floor(#digitsText)
        ) or (__TS__StringSlice(digitsText, 0, carry) .. string.char(__TS__StringCharCodeAt(digitsText, carry) + 1)) .. string.rep(
            "0",
            math.floor(#digitsText - carry - 1)
        )
    end
    local whole = __TS__StringSlice(digitsText, 0, #digitsText - digits)
    local text = digits > 0 and (whole .. ".") .. __TS__StringSlice(digitsText, #digitsText - digits) or whole
    return real < 0 and "-" .. text or text
end
local SYNC_DATA_LIMIT = 255
mix = function(hash, value) return hash * 1000003 + value | 0 end
nameHashes = __TS__New(Map)
local function mixCall(hash, ____bindingPattern0)
    local args
    local name
    name = ____bindingPattern0.name
    args = ____bindingPattern0.args
    local mixed = mixName(hash, name)
    do
        local index = 0
        while index < #args do
            mixed = mixValue(mixed, args[index + 1])
            index = index + 1
        end
    end
    return mixed
end
INT32_LIMIT = 2147483648
____exports.HeadlessClient = __TS__Class()
local HeadlessClient = ____exports.HeadlessClient
HeadlessClient.name = "HeadlessClient"
function HeadlessClient.prototype.____constructor(self, options)
    self.textTags = __TS__New(____textTags.TextTags)
    self.lightnings = __TS__New(____lightnings.Lightnings)
    self.textAreaAutoScroll = __TS__New(Map)
    self.heldMouseButtons = __TS__New(Set)
    self.mouseScreenX = 0
    self.mouseScreenY = 0
    self.heldMeta = 0
    self.log = {}
    self.forgotten = 0
    self.forgottenHash = 0
    self.errors = {}
    self.missingNatives = {}
    self.messages = {}
    self.thrown = {}
    self.files = __TS__New(Map)
    self.published = __TS__New(Map)
    self.missedLookups = 0
    self.natives = {}
    self.frame = 0
    self.nextId = 0
    self.timers = {}
    self.spellHits = {}
    self.passiveAlliances = __TS__New(Map)
    self.timerOrder = 0
    self.now = 0
    self.registrations = {}
    self.heldKeys = __TS__New(Set)
    self.memo = __TS__New(Map)
    self.effects = __TS__New(Map)
    self.dying = {}
    self.effectSettled = __TS__New(WeakMap)
    self.effectDraws = 0
    self.effectDrawSeconds = 0
    self.units = __TS__New(Map)
    self.removals = {}
    self.sounds = __TS__New(Map)
    self.locations = __TS__New(Map)
    self.groups = __TS__New(Set)
    self.soundLog = {}
    self.musicVolume = 127
    self.cameraX = 0
    self.cameraY = 0
    self.cameraFields = {}
    self.cineFilter = {
        texture = "",
        blendMode = "BLEND_MODE_NONE",
        texMapFlags = nil,
        startColor = {255, 255, 255, 255},
        endColor = {255, 255, 255, 255},
        startUV = {0, 0, 1, 1},
        endUV = {0, 0, 1, 1},
        duration = 0,
        shown = nil
    }
    self.tooltips = __TS__New(Map)
    self.preloaded = __TS__New(Map)
    self.event = {
        player = 0,
        syncPrefix = "",
        syncData = "",
        chat = "",
        key = 0,
        timer = nil,
        frame = nil,
        frameEvent = nil
    }
    self.preload = {}
    self.abilities = __TS__New(____warcraft3Abilities.Warcraft3Abilities, options.abilityObjects)
    self.scenery = __TS__New(____warcraft3Scenery.Scenery, options.scenery)
    self.inventory = __TS__New(
        ____warcraft3Inventory.Warcraft3Inventory,
        {
            handle = function(kind) return self:handle(kind) end,
            getUnitTypeId = function(unit) return unit.typeId end,
            readLife = function(unit) return self:unitValue(unit, "life") end,
            readMaxLife = function(unit) return self:unitValue(unit, "maxLife") end,
            writeLife = function(unit, life) return self:setLife(unit, life) end
        },
        options.inventory
    )
    self.unitStates = options.unitStates or ({})
    self.effectDeaths = options.effectDeaths
    self.musicSlider = options.musicSlider or 1
    self.slot = options.slot
    self.scope = options.scope
    self.filePrefix = options.filePrefix
    self.stored = options.files
    local behaviors = self:behaviors(options)
    local ____local = options.localNatives
    local log = self.log
    local function logged(name, parameters, behave)
        repeat
            local ____switch86 = parameters
            local ____cond86 = ____switch86 == 0
            if ____cond86 then
                return function()
                    log[#log + 1] = {name = name, args = {}}
                    return behave()
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 1
            if ____cond86 then
                return function(a)
                    log[#log + 1] = {name = name, args = {a}}
                    return behave(a)
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 2
            if ____cond86 then
                return function(a, b)
                    log[#log + 1] = {name = name, args = {a, b}}
                    return behave(a, b)
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 3
            if ____cond86 then
                return function(a, b, c)
                    log[#log + 1] = {name = name, args = {a, b, c}}
                    return behave(a, b, c)
                end
            end
            ____cond86 = ____cond86 or ____switch86 == 4
            if ____cond86 then
                return function(a, b, c, d)
                    log[#log + 1] = {name = name, args = {a, b, c, d}}
                    return behave(a, b, c, d)
                end
            end
            do
                return function(...)
                    local args = {...}
                    log[#log + 1] = {name = name, args = args}
                    return behave(...)
                end
            end
        until true
    end
    local arity = __TS__New(Map)
    local declared = __TS__New(Set)
    local missing = __TS__New(Set)
    local noops = options.intentionalNoops or ({})
    for ____, name in ipairs(__TS__ObjectKeys(noops)) do
        if not __TS__ArraySome(
            options.declarations.functions,
            function(____, ____bindingPattern0)
                local native
                native = ____bindingPattern0[1]
                return native == name
            end
        ) or __TS__StringTrim(noops[name] or "") == "" then
            do
                local ____thrown = __TS__New(Error, ("intentional no-op " .. name) .. " needs a declared native and a concrete reason")
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/client.ts:642"
                end
                error(____thrown, 0)
            end
        end
    end
    for ____, ____value in ipairs(options.declarations.functions) do
        local name = ____value[1]
        local returns = ____value[2]
        local parameters = ____value[3]
        declared:add(name)
        arity:set(name, parameters)
        local fallback = self:defaultNative(returns)
        local behave = behaviors[name] or (__TS__StringStartsWith(name, "Convert") and (function(value) return value end) or (noops[name] ~= nil and fallback or (function()
            if not missing:has(name) then
                missing:add(name)
                local ____self_missingNatives_1 = self.missingNatives
                ____self_missingNatives_1[#____self_missingNatives_1 + 1] = {native = name, client = self.slot, frame = self.frame}
            end
            return fallback()
        end)))
        self.natives[name] = ____local[name] == nil and logged(name, parameters, behave) or behave
    end
    for ____, ____value in ipairs(options.declarations.constants) do
        local name = ____value[1]
        local ____type = ____value[2]
        local ____self_natives_5 = self.natives
        local ____name_6 = name
        local ____WARCRAFT3_ENUM_VALUES_name_4 = ____warcraft3Natives.WARCRAFT3_ENUM_VALUES[name]
        if ____WARCRAFT3_ENUM_VALUES_name_4 == nil then
            local ____temp_3
            if ____type == "number" then
                ____temp_3 = 0
            else
                local ____temp_2
                if ____type == "boolean" then
                    ____temp_2 = name == "TRUE"
                else
                    ____temp_2 = name
                end
                ____temp_3 = ____temp_2
            end
            ____WARCRAFT3_ENUM_VALUES_name_4 = ____temp_3
        end
        ____self_natives_5[____name_6] = ____WARCRAFT3_ENUM_VALUES_name_4
    end
    for ____, ____value in ipairs(options.declarations.variables) do
        local name = ____value[1]
        local ____type = ____value[2]
        self.natives[name] = self:defaultValue(____type)
    end
    local points = __TS__New(Map)
    do
        local index = 0
        while index < #____frames.FRAME_POINTS do
            local name, fromLeft, fromTop = table.unpack(____frames.FRAME_POINTS[index + 1] or ({"", 0, 0}), 1, 3)
            local ____points_set_8 = points.set
            local ____self_natives_name_7 = self.natives[name]
            if ____self_natives_name_7 == nil then
                ____self_natives_name_7 = name
            end
            ____points_set_8(points, ____self_natives_name_7, {fromLeft, fromTop})
            points:set(index, {fromLeft, fromTop})
            index = index + 1
        end
    end
    self.frames = __TS__New(____frames.Frames, points)
    self.frames:define(options.frames or ({}))
    local ____opt_9 = options.natives
    local extra = ____opt_9 and ____opt_9(self) or ({})
    for ____, name in ipairs(__TS__ObjectKeys(extra)) do
        local value = extra[name]
        self.natives[name] = type(value) == "function" and declared:has(name) and ____local[name] == nil and logged(
            name,
            arity:get(name) or 5,
            value
        ) or value
    end
end
function HeadlessClient.prototype.clockSeconds(self)
    return self.wallSeconds or self.frame / ____frameRate.FRAMES_PER_SECOND
end
function HeadlessClient.prototype.setWallTime(self, seconds)
    self.wallSeconds = seconds
end
function HeadlessClient.prototype.liveHandleCounts(self)
    return {locations = self.locations.size, groups = self.groups.size}
end
function HeadlessClient.prototype.handle(self, kind)
    self.nextId = self.nextId + 1
    return {kind = kind, id = self.nextId}
end
function HeadlessClient.prototype.defaultNative(self, returns)
    repeat
        local ____switch115 = returns
        local ____cond115 = ____switch115 == "void"
        if ____cond115 then
            return function() return nil end
        end
        ____cond115 = ____cond115 or ____switch115 == "number"
        if ____cond115 then
            return function() return 0 end
        end
        ____cond115 = ____cond115 or ____switch115 == "string"
        if ____cond115 then
            return function() return "" end
        end
        ____cond115 = ____cond115 or ____switch115 == "boolean"
        if ____cond115 then
            return function() return false end
        end
        do
            return function() return self:handle(returns) end
        end
    until true
end
function HeadlessClient.prototype.defaultValue(self, ____type)
    if __TS__StringEndsWith(____type, "[]") then
        return {}
    end
    repeat
        local ____switch123 = ____type
        local ____cond123 = ____switch123 == "boolean"
        if ____cond123 then
            return false
        end
        ____cond123 = ____cond123 or ____switch123 == "number"
        if ____cond123 then
            return 0
        end
        ____cond123 = ____cond123 or ____switch123 == "string"
        if ____cond123 then
            return ""
        end
        do
            return self:handle(____type)
        end
    until true
end
function HeadlessClient.prototype.memoized(self, key, name)
    if name == nil then
        name = ""
    end
    local known = self.memo:get(key)
    if known ~= nil then
        return known
    end
    local created = self.frames:add(
        self:handle("framehandle"),
        "",
        name,
        nil,
        0
    )
    self.memo:set(key, created)
    return created
end
function HeadlessClient.prototype.created(self, ____type, name, owner, context)
    return self.frames:add(
        self:handle("framehandle"),
        ____type,
        name,
        isFrame(owner) and owner or nil,
        context
    )
end
function HeadlessClient.prototype.effectAt(self, model, x, y)
    local handle = self:handle("effect")
    local pose = __TS__ObjectAssign(
        {},
        ____animation.freshAnimation(),
        {
            handle = handle,
            model = model,
            created = self.frame,
            x = x,
            y = y,
            z = 0,
            alpha = 255,
            scale = 1,
            timeScale = 1,
            flat = false,
            queuedAnimations = {},
            yaw = 0,
            pitch = 0,
            roll = 0,
            color = {255, 255, 255},
            teamColor = 0,
            matrixScale = {1, 1, 1}
        }
    )
    self.effects:set(handle, pose)
    self.effectSettled:set(pose, self.effectDraws)
    return handle
end
function HeadlessClient.prototype.unitAt(self, owner, typeId, x, y, facing)
    local handle = self:handle("unit")
    local state = self.unitStates[typeId]
    local unit = __TS__ObjectAssign(
        {},
        handle,
        ____animation.freshAnimation(),
        {
            handle = handle,
            typeId = typeId,
            owner = owner,
            x = x,
            y = y,
            z = 0,
            facing = unitFacing(facing),
            scale = {1, 1, 1},
            alpha = 255,
            color = {255, 255, 255},
            teamColor = owner,
            timeScale = 1,
            visible = true,
            moveSpeed = 0,
            attackCooldown = 0,
            life = state and state.life,
            maxLife = state and state.maxLife,
            mana = state and state.mana,
            maxMana = state and state.maxMana,
            dead = state ~= nil and state.life <= DEATH_CUTOFF,
            removed = false
        }
    )
    self.units:set(unit, unit)
    return unit
end
function HeadlessClient.prototype.unitValue(self, unit, field)
    if unit.removed then
        return 0
    end
    local value = unit[field]
    if value == nil then
        do
            local ____thrown = __TS__New(
                Error,
                ((((("unit type " .. tostring(unit.typeId)) .. ": declare unitStates.") .. tostring(unit.typeId)) .. ".") .. field) .. " or set it before reading"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/client.ts:738"
            end
            error(____thrown, 0)
        end
    end
    return value
end
function HeadlessClient.prototype.setLife(self, unit, life)
    if unit.removed then
        return
    end
    local value = unit.life == nil and life or ____binary32.addFloat32(
        unit.life,
        ____binary32.subtractFloat32(life, unit.life, true)
    )
    if not unit.dead and value <= DEATH_CUTOFF then
        unit.life = 0
        unit.dead = true
    else
        unit.life = value
    end
end
function HeadlessClient.prototype.unitAnimation(self, unit, animation)
    ____animation.selectAnimation(unit, animation)
end
function HeadlessClient.prototype.sound(self, source, label, looping)
    local handle = self:handle("sound")
    local sound = {
        kind = "sound",
        handle = handle,
        source = source,
        label = label,
        volume = 127,
        pitch = 1,
        x = 0,
        y = 0,
        z = 0,
        unit = nil,
        looping = looping,
        duration = 0,
        elapsed = 0,
        playing = false,
        killWhenDone = false
    }
    self.sounds:set(handle, sound)
    self:cue(sound, "create")
    return handle
end
function HeadlessClient.prototype.cue(self, sound, event)
    local ____self_soundLog_34 = self.soundLog
    local ____event_23 = event
    local ____sound_kind_24 = sound.kind
    local ____self_frame_25 = self.frame
    local ____sound_handle_26 = sound.handle
    local ____sound_source_27 = sound.source
    local ____sound_label_28 = sound.label
    local ____sound_volume_29 = sound.volume
    local ____temp_30 = sound.volume / 127 * (sound.kind == "music" and self.musicSlider or 1)
    local ____sound_looping_31 = sound.looping
    local ____sound_pitch_32 = sound.pitch
    local ____opt_19 = sound.unit
    local ____temp_33 = ____opt_19 and ____opt_19.x or sound.x
    local ____opt_21 = sound.unit
    ____self_soundLog_34[#____self_soundLog_34 + 1] = {
        event = ____event_23,
        kind = ____sound_kind_24,
        frame = ____self_frame_25,
        handle = ____sound_handle_26,
        source = ____sound_source_27,
        label = ____sound_label_28,
        volume = ____sound_volume_29,
        effectiveVolume = ____temp_30,
        looping = ____sound_looping_31,
        pitch = ____sound_pitch_32,
        x = ____temp_33,
        y = ____opt_21 and ____opt_21.y or sound.y,
        z = sound.z
    }
end
function HeadlessClient.prototype.stopAudio(self, sound)
    if not sound.playing then
        return
    end
    self:cue(sound, "stop")
    sound.playing = false
end
function HeadlessClient.prototype.playMusic(self, source, looping)
    if looping == nil then
        looping = true
    end
    if self.music ~= nil then
        self:stopAudio(self.music)
    end
    self.music = {
        kind = "music",
        handle = {kind = "music", id = 0},
        source = source,
        label = nil,
        volume = self.musicVolume,
        pitch = 1,
        x = 0,
        y = 0,
        z = 0,
        unit = nil,
        looping = looping,
        duration = 0,
        elapsed = 0,
        playing = true,
        killWhenDone = false
    }
    self:cue(self.music, "start")
end
function HeadlessClient.prototype.startSound(self, handle)
    local sound = self.sounds:get(handle)
    if sound == nil or sound.playing then
        return
    end
    self:cue(sound, "start")
    sound.elapsed = 0
    sound.playing = sound.looping or sound.duration > 0
    if not sound.playing and sound.killWhenDone then
        self.sounds:delete(handle)
    end
end
function HeadlessClient.prototype.cameraField(self, field)
    if type(field) == "number" then
        return CAMERA_FIELDS[field + 1] or ____exports.describeValue(field)
    end
    if type(field) == "string" then
        return field
    end
    return ____exports.describeValue(field)
end
function HeadlessClient.prototype.liveEffect(self, effect)
    local pose = self.effects:get(effect)
    local ____temp_37
    if (pose and pose.destroyed) == nil then
        ____temp_37 = pose
    else
        ____temp_37 = nil
    end
    return ____temp_37
end
function HeadlessClient.prototype.settleEffect(self, pose)
    local settled = self.effectSettled:get(pose) or self.effectDraws
    if settled == self.effectDraws then
        return
    end
    ____animation.settleAnimation(pose, pose.timeScale, self.effectDrawSeconds, self.effectDraws - settled)
    self.effectSettled:set(pose, self.effectDraws)
end
function HeadlessClient.prototype.destroyEffect(self, effect)
    local pose = self:liveEffect(effect)
    if pose == nil then
        return
    end
    local ____opt_38 = self.effectDeaths
    local death = ____opt_38 and ____opt_38(pose.model)
    self:settleEffect(pose)
    pose.destroyed = self.frame
    local ____self_dying_40 = self.dying
    ____self_dying_40[#____self_dying_40 + 1] = pose
    __TS__ArraySetLength(pose.queuedAnimations, 0)
    if death ~= nil and death > 0 then
        pose.death = death
        ____animation.selectAnimation(pose, "death", {})
    end
end
function HeadlessClient.prototype.playEffect(self, effect, animation, timeScale)
    local pose = self:liveEffect(effect)
    if pose == nil then
        return
    end
    self:settleEffect(pose)
    ____animation.selectAnimation(pose, animation, nil, true)
    if timeScale ~= nil then
        pose.timeScale = timeScale
    end
end
function HeadlessClient.prototype.show(self, text)
    local ____self_messages_41 = self.messages
    ____self_messages_41[#____self_messages_41 + 1] = text
end
function HeadlessClient.prototype.report(self, lines)
    local heading = lines[1] or ""
    local ____self_errors_42 = self.errors
    ____self_errors_42[#____self_errors_42 + 1] = (("error in " .. __TS__StringSlice(
        heading,
        (string.find(heading, " in ", nil, true) or 0) - 1 + 4
    )) .. ": ") .. (lines[2] or "")
end
function HeadlessClient.prototype.behaviors(self, ____bindingPattern0)
    local screen
    local network
    local playerNames
    local humans
    humans = ____bindingPattern0.humans
    playerNames = ____bindingPattern0.playerNames
    network = ____bindingPattern0.network
    screen = ____bindingPattern0.screen
    local function playing(player)
        return __TS__ArrayIncludes(humans, player)
    end
    return __TS__ObjectAssign(
        {},
        self.scenery:behaviors({handle = function(kind) return self:handle(kind) end}),
        self.textTags:behaviors({
            handle = function(kind) return self:handle(kind) end,
            unitPosition = function(unit)
                local live = unit
                local ____temp_43
                if live == nil or live.removed then
                    ____temp_43 = nil
                else
                    ____temp_43 = {x = live.x, y = live.y, z = live.z}
                end
                return ____temp_43
            end
        }),
        self.lightnings:behaviors({handle = function(kind) return self:handle(kind) end}),
        self.inventory:behaviors(),
        {
            GetLocalPlayer = function() return self.slot end,
            Player = function(n) return n end,
            GetPlayerId = function(player) return player end,
            GetPlayerName = function(player) return playerNames and playerNames[player] or "Player " .. tostring(player + 1) end,
            GetTriggerPlayer = function() return self.event.player end,
            GetHandleId = function(handle) return isHandle(handle) and handle.id or handle end,
            Location = function(x, y)
                local handle = self:handle("location")
                self.locations:set(handle, {x = x, y = y})
                return handle
            end,
            RemoveLocation = function(handle)
                self.locations:delete(handle)
            end,
            MoveLocation = function(handle, x, y)
                local location = self.locations:get(handle)
                if location ~= nil then
                    location.x = x
                    location.y = y
                end
            end,
            GetLocationX = function(handle)
                local ____opt_46 = self.locations:get(handle)
                return ____opt_46 and ____opt_46.x or 0
            end,
            GetLocationY = function(handle)
                local ____opt_48 = self.locations:get(handle)
                return ____opt_48 and ____opt_48.y or 0
            end,
            CreateGroup = function()
                local handle = self:handle("group")
                self.groups:add(handle)
                return handle
            end,
            DestroyGroup = function(handle)
                self.groups:delete(handle)
            end,
            GetPlayerController = function(player) return playing(player) and "MAP_CONTROL_USER" or "MAP_CONTROL_NONE" end,
            GetPlayerSlotState = function(player) return playing(player) and "PLAYER_SLOT_STATE_PLAYING" or "PLAYER_SLOT_STATE_EMPTY" end,
            GetPlayersAll = function()
                if self.allPlayers == nil then
                    self.allPlayers = self:handle("force")
                end
                return self.allPlayers
            end,
            CreateUnit = function(owner, typeId, x, y, facing) return self:unitAt(
                owner,
                typeId,
                x,
                y,
                facing
            ) end,
            CreateUnitByName = function(owner, name, x, y, facing) return self:unitAt(
                owner,
                #name == 4 and (string.byte(name, 1) or 0 / 0) * 16777216 + (string.byte(name, 2) or 0 / 0) * 65536 + (string.byte(name, 3) or 0 / 0) * 256 + (string.byte(name, 4) or 0 / 0) or 0,
                x,
                y,
                facing
            ) end,
            RemoveUnit = function(unit)
                local ____self_removals_50 = self.removals
                ____self_removals_50[#____self_removals_50 + 1] = unit
                self.units:delete(unit)
                self.abilities:removeUnit(unit)
            end,
            GetOwningPlayer = function(unit) return unit.owner end,
            GetWidgetLife = function(unit) return self:unitValue(unit, "life") end,
            SetWidgetLife = function(unit, life) return self:setLife(unit, life) end,
            KillUnit = function(unit)
                if not unit.removed then
                    unit.life = 0
                    unit.dead = true
                end
            end,
            GetUnitState = function(unit, state)
                if state == "UNIT_STATE_LIFE" then
                    return self:unitValue(unit, "life")
                end
                if state == "UNIT_STATE_MAX_LIFE" then
                    return self:unitValue(unit, "maxLife")
                end
                if state == "UNIT_STATE_MANA" then
                    return self:unitValue(unit, "mana")
                end
                if state == "UNIT_STATE_MAX_MANA" then
                    return self:unitValue(unit, "maxMana")
                end
                do
                    local ____thrown = __TS__New(Error, "GetUnitState: unsupported state " .. state)
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/headless/client.ts:898"
                    end
                    error(____thrown, 0)
                end
            end,
            SetUnitState = function(unit, state, value)
                if unit.removed then
                    return
                end
                if state == "UNIT_STATE_LIFE" then
                    self:setLife(unit, value)
                elseif state == "UNIT_STATE_MANA" then
                    unit.mana = unit.mana == nil and value or ____binary32.addFloat32(
                        unit.mana,
                        ____binary32.subtractFloat32(value, unit.mana, true)
                    )
                elseif state ~= "UNIT_STATE_MAX_LIFE" and state ~= "UNIT_STATE_MAX_MANA" then
                    do
                        local ____thrown = __TS__New(Error, "SetUnitState: unsupported state " .. state)
                        if _G.__wispThrown ~= ____thrown then
                            _G.__wispThrown = ____thrown
                            _G.__wispThrowSite = "wisp/src/headless/client.ts:905"
                        end
                        error(____thrown, 0)
                    end
                end
            end,
            BlzGetUnitMaxHP = function(unit) return self:unitValue(unit, "maxLife") end,
            BlzSetUnitMaxHP = function(unit, value)
                if not unit.removed then
                    unit.maxLife = value
                end
            end,
            BlzGetUnitMaxMana = function(unit) return self:unitValue(unit, "maxMana") end,
            BlzSetUnitMaxMana = function(unit, value)
                if not unit.removed then
                    unit.maxMana = value
                end
            end,
            ShowUnit = function(unit, show)
                unit.visible = show
            end,
            IsUnitHidden = function(unit) return not unit.visible end,
            GetUnitFlyHeight = function(unit) return unit.z end,
            SetUnitFlyHeight = function(unit, height)
                unit.z = height
            end,
            GetUnitFacing = function(unit) return unit.facing end,
            SetUnitFacing = function(unit, facing)
                unit.facing = unitFacing(facing)
            end,
            BlzSetUnitFacingEx = function(unit, facing)
                unit.facing = unitFacing(facing)
            end,
            SetUnitScale = function(unit, x, y, z)
                unit.scale = {x, y, z}
            end,
            SetUnitTimeScale = function(unit, timeScale)
                unit.timeScale = timeScale
            end,
            SetUnitBlendTime = function(unit, blendTime)
                unit.animationBlendTime = blendTime
            end,
            SetUnitVertexColor = function(unit, red, green, blue, alpha)
                unit.color = {red, green, blue}
                unit.alpha = alpha
            end,
            SetUnitColor = function(unit, color)
                unit.teamColor = type(color) == "number" and color or __TS__ArrayIndexOf(PLAYER_COLORS, color)
            end,
            SetUnitAnimation = function(unit, animation) return self:unitAnimation(unit, animation) end,
            SetUnitAnimationByIndex = function(unit, animation) return self:unitAnimation(unit, animation) end,
            SetUnitAnimationWithRarity = function(unit, animation) return self:unitAnimation(unit, animation) end,
            GetUnitTypeId = function(unit) return unit.removed and 0 or unit.typeId end,
            GetUnitX = function(unit) return unit.x end,
            GetUnitY = function(unit) return unit.y end,
            SetUnitX = function(unit, x)
                unit.x = x
            end,
            SetUnitY = function(unit, y)
                unit.y = y
            end,
            SetUnitPosition = function(unit, x, y)
                unit.x = x
                unit.y = y
            end,
            SetUnitMoveSpeed = function(unit, value)
                unit.moveSpeed = value
            end,
            GetUnitMoveSpeed = function(unit) return unit.moveSpeed end,
            SetPlayerAlliance = function(source, target, which, allied)
                if which ~= "ALLIANCE_PASSIVE" then
                    do
                        local ____thrown = __TS__New(Error, "SetPlayerAlliance: unsupported alliance " .. which)
                        if _G.__wispThrown ~= ____thrown then
                            _G.__wispThrown = ____thrown
                            _G.__wispThrowSite = "wisp/src/headless/client.ts:949"
                        end
                        error(____thrown, 0)
                    end
                end
                self.passiveAlliances:set(
                    (tostring(source) .. " ") .. tostring(target),
                    allied
                )
            end,
            IssueTargetOrder = function(caster, order, target)
                local ____temp_51
                if order == "shadowstrike" then
                    ____temp_51 = self.abilities:shadowStrike(caster)
                else
                    ____temp_51 = nil
                end
                local spell = ____temp_51
                if spell == nil or spell.interval <= 0 or spell.duration <= 0 then
                    local ____self_missingNatives_52 = self.missingNatives
                    ____self_missingNatives_52[#____self_missingNatives_52 + 1] = {native = "IssueTargetOrder", client = self.slot, frame = self.frame}
                    return false
                end
                if not self.units:has(caster) or not self.units:has(target) or caster.dead or target.dead or caster.owner == target.owner or self.passiveAlliances:get((tostring(caster.owner) .. " ") .. tostring(target.owner)) == true then
                    return false
                end
                local dx = target.x - caster.x
                local dy = target.y - caster.y
                if dx * dx + dy * dy > spell.range * spell.range then
                    return false
                end
                local impact = after(self.now, spell.impactDelay)
                local ____self_spellHits_53 = self.spellHits
                ____self_spellHits_53[#____self_spellHits_53 + 1] = {target = target, due = impact, damage = spell.initial}
                do
                    local elapsed = spell.interval
                    while elapsed < spell.duration do
                        local ____self_spellHits_54 = self.spellHits
                        ____self_spellHits_54[#____self_spellHits_54 + 1] = {
                            target = target,
                            due = after(impact, elapsed),
                            damage = spell.periodic
                        }
                        elapsed = after(elapsed, spell.interval)
                    end
                end
                return true
            end
        },
        self.abilities:behaviors(function(kind) return self:handle(kind) end),
        {
            BlzGetLocalClientWidth = function() return screen.width end,
            BlzGetLocalClientHeight = function() return screen.height end,
            BlzIsLocalClientActive = function() return true end,
            BlzIsKeyPressed = function(key) return self.heldKeys:has(key) end,
            BlzIsMetaKeyPressed = function(meta) return self.heldMeta & meta == meta end,
            BlzIsMouseButtonPressed = function(button) return self.heldMouseButtons:has(button) end,
            BlzGetMouseScreenPosX = function() return self.mouseScreenX end,
            BlzGetMouseScreenPosY = function() return self.mouseScreenY end,
            BlzPixelToFrameX = function(pixel) return __wispF32Divide(pixel * 0xcccccdp-24, screen.width) end,
            BlzPixelToFrameY = function(pixel) return __wispF32Divide(pixel * 0x4ccccdp-23, screen.height) end,
            BlzFrameToPixelX = function(frame) return math.floor(frame * screen.width / 0xcccccdp-24 + 0x1p-1) end,
            BlzFrameToPixelY = function(frame) return math.floor(frame * screen.height / 0x4ccccdp-23 + 0x1p-1) end,
            BlzTextAreaFrameSetAutoScroll = function(frame, value)
                self.textAreaAutoScroll:set(frame, value)
            end,
            BlzLoadTOCFile = function() return true end,
            BlzGetOriginFrame = function(____type, index)
                local frame = self:memoized((("origin " .. ____exports.describeValue(____type)) .. " ") .. tostring(index))
                if ____type == self.natives.ORIGIN_FRAME_GAME_UI then
                    self.frames.gameUi:add(frame)
                end
                return frame
            end,
            BlzGetFrameByName = function(name, context) return self.frames:named(name, context) or self:memoized(
                (("name " .. name) .. " ") .. tostring(context),
                name
            ) end,
            BlzFrameGetChildrenCount = function(frame) return isFrame(frame) and #self.frames:children(frame) or 0 end,
            BlzFrameGetChild = function(frame, index)
                local ____isFrame_result_55
                if isFrame(frame) then
                    ____isFrame_result_55 = self.frames:children(frame)[index + 1]
                else
                    ____isFrame_result_55 = nil
                end
                return ____isFrame_result_55 or self:memoized((("child " .. tostring(frame.id)) .. " ") .. tostring(index))
            end,
            BlzCreateFrame = function(name, owner, _priority, context) return self.frames:create(
                function() return self:handle("framehandle") end,
                name,
                isFrame(owner) and owner or nil,
                context
            ) end,
            BlzCreateSimpleFrame = function(name, owner, context) return self:created(name, name, owner, context) end,
            BlzCreateFrameByType = function(____type, name, owner, _inherits, context) return self:created(____type, name, owner, context) end,
            BlzDestroyFrame = function(frame)
                if isFrame(frame) then
                    self.frames:destroy(frame)
                end
            end,
            BlzFrameGetName = function(frame) return isFrame(frame) and frame.name or "" end,
            BlzFrameGetParent = function(frame)
                local ____isFrame_result_56
                if isFrame(frame) then
                    ____isFrame_result_56 = frame.parent
                else
                    ____isFrame_result_56 = nil
                end
                return ____isFrame_result_56
            end,
            BlzFrameSetText = function(frame, text)
                if isFrame(frame) then
                    frame.text = frame.textLimit >= 0 and __TS__StringSlice(text, 0, frame.textLimit) or text
                end
            end,
            BlzFrameGetText = function(frame) return isFrame(frame) and frame.text or "" end,
            BlzFrameSetTexture = function(frame, texture)
                if isFrame(frame) then
                    frame.texture = texture
                end
            end,
            BlzFrameSetVertexColor = function(frame, color)
                if isFrame(frame) then
                    frame.color = color
                end
            end,
            BlzFrameSetTextColor = function(frame, color)
                if isFrame(frame) then
                    frame.textColor = color
                end
            end,
            BlzFrameSetAlpha = function(frame, alpha)
                if isFrame(frame) then
                    frame.alpha = alpha
                end
            end,
            BlzFrameGetAlpha = function(frame) return isFrame(frame) and frame.alpha or 0 end,
            BlzFrameSetTextSizeLimit = function(frame, size)
                if isFrame(frame) then
                    frame.textLimit = size
                end
            end,
            BlzFrameGetTextSizeLimit = function(frame) return isFrame(frame) and frame.textLimit or 0 end,
            BlzFrameSetFont = function(frame, file, height, flags)
                if isFrame(frame) then
                    frame.font = {file = file, height = height, flags = flags}
                end
            end,
            BlzFrameSetTextAlignment = function(frame, vertical, horizontal)
                if isFrame(frame) then
                    frame.alignment = {vertical = vertical, horizontal = horizontal}
                end
            end,
            BlzFrameSetScale = function(frame, scale)
                if isFrame(frame) then
                    frame.scale = scale
                end
            end,
            BlzFrameSetVisible = function(frame, visible)
                if isFrame(frame) then
                    frame.visible = visible
                end
            end,
            BlzFrameIsVisible = function(frame)
                local ____isFrame_result_57
                if isFrame(frame) then
                    ____isFrame_result_57 = self.frames:shown(frame)
                else
                    ____isFrame_result_57 = false
                end
                return ____isFrame_result_57
            end,
            BlzFrameSetEnable = function(frame, enabled)
                if isFrame(frame) then
                    frame.enabled = enabled
                end
            end,
            BlzFrameGetEnable = function(frame)
                local ____isFrame_result_58
                if isFrame(frame) then
                    ____isFrame_result_58 = frame.enabled
                else
                    ____isFrame_result_58 = false
                end
                return ____isFrame_result_58
            end,
            BlzFrameSetFocus = function(frame, flag)
                if isFrame(frame) then
                    self.frames:focus(frame, flag)
                end
            end,
            BlzFrameSetLevel = function(frame, level)
                if isFrame(frame) then
                    frame.level = level
                end
            end,
            BlzFrameSetSize = function(frame, width, height)
                if isFrame(frame) then
                    frame.width = width
                    frame.height = height
                end
            end,
            BlzFrameSetAbsPoint = function(frame, point, x, y)
                if isFrame(frame) then
                    frame.points:set(point, {x = x, y = y})
                end
            end,
            BlzFrameClearAllPoints = function(frame)
                if isFrame(frame) then
                    frame.points:clear()
                    __TS__ArraySetLength(frame.anchors, 0)
                end
            end,
            BlzFrameSetPoint = function(frame, point, relative, relativePoint, x, y)
                if not isFrame(frame) or not isFrame(relative) then
                    return
                end
                local function name(value)
                    local ____temp_61
                    if type(value) == "number" then
                        local ____opt_59 = ____frames.FRAME_POINTS[value + 1]
                        ____temp_61 = ____opt_59 and ____opt_59[1] or ""
                    else
                        ____temp_61 = type(value) == "string" and value or ""
                    end
                    return ____temp_61
                end
                local ownPoint = __TS__StringReplace(
                    name(point),
                    "FRAMEPOINT_",
                    ""
                )
                do
                    local index = #frame.anchors - 1
                    while index >= 0 do
                        local ____opt_62 = frame.anchors[index + 1]
                        if (____opt_62 and ____opt_62.point) == ownPoint then
                            __TS__ArraySplice(frame.anchors, index, 1)
                        end
                        index = index - 1
                    end
                end
                local ____frame_anchors_64 = frame.anchors
                ____frame_anchors_64[#____frame_anchors_64 + 1] = {
                    point = ownPoint,
                    relative = relative,
                    relativePoint = __TS__StringReplace(
                        name(relativePoint),
                        "FRAMEPOINT_",
                        ""
                    ),
                    x = x,
                    y = y
                }
            end,
            BlzFrameSetAllPoints = function(frame, relative)
                if not isFrame(frame) or not isFrame(relative) then
                    return false
                end
                frame.points:clear()
                __TS__ArraySetLength(frame.anchors, 0)
                for ____, point in ipairs({"TOPLEFT", "BOTTOMRIGHT"}) do
                    local ____frame_anchors_65 = frame.anchors
                    ____frame_anchors_65[#____frame_anchors_65 + 1] = {
                        point = point,
                        relative = relative,
                        relativePoint = point,
                        x = 0,
                        y = 0
                    }
                end
                return true
            end,
            BlzTriggerRegisterFrameEvent = function(trigger, frame, event)
                if isFrame(frame) then
                    local ____self_registrations_66 = self.registrations
                    ____self_registrations_66[#____self_registrations_66 + 1] = {kind = "frame", trigger = trigger, frame = frame, event = event}
                end
                return self:handle("event")
            end,
            BlzGetTriggerFrame = function() return self.event.frame end,
            BlzGetTriggerFrameEvent = function() return self.event.frameEvent end,
            BlzGetTriggerFrameText = function()
                local ____opt_67 = self.event.frame
                return ____opt_67 and ____opt_67.text or ""
            end,
            BlzGetTriggerSyncData = function() return self.event.syncData end,
            BlzGetTriggerSyncPrefix = function() return self.event.syncPrefix end,
            GetEventPlayerChatString = function() return self.event.chat end,
            BlzGetTriggerPlayerKey = function() return self.event.key end,
            GetExpiredTimer = function() return self.event.timer end,
            CreateTrigger = function() return __TS__ObjectAssign(
                {},
                self:handle("trigger"),
                {actions = {}, destroyed = false, running = false, interrupted = false}
            ) end,
            BlzTriggerIsRunning = function(trigger) return trigger.running end,
            BlzTriggerInterrupt = function(trigger)
                trigger.interrupted = true
            end,
            DestroyTrigger = function(trigger)
                trigger.destroyed = true
            end,
            TriggerAddAction = function(trigger, action)
                local ____trigger_actions_69 = trigger.actions
                ____trigger_actions_69[#____trigger_actions_69 + 1] = action
                return self:handle("triggeraction")
            end,
            BlzTriggerRegisterPlayerSyncEvent = function(trigger, player, prefix)
                local ____self_registrations_70 = self.registrations
                ____self_registrations_70[#____self_registrations_70 + 1] = {kind = "sync", trigger = trigger, player = player, prefix = prefix}
                return self:handle("event")
            end,
            TriggerRegisterPlayerChatEvent = function(trigger, player, text, exact)
                local ____self_registrations_71 = self.registrations
                ____self_registrations_71[#____self_registrations_71 + 1] = {
                    kind = "chat",
                    trigger = trigger,
                    player = player,
                    text = text,
                    exact = exact
                }
                return self:handle("event")
            end,
            BlzTriggerRegisterPlayerKeyEvent = function(trigger, player, key, meta, down)
                local ____self_registrations_72 = self.registrations
                ____self_registrations_72[#____self_registrations_72 + 1] = {
                    kind = "key",
                    trigger = trigger,
                    player = player,
                    key = key,
                    meta = meta,
                    down = down
                }
                return self:handle("event")
            end,
            CreateTimer = function()
                local timer = __TS__ObjectAssign(
                    {},
                    self:handle("timer"),
                    {
                        callback = nil,
                        periodic = false,
                        timeout = 0,
                        period = 0,
                        due = 0,
                        order = 0,
                        running = false,
                        expired = false,
                        paused = nil
                    }
                )
                local ____self_timers_73 = self.timers
                ____self_timers_73[#____self_timers_73 + 1] = timer
                return timer
            end,
            TimerStart = function(timer, timeout, periodic, callback)
                local seconds = ____binary32.roundToFloat32(timeout)
                local shortest = periodic and MIN_PERIOD or MIN_ONE_SHOT
                timer.callback = callback
                timer.periodic = periodic
                timer.timeout = seconds
                timer.period = seconds >= shortest and seconds or shortest
                timer.due = after(self.now, timer.period)
                local ____timer_77 = timer
                local ____self_74, ____timerOrder_75 = self, "timerOrder"
                local ____self_timerOrder_76 = ____self_74[____timerOrder_75] + 1
                ____self_74[____timerOrder_75] = ____self_timerOrder_76
                ____timer_77.order = ____self_timerOrder_76
                timer.running = true
                timer.expired = false
                timer.paused = nil
            end,
            PauseTimer = function(timer)
                if timer.running then
                    timer.paused = self:timerElapsed(timer)
                end
                timer.running = false
            end,
            DestroyTimer = function(timer)
                timer.running = false
                local index = __TS__ArrayIndexOf(self.timers, timer)
                if index >= 0 then
                    __TS__ArraySplice(self.timers, index, 1)
                end
            end,
            TimerGetElapsed = function(timer) return self:timerElapsed(timer) end,
            BlzSendSyncData = function(prefix, data)
                network[#network + 1] = {
                    sender = self.slot,
                    prefix = prefix,
                    data = __TS__StringSlice(data, 0, SYNC_DATA_LIMIT)
                }
                return true
            end,
            DisplayTextToPlayer = function(player, _x, _y, text)
                if player == self.slot then
                    self:show(text)
                end
            end,
            DisplayTimedTextToPlayer = function(player, _x, _y, _duration, text)
                if player == self.slot then
                    self:show(text)
                end
            end,
            DisplayTextToForce = function(_force, text) return self:show(text) end,
            PreloadGenClear = function()
                self.preload = {}
            end,
            PreloadGenStart = function() return nil end,
            Preload = function(line)
                local ____self_preload_78 = self.preload
                ____self_preload_78[#____self_preload_78 + 1] = line
            end,
            PreloadGenEnd = function(name)
                self.files:set(name, self.preload)
                if name == ____gameFiles.errorFile(self.slot, self.filePrefix) then
                    self:report(self.preload)
                end
                local ____opt_79 = self.stored
                if ____opt_79 ~= nil then
                    ____opt_79.written(name, self.preload)
                end
            end,
            Preloader = function(name)
                local ____temp_83 = self.preloaded:get(name) or self.published:get(name)
                if ____temp_83 == nil then
                    local ____opt_81 = self.stored
                    ____temp_83 = ____opt_81 and ____opt_81.read(name)
                end
                local chunks = ____temp_83
                if chunks == nil then
                    self.missedLookups = self.missedLookups + 1
                    return
                end
                self.preloaded:set(name, chunks)
                do
                    local level = 0
                    while level < #chunks do
                        self.tooltips:set(
                            (tostring(____gameFiles.FILE_IO_ABILITY) .. " ") .. tostring(level),
                            chunks[level + 1] or ""
                        )
                        level = level + 1
                    end
                end
            end,
            BlzSetAbilityTooltip = function(ability, text, level)
                self.tooltips:set(
                    (tostring(ability) .. " ") .. tostring(level),
                    text
                )
            end,
            BlzGetAbilityTooltip = function(ability, level) return self.tooltips:get((tostring(ability) .. " ") .. tostring(level)) or "" end,
            AddSpecialEffect = function(model, x, y) return self:effectAt(model, x, y) end,
            SetCameraPosition = function(x, y)
                self.cameraX = x
                self.cameraY = y
            end,
            GetCameraTargetPositionX = function() return self.cameraX end,
            SetCameraTargetController = function()
                self.scenery.cameraAllowsHotkeyTargetLock = false
            end,
            SetCameraOrientController = function()
                self.scenery.cameraAllowsHotkeyTargetLock = false
            end,
            SetCameraField = function(field, value)
                self.cameraFields[self:cameraField(field)] = value
            end,
            GetCameraField = function(field) return self.cameraFields[self:cameraField(field)] or 0 end,
            SetCineFilterTexture = function(texture)
                self.cineFilter.texture = texture
            end,
            SetCineFilterBlendMode = function(mode)
                self.cineFilter.blendMode = type(mode) == "number" and (BLEND_MODES[mode + 1] or "BLEND_MODE_NONE") or tostring(mode)
            end,
            SetCineFilterTexMapFlags = function(flags)
                self.cineFilter.texMapFlags = flags
            end,
            SetCineFilterStartUV = function(minU, minV, maxU, maxV)
                self.cineFilter.startUV = {minU, minV, maxU, maxV}
            end,
            SetCineFilterEndUV = function(minU, minV, maxU, maxV)
                self.cineFilter.endUV = {minU, minV, maxU, maxV}
            end,
            SetCineFilterStartColor = function(red, green, blue, alpha)
                self.cineFilter.startColor = {red, green, blue, alpha}
            end,
            SetCineFilterEndColor = function(red, green, blue, alpha)
                self.cineFilter.endColor = {red, green, blue, alpha}
            end,
            SetCineFilterDuration = function(duration)
                self.cineFilter.duration = duration
            end,
            DisplayCineFilter = function(flag)
                self.cineFilter.shown = flag and self.frame or nil
            end,
            IsCineFilterDisplayed = function() return self.cineFilter.shown ~= nil end,
            CreateSound = function(source, loop) return self:sound(source, nil, loop) end,
            CreateSoundFromLabel = function(label, loop) return self:sound(nil, label, loop) end,
            CreateSoundFilenameWithLabel = function(source, loop, _is3D, _stop, _fadeIn, _fadeOut, label) return self:sound(source, label, loop) end,
            SetSoundDuration = function(handle, duration)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.duration = math.max(0, duration)
                end
            end,
            GetSoundDuration = function(handle)
                local ____opt_84 = self.sounds:get(handle)
                return ____opt_84 and ____opt_84.duration or 0
            end,
            GetSoundIsPlaying = function(handle)
                local sound = self.sounds:get(handle)
                return sound ~= nil and sound.playing and not sound.killWhenDone
            end,
            KillSoundWhenDone = function(handle)
                local sound = self.sounds:get(handle)
                if sound == nil then
                    return
                end
                sound.killWhenDone = true
                if not sound.playing then
                    self.sounds:delete(handle)
                end
            end,
            StopSound = function(handle, killWhenDone)
                local sound = self.sounds:get(handle)
                if sound == nil then
                    return
                end
                self:stopAudio(sound)
                if killWhenDone or sound.killWhenDone then
                    self.sounds:delete(handle)
                end
            end,
            SetSoundParamsFromLabel = function(handle, label)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.label = label
                end
            end,
            SetSoundVolume = function(handle, volume)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.volume = math.max(
                        0,
                        math.min(127, volume)
                    )
                    if sound.playing then
                        self:cue(sound, "volume")
                    end
                end
            end,
            PlayMusic = function(source) return self:playMusic(source) end,
            PlayMusicEx = function(source) return self:playMusic(source) end,
            PlayThematicMusic = function(source) return self:playMusic(source, false) end,
            StopMusic = function()
                if self.music ~= nil then
                    self:stopAudio(self.music)
                end
            end,
            ResumeMusic = function()
                if self.music == nil or self.music.playing then
                    return
                end
                self.music.playing = true
                self:cue(self.music, "start")
            end,
            SetMusicVolume = function(volume)
                self.musicVolume = math.max(
                    0,
                    math.min(127, volume)
                )
                if self.music ~= nil then
                    self.music.volume = self.musicVolume
                    if self.music.playing then
                        self:cue(self.music, "volume")
                    end
                end
            end,
            SetSoundPitch = function(handle, pitch)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.pitch = pitch
                end
            end,
            SetSoundPosition = function(handle, x, y, z)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.x = x
                    sound.y = y
                    sound.z = z
                    sound.unit = nil
                end
            end,
            AttachSoundToUnit = function(handle, unit)
                local sound = self.sounds:get(handle)
                if sound ~= nil then
                    sound.unit = unit
                end
            end,
            StartSound = function(handle) return self:startSound(handle) end,
            StartSoundEx = function(handle) return self:startSound(handle) end,
            AddSpecialEffectLoc = function(model) return self:effectAt(model, 0, 0) end,
            AddSpecialEffectTarget = function(model) return self:effectAt(model, 0, 0) end,
            DestroyEffect = function(effect) return self:destroyEffect(effect) end,
            BlzRemoveEffect = function(effect)
                if self:liveEffect(effect) ~= nil then
                    self.effects:delete(effect)
                end
            end,
            BlzSetSpecialEffectAnimationBlendTime = function(effect, time)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.animationBlendTime = time
                end
            end,
            BlzSetSpecialEffectAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    __TS__ArraySetLength(pose.queuedAnimations, 0)
                    self:playEffect(effect, animation)
                end
            end,
            BlzQueueSpecialEffectAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    local ____pose_queuedAnimations_86 = pose.queuedAnimations
                    ____pose_queuedAnimations_86[#____pose_queuedAnimations_86 + 1] = animation
                end
            end,
            BlzSetSpecialEffectPosition = function(effect, x, y, z)
                local pose = self:liveEffect(effect)
                if pose == nil then
                    return
                end
                pose.x = x
                pose.y = y
                pose.z = z
            end,
            BlzSetSpecialEffectX = function(effect, x)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.x = x
                end
            end,
            BlzSetSpecialEffectY = function(effect, y)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.y = y
                end
            end,
            BlzSetSpecialEffectZ = function(effect, z)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.z = z
                end
            end,
            BlzSetSpecialEffectAlpha = function(effect, alpha)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.alpha = alpha
                end
            end,
            BlzSetSpecialEffectScale = function(effect, scale)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.scale = scale
                end
            end,
            BlzSetSpecialEffectTimeScale = function(effect, timeScale)
                local pose = self:liveEffect(effect)
                if pose == nil then
                    return
                end
                self:settleEffect(pose)
                pose.timeScale = timeScale
            end,
            BlzSetSpecialEffectTime = function(effect, time)
                local pose = self:liveEffect(effect)
                if pose == nil then
                    return
                end
                self:settleEffect(pose)
                ____animation.seekAnimation(pose, time)
            end,
            BlzPlaySpecialEffect = function(effect, animation) return self:playEffect(effect, animation) end,
            BlzPlaySpecialEffectWithTimeScale = function(effect, animation, timeScale) return self:playEffect(effect, animation, timeScale) end,
            BlzSpecialEffectClearSubAnimations = function(effect)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    __TS__ArraySetLength(pose.subAnimations, 0)
                end
            end,
            BlzSpecialEffectAddSubAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose ~= nil and not __TS__ArrayIncludes(pose.subAnimations, animation) then
                    local ____pose_subAnimations_87 = pose.subAnimations
                    ____pose_subAnimations_87[#____pose_subAnimations_87 + 1] = animation
                end
            end,
            BlzSpecialEffectRemoveSubAnimation = function(effect, animation)
                local pose = self:liveEffect(effect)
                if pose == nil then
                    return
                end
                local index = __TS__ArrayIndexOf(pose.subAnimations, animation)
                if index >= 0 then
                    __TS__ArraySplice(pose.subAnimations, index, 1)
                end
            end,
            BlzSetSpecialEffectOrientation = function(effect, yaw, pitch, roll)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.yaw = yaw
                    pose.pitch = pitch
                    pose.roll = roll
                    pose.matrixScale = {1, 1, 1}
                    pose.flat = false
                end
            end,
            BlzSetSpecialEffectYaw = function(effect, yaw)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.yaw = yaw
                    pose.matrixScale = {1, 1, 1}
                    pose.flat = false
                end
            end,
            BlzSetSpecialEffectPitch = function(effect, pitch)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.pitch = pitch
                    pose.matrixScale = {1, 1, 1}
                    pose.flat = false
                end
            end,
            BlzSetSpecialEffectRoll = function(effect, roll)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.roll = roll
                    pose.matrixScale = {1, 1, 1}
                    pose.flat = false
                end
            end,
            BlzSetSpecialEffectColor = function(effect, r, g, b)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.color = {r, g, b}
                end
            end,
            BlzSetSpecialEffectColorByPlayer = function(effect, player)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.teamColor = player
                end
            end,
            BlzSetSpecialEffectMatrixScale = function(effect, x, y, z)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.matrixScale = {
                        __wispF32Multiply(pose.matrixScale[1], x),
                        __wispF32Multiply(pose.matrixScale[2], y),
                        __wispF32Multiply(pose.matrixScale[3], z)
                    }
                    pose.flat = __TS__ArrayIncludes(pose.matrixScale, 0)
                end
            end,
            BlzResetSpecialEffectMatrix = function(effect)
                local pose = self:liveEffect(effect)
                if pose ~= nil then
                    pose.flat = false
                    pose.matrixScale = {1, 1, 1}
                    pose.yaw = 0
                    pose.pitch = 0
                    pose.roll = 0
                end
            end,
            BlzGetLocalSpecialEffectX = function(effect)
                local ____opt_88 = self.effects:get(effect)
                return ____opt_88 and ____opt_88.x or 0
            end,
            BlzGetLocalSpecialEffectY = function(effect)
                local ____opt_90 = self.effects:get(effect)
                return ____opt_90 and ____opt_90.y or 0
            end,
            BlzGetLocalSpecialEffectZ = function(effect)
                local ____opt_92 = self.effects:get(effect)
                return ____opt_92 and ____opt_92.z or 0
            end,
            I2S = function(n) return ____exports.describeNumber(n) end,
            R2S = function(n) return fixed(n, 3) end,
            R2SW = function(n, width, precision)
                local text = fixed(n, precision > 0 and precision or 0)
                if precision <= 0 then
                    text = text .. ".0"
                end
                while #text < width + 1 do
                    text = " " .. text
                end
                return text
            end,
            R2I = function(n) return n < 0 and math.ceil(n) or math.floor(n) end,
            I2R = function(n) return n end,
            S2I = function(text)
                local value = leadingNumber(text, false)
                return value < 0 and math.ceil(value) or math.floor(value)
            end,
            S2R = function(text) return leadingNumber(text, true) end,
            SubString = function(text, start, ____end) return __TS__StringSubstring(text, start, ____end) end,
            StringLength = function(text) return #text end,
            SquareRoot = function(n) return math.sqrt(n) end,
            Atan2 = function(y, x) return math.atan(y, x) end,
            BlzBitAnd = function(a, b) return a & b end,
            BlzBitOr = function(a, b) return a | b end,
            BlzBitXor = function(a, b) return a ~ b end
        }
    )
end
function HeadlessClient.prototype.preloadedFiles(self)
    return {__TS__Spread(self.preloaded:keys())}
end
function HeadlessClient.prototype.effectPoses(self, options)
    if options == nil then
        options = {}
    end
    local poses = {}
    for ____, pose in __TS__Iterator(self.effects:values()) do
        if options.visibleOnly ~= true or pose.alpha > 0 and pose.scale > 0 and not pose.flat then
            self:settleEffect(pose)
            poses[#poses + 1] = __TS__ObjectAssign(
                {},
                pose,
                {
                    subAnimations = {table.unpack(pose.subAnimations)},
                    animationBlend = copyBlend(pose.animationBlend),
                    color = {table.unpack(pose.color)},
                    matrixScale = {table.unpack(pose.matrixScale)}
                }
            )
        end
    end
    return poses
end
function HeadlessClient.prototype.cineFilterPose(self)
    local filter = self.cineFilter
    if filter.shown == nil then
        return nil
    end
    local share = filter.duration <= 0 and 1 or math.min(1, (self.frame - filter.shown) / ____frameRate.FRAMES_PER_SECOND / filter.duration)
    local function mix(from, to)
        return __TS__ArrayMap(
            {0, 1, 2, 3},
            function(____, i) return (from[i + 1] or 0) + ((to[i + 1] or 0) - (from[i + 1] or 0)) * share end
        )
    end
    return {
        texture = filter.texture,
        blendMode = filter.blendMode,
        texMapFlags = filter.texMapFlags,
        color = mix(filter.startColor, filter.endColor),
        uv = mix(filter.startUV, filter.endUV)
    }
end
function HeadlessClient.prototype.cameraPose(self)
    return {
        x = self.cameraX,
        y = self.cameraY,
        fields = __TS__ObjectAssign({}, self.cameraFields)
    }
end
function HeadlessClient.prototype.unitPoses(self)
    local poses = {}
    for ____, unit in __TS__Iterator(self.units:values()) do
        poses[#poses + 1] = {
            handle = unit.handle,
            typeId = unit.typeId,
            owner = unit.owner,
            x = unit.x,
            y = unit.y,
            z = unit.z,
            facing = unit.facing,
            scale = {table.unpack(unit.scale)},
            alpha = unit.alpha,
            color = {table.unpack(unit.color)},
            teamColor = unit.teamColor,
            timeScale = unit.timeScale,
            visible = unit.visible,
            animation = unit.animation,
            subAnimations = {table.unpack(unit.subAnimations)},
            animationElapsed = unit.animationElapsed,
            animationClock = unit.animationClock,
            animationBlendTime = unit.animationBlendTime,
            animationBlend = copyBlend(unit.animationBlend)
        }
    end
    return poses
end
function HeadlessClient.prototype.run(self, body)
    local ____opt_94 = self.scope
    if ____opt_94 ~= nil then
        ____opt_94.enter(self)
    end
    do
        local ____try, ____error = pcall(function()
            body()
        end)
        do
            local ____opt_96 = self.scope
            if ____opt_96 ~= nil then
                ____opt_96.leave(self)
            end
        end
        if not ____try then
            error(____error, 0)
        end
    end
end
function HeadlessClient.prototype.fire(self, trigger, event)
    if trigger.destroyed then
        return
    end
    if event.player ~= nil then
        self.event.player = event.player
    end
    if event.syncPrefix ~= nil then
        self.event.syncPrefix = event.syncPrefix
    end
    if event.syncData ~= nil then
        self.event.syncData = event.syncData
    end
    if event.chat ~= nil then
        self.event.chat = event.chat
    end
    if event.key ~= nil then
        self.event.key = event.key
    end
    if event.frame ~= nil then
        self.event.frame = event.frame
    end
    if event.frameEvent ~= nil then
        self.event.frameEvent = event.frameEvent
    end
    local running = trigger.running
    local interrupted = trigger.interrupted
    trigger.running = true
    trigger.interrupted = false
    do
        local ____try, ____error = pcall(function()
            for ____, action in ipairs(trigger.actions) do
                if trigger.interrupted then
                    break
                end
                action()
            end
        end)
        do
            trigger.running = running
            trigger.interrupted = interrupted
        end
        if not ____try then
            error(____error, 0)
        end
    end
end
function HeadlessClient.prototype.step(self, draw)
    if draw == nil then
        draw = true
    end
    self.frame = self.frame + 1
    ____frameRate.steppedFrames.count = ____frameRate.steppedFrames.count + 1
    self.abilities:tick(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    self.scenery:tick(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    self.textTags:tick(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    if draw then
        self:draw(__wispF32Divide(1, ____frameRate.FRAMES_PER_SECOND))
    end
    local expired = 0
    while true do
        local ____temp_101 = expired < #self.dying
        if ____temp_101 then
            local ____self_frame_100 = self.frame
            local ____opt_98 = self.dying[expired + 1]
            ____temp_101 = ____self_frame_100 - (____opt_98 and ____opt_98.destroyed or self.frame) >= 5 * ____frameRate.FRAMES_PER_SECOND
        end
        if not ____temp_101 then
            break
        end
        expired = expired + 1
    end
    if expired > 0 then
        for ____, pose in ipairs(__TS__ArraySplice(self.dying, 0, expired)) do
            if self.effects:get(pose.handle) == pose then
                self.effects:delete(pose.handle)
            end
        end
    end
    for ____, sound in __TS__Iterator(self.sounds:values()) do
        do
            if not sound.playing or sound.looping then
                goto __continue517
            end
            sound.elapsed = sound.elapsed + sound.pitch * 1000 / ____frameRate.FRAMES_PER_SECOND
            if sound.elapsed < sound.duration then
                goto __continue517
            end
            self:stopAudio(sound)
            if sound.killWhenDone then
                self.sounds:delete(sound.handle)
            end
        end
        ::__continue517::
    end
    self:run(function() return self:runDueTimers() end)
    for ____, unit in ipairs(self.removals) do
        unit.removed = true
    end
    self.removals = {}
end
function HeadlessClient.prototype.draw(self, seconds)
    local step = seconds
    if step ~= self.effectDrawSeconds then
        for ____, pose in __TS__Iterator(self.effects:values()) do
            self:settleEffect(pose)
        end
        self.effectDrawSeconds = step
    end
    self.effectDraws = self.effectDraws + 1
    for ____, unit in __TS__Iterator(self.units:values()) do
        ____animation.advanceAnimation(unit, unit.timeScale, seconds)
    end
end
function HeadlessClient.prototype.timerElapsed(self, timer)
    if timer.paused ~= nil then
        return timer.paused
    end
    if timer.expired then
        return timer.timeout
    end
    if not timer.running then
        return 0
    end
    local remaining = timer.due > self.now and ____binary32.subtractFloat32TowardZero(timer.due, self.now) or 0
    return remaining < timer.period and ____binary32.subtractFloat32TowardZero(timer.period, remaining) or 0
end
function HeadlessClient.prototype.runDueTimers(self)
    local ____end = frameEnd(self.frame)
    self.now = ____end
    do
        while true do
            do
                local next
                for ____, timer in ipairs(self.timers) do
                    do
                        if not timer.running or timer.callback == nil or timer.due > ____end then
                            goto __continue538
                        end
                        if next == nil or timer.due < next.due or timer.due == next.due and timer.order < next.order then
                            next = timer
                        end
                    end
                    ::__continue538::
                end
                local hitIndex = -1
                do
                    local index = 0
                    while index < #self.spellHits do
                        local hit = self.spellHits[index + 1]
                        local earliest = self.spellHits[hitIndex + 1]
                        if hit ~= nil and hit.due <= ____end and (next == nil or hit.due <= next.due) and (earliest == nil or hit.due < earliest.due) then
                            hitIndex = index
                        end
                        index = index + 1
                    end
                end
                local hit = self.spellHits[hitIndex + 1]
                if hit ~= nil then
                    __TS__ArraySplice(self.spellHits, hitIndex, 1)
                    self.now = hit.due
                    if self.units:has(hit.target) and not hit.target.dead then
                        self:setLife(
                            hit.target,
                            ____binary32.subtractFloat32(
                                self:unitValue(hit.target, "life"),
                                hit.damage
                            )
                        )
                    end
                    goto __continue537
                end
                if next == nil or next.callback == nil then
                    break
                end
                self.now = next.due
                if next.periodic then
                    next.due = after(next.due, next.period)
                else
                    next.running = false
                    next.expired = true
                end
                self.event.timer = next
                do
                    local ____try, ____error = pcall(function()
                        next.callback()
                    end)
                    do
                        self.now = ____end
                    end
                    if not ____try then
                        error(____error, 0)
                    end
                end
            end
            ::__continue537::
        end
    end
end
function HeadlessClient.prototype.deliverSync(self, ____bindingPattern0)
    local data
    local prefix
    local sender
    sender = ____bindingPattern0.sender
    prefix = ____bindingPattern0.prefix
    data = ____bindingPattern0.data
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "sync" and registration.player == sender and registration.prefix == prefix then
                self:fire(registration.trigger, {player = sender, syncPrefix = prefix, syncData = data})
            end
        end
    end)
end
function HeadlessClient.prototype.chat(self, sender, message)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            do
                if registration.kind ~= "chat" or registration.player ~= sender then
                    goto __continue559
                end
                local ____registration_exact_102
                if registration.exact then
                    ____registration_exact_102 = message == registration.text
                else
                    ____registration_exact_102 = __TS__StringIncludes(message, registration.text)
                end
                if ____registration_exact_102 then
                    self:fire(registration.trigger, {player = sender, chat = message})
                end
            end
            ::__continue559::
        end
    end)
end
function HeadlessClient.prototype.key(self, sender, key, meta, down)
    if sender == self.slot then
        self:hold(key, meta, down)
    end
    self:keyEvent(sender, key, meta, down)
end
function HeadlessClient.prototype.hold(self, key, meta, down)
    self.heldMeta = meta
    if down then
        self.heldKeys:add(key)
    else
        self.heldKeys:delete(key)
    end
end
function HeadlessClient.prototype.keyEvent(self, sender, key, meta, down)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "key" and registration.player == sender and registration.key == key and registration.meta == meta and registration.down == down then
                self:fire(registration.trigger, {player = sender, key = key})
            end
        end
    end)
end
function HeadlessClient.prototype.type(self, text)
    return self.frames:type(text)
end
function HeadlessClient.prototype.clickTarget(self, x, y)
    local click = self.natives.FRAMEEVENT_CONTROL_CLICK
    return self.frames:at(
        x,
        y,
        function(frame) return __TS__ArraySome(
            self.registrations,
            function(____, registration) return registration.kind == "frame" and registration.frame == frame and registration.event == click and not registration.trigger.destroyed end
        ) end
    )
end
function HeadlessClient.prototype.frameEvent(self, sender, id, event)
    self:run(function()
        for ____, registration in ipairs({table.unpack(self.registrations)}) do
            if registration.kind == "frame" and registration.frame.id == id and registration.event == event then
                self:fire(registration.trigger, {player = sender, frame = registration.frame, frameEvent = event})
            end
        end
    end)
end
function HeadlessClient.prototype.callCount(self)
    return self.forgotten + #self.log
end
function HeadlessClient.prototype.forget(self, count)
    local hash = self.forgottenHash
    do
        local index = 0
        while index < count do
            local call = self.log[index + 1]
            if call ~= nil then
                hash = mixCall(hash, call)
            end
            index = index + 1
        end
    end
    self.forgottenHash = hash
    __TS__ArraySplice(self.log, 0, count)
    self.forgotten = self.forgotten + count
end
function HeadlessClient.prototype.checksum(self)
    local hash = self.forgottenHash
    for ____, call in ipairs(self.log) do
        hash = mixCall(hash, call)
    end
    return ____exports.describeNumber(hash)
end
return ____exports
