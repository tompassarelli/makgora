local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____frameRing = require("src.netcode.frameRing")
local ____wire = require("src.netcode.wire")
____exports.FUTURE_LIMIT = 128
____exports.LAST_FRAME = ____wire.WIRE_MAX_VALUE
____exports.NO_FRAME = ____exports.LAST_FRAME + 1
____exports.NO_EPOCH = -1
____exports.STILL_PLAYING = 2147483647
function ____exports.ledgerCapacity(history)
    return history + 2 * ____exports.FUTURE_LIMIT
end
function ____exports.inputLedger(codec, players, history)
    local rings = {}
    local through = {}
    local goneAfter = {}
    local lowestAccepted = {}
    do
        local player = 0
        while player < players do
            rings[#rings + 1] = ____frameRing.frameRing(
                codec,
                ____exports.ledgerCapacity(history)
            )
            through[#through + 1] = 0
            goneAfter[#goneAfter + 1] = ____exports.STILL_PLAYING
            lowestAccepted[#lowestAccepted + 1] = ____exports.NO_FRAME
            player = player + 1
        end
    end
    return {
        codec = codec,
        rings = rings,
        through = through,
        goneAfter = goneAfter,
        lowestAccepted = lowestAccepted,
        idle = codec.neutral(),
        epoch = ____exports.NO_EPOCH,
        participants = 0,
        retainedFrom = 1,
        consumed = 0,
        known = 0
    }
end
function ____exports.allParticipants(players)
    return (1 << players) - 1
end
function ____exports.isActive(ledger, player)
    return player >= 0 and player < #ledger.rings and ledger.participants & 1 << player ~= 0
end
function ____exports.isPlaying(ledger, player)
    return ____exports.isActive(ledger, player) and ____lookup.at(ledger.goneAfter, player) == ____exports.STILL_PLAYING
end
function ____exports.beginEpoch(ledger, epoch, firstFrame, delay, participants)
    local players = #ledger.rings
    if participants < 0 or participants > ____exports.allParticipants(players) or epoch < 0 or epoch <= ledger.epoch then
        return false
    end
    if firstFrame < 1 or firstFrame > ____exports.LAST_FRAME or delay < 0 or delay > ____exports.FUTURE_LIMIT or delay > 0 and firstFrame > ____exports.LAST_FRAME - (delay - 1) then
        return false
    end
    ledger.participants = participants
    ledger.epoch = epoch
    ledger.retainedFrom = firstFrame
    ledger.consumed = firstFrame - 1
    ledger.known = delay > 0 and firstFrame + delay - 1 or firstFrame - 1
    local neutral = ledger.codec.neutral()
    do
        local player = 0
        while player < players do
            do
                ____frameRing.ringClear(____lookup.at(ledger.rings, player))
                ledger.goneAfter[player + 1] = ____exports.STILL_PLAYING
                ledger.lowestAccepted[player + 1] = ____exports.NO_FRAME
                ledger.through[player + 1] = ledger.known
                if not ____exports.isActive(ledger, player) then
                    goto __continue13
                end
                do
                    local index = 0
                    while index < delay do
                        ____frameRing.ringStore(
                            ledger.codec,
                            ____lookup.at(ledger.rings, player),
                            firstFrame + index,
                            neutral
                        )
                        index = index + 1
                    end
                end
            end
            ::__continue13::
            player = player + 1
        end
    end
    return true
end
local function frontier(ledger)
    local known = ____exports.STILL_PLAYING
    local latest = 0
    do
        local player = 0
        while player < #ledger.through do
            do
                if not ____exports.isActive(ledger, player) then
                    goto __continue19
                end
                local through = ____lookup.at(ledger.through, player)
                if through > latest then
                    latest = through
                end
                if ____exports.isPlaying(ledger, player) and through < known then
                    known = through
                end
            end
            ::__continue19::
            player = player + 1
        end
    end
    return known == ____exports.STILL_PLAYING and latest or known
end
function ____exports.knownThrough(ledger)
    return ledger.known
end
local function advanceKnown(ledger)
    local known = frontier(ledger)
    if known > ledger.known then
        ledger.known = known
    end
end
function ____exports.acceptedRow(ledger, player, frame)
    if not ____exports.isActive(ledger, player) or frame < ledger.retainedFrom or frame > ____exports.LAST_FRAME then
        return nil
    end
    return frame > ____lookup.at(ledger.goneAfter, player) and ledger.idle or ____frameRing.ringRow(
        ____lookup.at(ledger.rings, player),
        frame
    )
end
function ____exports.leaveLedger(ledger, player)
    if not ____exports.isActive(ledger, player) then
        return ____exports.STILL_PLAYING
    end
    if ____exports.isPlaying(ledger, player) then
        ledger.goneAfter[player + 1] = ____lookup.at(ledger.through, player)
        advanceKnown(ledger)
    end
    return ____lookup.at(ledger.goneAfter, player)
end
function ____exports.markConsumed(ledger, epoch, frame)
    if epoch ~= ledger.epoch or frame > ledger.known or frame ~= ledger.consumed + 1 then
        return false
    end
    ledger.consumed = frame
    return true
end
function ____exports.discardThrough(ledger, epoch, frame)
    if epoch ~= ledger.epoch or frame < ledger.retainedFrom - 1 or frame > ledger.consumed then
        return false
    end
    do
        local old = ledger.retainedFrom
        while old <= frame do
            for ____, ring in ipairs(ledger.rings) do
                ____frameRing.ringRelease(ring, old)
            end
            old = old + 1
        end
    end
    ledger.retainedFrom = frame + 1
    return true
end
local function check(ledger, ring, frame, row)
    if frame < ledger.retainedFrom then
        return "outOfHistory"
    end
    if frame - ledger.known > ____exports.FUTURE_LIMIT then
        return "tooFarAhead"
    end
    if frame - ledger.retainedFrom >= #ring.frames then
        return "storageFull"
    end
    local stored = ____frameRing.ringRow(ring, frame)
    if stored ~= nil then
        return ledger.codec.same(stored, row) and "accepted" or "conflict"
    end
    return ____frameRing.ringVacant(ring, frame) and "accepted" or "storageFull"
end
function ____exports.acceptRows(ledger, sender, epoch, firstFrame, rows, count)
    local ring = ledger.rings[sender + 1]
    if ring == nil or not ____exports.isActive(ledger, sender) then
        return "wrongSender"
    end
    if count < 1 or firstFrame < 1 or firstFrame > ____exports.LAST_FRAME - (count - 1) then
        return "malformed"
    end
    if epoch ~= ledger.epoch then
        return "wrongEpoch"
    end
    if not ____exports.isPlaying(ledger, sender) then
        return "gone"
    end
    do
        local index = 0
        while index < count do
            local receipt = check(
                ledger,
                ring,
                firstFrame + index,
                ____lookup.at(rows, index)
            )
            if receipt ~= "accepted" then
                return receipt
            end
            index = index + 1
        end
    end
    do
        local index = 0
        while index < count do
            ____frameRing.ringStore(
                ledger.codec,
                ring,
                firstFrame + index,
                ____lookup.at(rows, index)
            )
            index = index + 1
        end
    end
    local through = ____lookup.at(ledger.through, sender)
    while through < ____exports.LAST_FRAME and ____frameRing.ringRow(ring, through + 1) ~= nil do
        through = through + 1
    end
    ledger.through[sender + 1] = through
    advanceKnown(ledger)
    if firstFrame < ____lookup.at(ledger.lowestAccepted, sender) then
        ledger.lowestAccepted[sender + 1] = firstFrame
    end
    return "accepted"
end
function ____exports.takeLowestAccepted(ledger, sender)
    local lowest = ____lookup.at(ledger.lowestAccepted, sender)
    ledger.lowestAccepted[sender + 1] = ____exports.NO_FRAME
    return lowest
end
return ____exports
