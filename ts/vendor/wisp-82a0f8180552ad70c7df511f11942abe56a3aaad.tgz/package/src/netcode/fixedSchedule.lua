local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____capture = require("src.netcode.capture")
local ____frameRing = require("src.netcode.frameRing")
local ____ledger = require("src.netcode.ledger")
function ____exports.fixedSchedule(codec, players, history)
    return {
        codec = codec,
        ledger = ____ledger.inputLedger(codec, players, history),
        pending = ____frameRing.frameRing(
            codec,
            ____ledger.ledgerCapacity(history)
        ),
        history = history,
        epoch = ____ledger.NO_EPOCH,
        delay = 0,
        next = 1,
        prepared = nil
    }
end
function ____exports.beginFixedEpoch(schedule, epoch, delay, participants)
    if not ____ledger.beginEpoch(
        schedule.ledger,
        epoch,
        1,
        delay,
        participants
    ) then
        return false
    end
    schedule.epoch = epoch
    schedule.delay = delay
    schedule.next = 1
    schedule.prepared = nil
    ____frameRing.ringClear(schedule.pending)
    return true
end
function ____exports.captureTarget(frame, delay)
    return frame >= 1 and frame <= ____ledger.LAST_FRAME - delay and frame + delay or nil
end
function ____exports.captureFixed(schedule, epoch, sample)
    if epoch ~= schedule.epoch then
        return ____capture.Capture.wrongEpoch
    end
    local target = ____exports.captureTarget(schedule.next, schedule.delay)
    if target == nil then
        return ____capture.Capture.frameExhausted
    end
    if ____frameRing.ringRow(schedule.pending, target) ~= nil then
        return ____capture.Capture.alreadyCaptured
    end
    if not ____frameRing.ringVacant(schedule.pending, target) then
        return ____capture.Capture.pendingFull
    end
    ____frameRing.ringStore(schedule.codec, schedule.pending, target, sample)
    return ____capture.Capture.captured
end
function ____exports.fixedPending(schedule, epoch, frame)
    if epoch ~= schedule.epoch or frame < schedule.ledger.retainedFrom or frame > ____ledger.LAST_FRAME then
        return nil
    end
    return ____frameRing.ringRow(schedule.pending, frame)
end
function ____exports.mayAdvanceFixed(schedule)
    return schedule.epoch ~= ____ledger.NO_EPOCH and schedule.next <= ____ledger.LAST_FRAME and schedule.next <= schedule.ledger.known
end
function ____exports.readFixed(schedule, epoch, inputs)
    if epoch ~= schedule.epoch or not ____exports.mayAdvanceFixed(schedule) then
        return false
    end
    do
        local slot = 0
        while slot < #inputs do
            local row = ____ledger.acceptedRow(schedule.ledger, slot, schedule.next)
            if row ~= nil then
                schedule.codec.copy(
                    ____lookup.at(inputs, slot),
                    row
                )
            end
            slot = slot + 1
        end
    end
    schedule.prepared = schedule.next
    return true
end
function ____exports.completeFixed(schedule, epoch, frame)
    if epoch ~= schedule.epoch or frame ~= schedule.next or frame ~= schedule.prepared then
        return false
    end
    if not ____ledger.markConsumed(schedule.ledger, epoch, frame) then
        return false
    end
    schedule.prepared = nil
    schedule.next = schedule.next + 1
    local expired = frame - schedule.history
    if expired >= schedule.ledger.retainedFrom then
        ____frameRing.ringRelease(schedule.pending, expired)
        ____ledger.discardThrough(schedule.ledger, epoch, expired)
    end
    return true
end
return ____exports
