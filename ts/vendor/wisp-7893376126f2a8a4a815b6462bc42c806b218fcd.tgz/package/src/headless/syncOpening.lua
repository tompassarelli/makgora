local ____lualib = require("lualib_bundle")
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local ____frameRate = require("src.headless.frameRate")
function ____exports.openingFlights(options, players)
    if options.link ~= nil then
        return {}
    end
    local arrival = ____frameRate.turnStart(options.callbacks, 1)
    local ____opt_2 = options.delivery
    local ____opt_0 = ____opt_2 and ____opt_2.opening
    return __TS__ArrayMap(
        ____opt_0 and ____opt_0(players) or ({}),
        function(____, message) return {arrival = arrival, message = message} end
    )
end
return ____exports
