/** @noSelfInFile */
import type { SyncMessage } from "./clientTypes";
import { type CallbackTiming } from "./frameRate";
export interface SyncOpening {
    opening?(this: void, players: readonly number[]): readonly SyncMessage[];
}
interface OpeningOptions {
    readonly link?: object;
    readonly delivery?: SyncOpening;
    readonly callbacks?: CallbackTiming;
}
export declare function openingFlights(options: OpeningOptions, players: readonly number[]): readonly {
    readonly arrival: number;
    readonly message: SyncMessage;
}[];
export {};
