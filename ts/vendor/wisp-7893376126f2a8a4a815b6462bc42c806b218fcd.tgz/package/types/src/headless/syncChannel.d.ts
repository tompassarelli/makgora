/** @noSelfInFile */
import type { SyncMessage } from "./clientTypes";
import type { SyncDelivery } from "./lockstep";
import { type CallbackTiming } from "./frameRate";
export { type CallbackTiming, EVEN_CALLBACKS } from "./frameRate";
export interface SyncLatency {
    readonly latencyMs: number;
    readonly turnMs: number;
    readonly extraTurns: readonly number[];
}
export declare const MEASURED_BATTLE_NET: SyncLatency;
export declare const CALLBACK_MS: number;
export declare function syncAgeMs(latency: SyncLatency, frame: number, extraTurns: number): number;
export declare function syncDelivery(latency?: SyncLatency, seed?: number): SyncDelivery;
export interface ReplayedArrival {
    readonly accepts: (this: void, message: SyncMessage) => boolean;
    readonly atMs: number;
}
export declare function replayedDelivery(arrivals: (this: void) => readonly ReplayedArrival[], fallback: SyncDelivery, nowMs: (this: void) => number): SyncDelivery;
export interface TurnBurstModel {
    readonly turnMs: number;
    readonly jitterMs: number;
    readonly hitchChance: number;
    readonly hitchMeanMs: number;
}
export declare const MEASURED_TURN_BURSTS: TurnBurstModel;
export declare function turnBursts(model?: TurnBurstModel, seed?: number): CallbackTiming;
export interface RelayLink {
    readonly rttMs: number;
    readonly loss: number;
    readonly depthTurns: number;
}
export interface RelayOutage {
    readonly atMs: number;
    readonly lengthMs: number;
}
export interface RelayTiming {
    readonly steps: readonly number[];
    readonly jitterMs: number;
    readonly links: readonly RelayLink[];
    readonly outage?: RelayOutage;
}
export declare const MEASURED_RELAY: RelayTiming;
export declare const RELAY_LAG_STOP_MS = 1000;
export declare const RELAY_CATCH_UP_STEP_MS = 4;
export declare const RELAY_SLEW_HOLD_MS = 30000;
export declare const RELAY_MARK_PREFIX = "WISP_RLY";
export declare const RELAY_PROTOCOL_VERSION = 1;
export interface RelayDelivery extends SyncDelivery {
    ageMs(this: void, sender: number, frame: number): number;
}
export declare function relayDelivery(timing?: RelayTiming, seed?: number): RelayDelivery;
export declare function relayCallbacks(timing?: RelayTiming): CallbackTiming;
