local ____exports = {}
local split, scaleByPowerOfTwo, roundLimbs, limbFusedMultiplyAdd, INFINITY, SMALLEST_NORMAL, splitSignificand, splitExponent
local ____lookup = require("src.runtime.lookup")
local ____intMath = require("src.sim.intMath")
local ____limbs = require("src.sim.limbs")
function split(value)
    local normalized = value < 0 and -value or value
    local exponent = -23
    if normalized >= 2 then
        while normalized >= 65536 do
            normalized = normalized * 0x1p-16
            exponent = exponent + 16
        end
        if normalized >= 256 then
            normalized = normalized * 0x1p-8
            exponent = exponent + 8
        end
        if normalized >= 16 then
            normalized = normalized * 0x1p-4
            exponent = exponent + 4
        end
        if normalized >= 4 then
            normalized = normalized * 0x1p-2
            exponent = exponent + 2
        end
        if normalized >= 2 then
            normalized = normalized * 0x1p-1
            exponent = exponent + 1
        end
    elseif normalized < 1 then
        if normalized < SMALLEST_NORMAL then
            normalized = normalized * 16777216
            exponent = exponent - 24
        end
        while normalized < 0x1p-16 do
            normalized = normalized * 65536
            exponent = exponent - 16
        end
        if normalized < 0x1p-8 then
            normalized = normalized * 256
            exponent = exponent - 8
        end
        if normalized < 0x1p-4 then
            normalized = normalized * 16
            exponent = exponent - 4
        end
        if normalized < 0x1p-2 then
            normalized = normalized * 4
            exponent = exponent - 2
        end
        if normalized < 0x1p-1 then
            normalized = normalized * 2
            exponent = exponent - 1
        end
        normalized = normalized * 2
        exponent = exponent - 1
    end
    splitSignificand = normalized * 8388608.0 | 0
    splitExponent = exponent
end
function scaleByPowerOfTwo(value, scale)
    local result = value * 1.0
    local remaining = scale
    if remaining < 0 then
        while remaining <= -16 do
            result = result * 0x1p-16
            remaining = remaining + 16
        end
        while remaining <= -4 do
            result = result * 0x1p-4
            remaining = remaining + 4
        end
        while remaining < 0 do
            result = result * 0x1p-1
            remaining = remaining + 1
        end
    else
        while remaining >= 16 do
            result = result * 65536.0
            remaining = remaining - 16
        end
        while remaining >= 4 do
            result = result * 16.0
            remaining = remaining - 4
        end
        while remaining > 0 do
            result = result * 2.0
            remaining = remaining - 1
        end
    end
    return result
end
function roundLimbs(value, scale, negative)
    local bits = value.high ~= 0 and 48 + ____limbs.bitLength(value.high) or (value.middle ~= 0 and 24 + ____limbs.bitLength(value.middle) or ____limbs.bitLength(value.low))
    if bits == 0 then
        return 0.0
    end
    local shift = bits - 24
    if scale + shift < -149 then
        shift = -149 - scale
    end
    local rounded = value.low
    local resultScale = scale
    if shift >= 2 then
        local truncated = ____limbs.shiftRightJam(value, shift - 2)
        rounded = truncated.middle * 4194304 + truncated.low // 4
        local remainder = truncated.low % 4
        if remainder > 2 or remainder == 2 and rounded % 2 ~= 0 then
            rounded = rounded + 1
        end
        resultScale = resultScale + shift
    elseif shift == 1 then
        rounded = value.middle * 8388608 + value.low // 2
        if value.low % 2 ~= 0 and rounded % 2 ~= 0 then
            rounded = rounded + 1
        end
        resultScale = resultScale + 1
    end
    if resultScale + ____limbs.bitLength(rounded) > 128 then
        return negative and -INFINITY or INFINITY
    end
    local result = scaleByPowerOfTwo(rounded, resultScale)
    return negative and -result or result
end
function limbFusedMultiplyAdd(a, b, c)
    if a == 0 or b == 0 or a - a + (b - b) ~= 0 then
        return a * b + c
    end
    if c - c ~= 0 then
        return c
    end
    split(a)
    local leftSignificand = splitSignificand
    local leftExponent = splitExponent
    split(b)
    local leftHigh = leftSignificand // 4096
    local leftLow = leftSignificand % 4096
    local rightHigh = splitSignificand // 4096
    local rightLow = splitSignificand % 4096
    local first = leftLow * rightLow
    local second = first // 4096 + leftHigh * rightLow + leftLow * rightHigh
    local wideHigh = leftHigh * rightHigh + second // 4096
    local wideLow = first % 4096 + second % 4096 * 4096
    local magnitude = {high = wideHigh // 2, middle = wideHigh % 2 * 8388608 + wideLow // 2, low = wideLow % 2 * 8388608}
    local scale = leftExponent + splitExponent - 23
    local negative = a < 0 ~= (b < 0)
    if c ~= 0 then
        split(c)
        local other = {high = splitSignificand // 2, middle = splitSignificand % 2 * 8388608, low = 0}
        local otherScale = splitExponent - 47
        if scale < otherScale then
            magnitude = ____limbs.shiftRightJam(magnitude, otherScale - scale)
            scale = otherScale
        else
            other = ____limbs.shiftRightJam(other, scale - otherScale)
        end
        if negative == (c < 0) then
            magnitude = ____limbs.addLimbs(magnitude, other)
        elseif ____limbs.lessThan(magnitude, other) then
            magnitude = ____limbs.subtractLimbs(other, magnitude)
            negative = c < 0
        else
            magnitude = ____limbs.subtractLimbs(magnitude, other)
        end
    end
    return roundLimbs(magnitude, scale, negative)
end
local TWO_POWERS = ____limbs.TWO_POWERS
function ____exports.toInt(value)
    return value < 0 and math.ceil(value) or math.floor(value)
end
INFINITY = math.huge
local SIGNIFICAND_UNIT = 0x1p-23
local NORMAL_POWERS = {}
do
    local power = 1.0
    do
        local i = 0
        while i < 126 do
            power = power * 0x1p-1
            i = i + 1
        end
    end
    NORMAL_POWERS[#NORMAL_POWERS + 1] = power
    do
        local i = 1
        while i < 254 do
            power = power * 2.0
            NORMAL_POWERS[#NORMAL_POWERS + 1] = power
            i = i + 1
        end
    end
end
SMALLEST_NORMAL = ____lookup.at(NORMAL_POWERS, 0)
local function normalResult(significand, exponent, negative)
    local power = NORMAL_POWERS[exponent + 149 + 1]
    if power == nil then
        return nil
    end
    local magnitude = significand * SIGNIFICAND_UNIT * power
    return negative and -magnitude or magnitude
end
function ____exports.roundToFloat32(value)
    if value >= SMALLEST_NORMAL and value < INFINITY or value <= -SMALLEST_NORMAL and value > -INFINITY then
        return value * 1.0
    end
    if value == 0 or value ~= value then
        return value
    end
    local negative = value < 0
    local significand = negative and -value or value
    local scale = 1.0
    local exponent = 0
    while significand >= 65536 and exponent <= 111 do
        significand = significand * 0x1p-16
        scale = scale * 65536
        exponent = exponent + 16
    end
    while significand >= 16 and exponent <= 123 do
        significand = significand * 0x1p-4
        scale = scale * 16
        exponent = exponent + 4
    end
    while significand >= 2 and exponent < 127 do
        significand = significand * 0x1p-1
        scale = scale * 2
        exponent = exponent + 1
    end
    if significand >= 2 then
        return negative and -INFINITY or INFINITY
    end
    while significand < 0x1p-16 and exponent >= -110 do
        significand = significand * 65536
        scale = scale * 0x1p-16
        exponent = exponent - 16
    end
    while significand < 0x1p-4 and exponent >= -122 do
        significand = significand * 16
        scale = scale * 0x1p-4
        exponent = exponent - 4
    end
    while significand < 1 and exponent > -126 do
        significand = significand * 2
        scale = scale * 0x1p-1
        exponent = exponent - 1
    end
    local units = significand * 8388608.0
    local rounded = math.floor(units)
    local remainder = units - rounded
    if remainder > 0x1p-1 or remainder == 0x1p-1 and rounded % 2 ~= 0 then
        rounded = rounded + 1
    end
    if exponent == 127 and rounded == 16777216 then
        return negative and -INFINITY or INFINITY
    end
    local result = rounded / 8388608.0 * scale
    return negative and -result or result
end
splitSignificand = 0
splitExponent = 0
local function roundLimbsToNormal(high, low, exponent, sticky, negative)
    local top = high
    local bottom = low
    local scale = exponent
    local inexact = sticky
    while top >= 16777216 do
        if bottom % 2 ~= 0 then
            inexact = true
        end
        bottom = bottom // 2 + top % 2 * 8388608
        top = top // 2
        scale = scale + 1
    end
    local significand
    local remainder
    local half
    if top >= 8388608 then
        significand = top
        remainder = bottom
        half = 8388608
        scale = scale + 24
    elseif inexact then
        significand = top * 2 + bottom // 8388608
        remainder = bottom % 8388608
        half = 4194304
        scale = scale + 23
    else
        if top == 0 then
            top = bottom
            bottom = 0
            scale = scale - 24
        end
        while top < 8388608 do
            top = top * 2 + bottom // 8388608
            bottom = bottom % 8388608 * 2
            scale = scale - 1
        end
        significand = top
        remainder = bottom
        half = 8388608
        scale = scale + 24
    end
    if remainder > half or remainder == half and (inexact or significand % 2 ~= 0) then
        significand = significand + 1
        if significand == 16777216 then
            significand = 8388608
            scale = scale + 1
        end
    end
    return normalResult(significand, scale, negative)
end
local function addToLimbs(high, low, exponent, negative, c)
    split(c)
    local addend = splitSignificand
    local addendNegative = c < 0
    local shift = splitExponent - exponent
    if shift > 30 then
        local guarded = splitExponent - 6
        local part = 0
        local sticky = true
        if shift - 30 < 24 then
            local unit = TWO_POWERS[shift - 30 + 1] or 0
            part = high // unit
            sticky = high - part * unit ~= 0 or low ~= 0
        end
        local sum = addend * 64
        if negative == addendNegative then
            sum = sum + part
        else
            sum = sum - (part + (sticky and 1 or 0))
        end
        local dropped = sum >= 1073741824 and 7 or (sum >= 536870912 and 6 or 5)
        local unit = TWO_POWERS[dropped + 1] or 0
        local significand = sum // unit
        local remainder = sum - significand * unit
        local half = TWO_POWERS[dropped] or 0
        local scale = guarded + dropped
        if remainder > half or remainder == half and (sticky or significand % 2 ~= 0) then
            significand = significand + 1
            if significand == 16777216 then
                significand = 8388608
                scale = scale + 1
            end
        end
        return normalResult(significand, scale, addendNegative)
    end
    local top = high
    local bottom = low
    local sign = negative
    if shift < 0 then
        local part = 0
        local sticky = true
        if -shift < 24 then
            local unit = TWO_POWERS[-shift + 1] or 0
            part = addend // unit
            sticky = addend - part * unit ~= 0
        end
        if negative == addendNegative then
            bottom = bottom + part
            if bottom >= 16777216 then
                bottom = bottom - 16777216
                top = top + 1
            end
        else
            bottom = bottom - (part + (sticky and 1 or 0))
            if bottom < 0 then
                bottom = bottom + 16777216
                top = top - 1
            end
        end
        return roundLimbsToNormal(
            top,
            bottom,
            exponent,
            sticky,
            sign
        )
    end
    local addendHigh
    local addendLow = 0
    if shift >= 24 then
        addendHigh = addend * (TWO_POWERS[shift - 24 + 1] or 0)
    else
        local unit = TWO_POWERS[24 - shift + 1] or 0
        addendHigh = addend // unit
        addendLow = (addend - addendHigh * unit) * (TWO_POWERS[shift + 1] or 0)
    end
    if negative == addendNegative then
        top = top + addendHigh
        bottom = bottom + addendLow
        if bottom >= 16777216 then
            bottom = bottom - 16777216
            top = top + 1
        end
    else
        top = top - addendHigh
        bottom = bottom - addendLow
        if bottom < 0 then
            bottom = bottom + 16777216
            top = top - 1
        end
        if top < 0 then
            if bottom > 0 then
                top = -top - 1
                bottom = 16777216 - bottom
            else
                top = -top
            end
            sign = addendNegative
        elseif top == 0 and bottom == 0 then
            return 0.0
        end
    end
    return roundLimbsToNormal(
        top,
        bottom,
        exponent,
        false,
        sign
    )
end
local function sumOfSplits(aSignificand, aExponent, aNegative, bSignificand, bExponent, bNegative, tiesTowardZero)
    if tiesTowardZero == nil then
        tiesTowardZero = false
    end
    local large = aSignificand
    local largeExponent = aExponent
    local negative = aNegative
    local small = bSignificand
    local smallExponent = bExponent
    if aExponent < bExponent or aExponent == bExponent and aSignificand < bSignificand then
        large = bSignificand
        largeExponent = bExponent
        negative = bNegative
        small = aSignificand
        smallExponent = aExponent
    end
    local same = aNegative == bNegative
    local shift = largeExponent - smallExponent
    local sum
    local exponent
    local sticky = false
    if shift <= 6 then
        local scaled = large * (TWO_POWERS[shift + 1] or 0)
        sum = same and scaled + small or scaled - small
        if sum == 0 then
            return 0.0
        end
        exponent = smallExponent
    elseif shift > 30 then
        return normalResult(large, largeExponent, negative)
    else
        local unit = TWO_POWERS[shift - 6 + 1] or 0
        local part = small // unit
        sticky = small - part * unit ~= 0
        sum = same and large * 64 + part or large * 64 - part - (sticky and 1 or 0)
        exponent = largeExponent - 6
    end
    local significand = sum
    if sum < 16777216 then
        while significand < 8388608 do
            significand = significand * 2
            exponent = exponent - 1
        end
    else
        local dropped
        if sum >= 134217728 then
            dropped = sum >= 1073741824 and 7 or (sum >= 536870912 and 6 or (sum >= 268435456 and 5 or 4))
        else
            dropped = sum >= 67108864 and 3 or (sum >= 33554432 and 2 or 1)
        end
        local unit = TWO_POWERS[dropped + 1] or 0
        significand = sum // unit
        local remainder = sum - significand * unit
        local half = TWO_POWERS[dropped] or 0
        exponent = exponent + dropped
        if remainder > half or remainder == half and (sticky or not tiesTowardZero and significand % 2 ~= 0) then
            significand = significand + 1
            if significand == 16777216 then
                significand = 8388608
                exponent = exponent + 1
            end
        end
    end
    local power = NORMAL_POWERS[exponent + 149 + 1]
    if power == nil then
        return nil
    end
    local magnitude = significand * SIGNIFICAND_UNIT * power
    return negative and -magnitude or magnitude
end
function ____exports.addFloat32(a, b)
    if a == 0 then
        return 1.0 * a + b
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY then
        split(a)
        local result
        if b == 0 then
            result = normalResult(splitSignificand, splitExponent, a < 0)
        else
            local significand = splitSignificand
            local exponent = splitExponent
            split(b)
            result = sumOfSplits(
                significand,
                exponent,
                a < 0,
                splitSignificand,
                splitExponent,
                b < 0
            )
        end
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(1.0, a, b)
end
--- Unit-state writes use halfway differences toward zero; ordinary subtraction keeps nearest-even.
function ____exports.subtractFloat32(a, b, tiesTowardZero)
    if tiesTowardZero == nil then
        tiesTowardZero = false
    end
    if b == 0 then
        return -1.0 * b + a
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY then
        split(b)
        local result
        if a == 0 then
            result = normalResult(splitSignificand, splitExponent, not (b < 0))
        else
            local significand = splitSignificand
            local exponent = splitExponent
            split(a)
            result = sumOfSplits(
                splitSignificand,
                splitExponent,
                a < 0,
                significand,
                exponent,
                not (b < 0),
                tiesTowardZero
            )
        end
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(-1.0, b, a)
end
function ____exports.addFloat32TowardZero(a, b)
    if a == 0 then
        return b
    end
    if b == 0 then
        return a
    end
    split(a)
    local large = splitSignificand
    local exponent = splitExponent
    split(b)
    local small = splitSignificand
    local shift = exponent - splitExponent
    if shift < 0 then
        small = large
        large = splitSignificand
        exponent = splitExponent
        shift = -shift
    end
    local sum = shift > 24 and large or large + small // (TWO_POWERS[shift + 1] or 1)
    if sum >= 16777216 then
        sum = sum // 2
        exponent = exponent + 1
    end
    return normalResult(sum, exponent, false) or a + b
end
function ____exports.subtractFloat32TowardZero(a, b)
    if b == 0 then
        return a
    end
    if a == b then
        return 0.0
    end
    split(a)
    local large = splitSignificand
    local exponent = splitExponent
    split(b)
    local shift = exponent - splitExponent
    local difference
    if shift <= 6 then
        difference = large * (TWO_POWERS[shift + 1] or 1) - splitSignificand
        exponent = splitExponent
    else
        local unit = shift - 6 > 30 and 0 or (TWO_POWERS[shift - 6 + 1] or 0)
        local part = unit == 0 and 0 or splitSignificand // unit
        difference = large * 64 - part - (part * unit == splitSignificand and 0 or 1)
        exponent = exponent - 6
    end
    while difference >= 16777216 do
        difference = difference // 2
        exponent = exponent + 1
    end
    while difference < 8388608 do
        difference = difference * 2
        exponent = exponent - 1
    end
    return normalResult(difference, exponent, false) or a - b
end
local productHigh = 0
local productLow = 0
local productExponent = 0
local function multiplySplit(a, b)
    split(a)
    local left = splitSignificand
    local leftExponent = splitExponent
    split(b)
    local leftHigh = left // 4096
    local leftLow = left - leftHigh * 4096
    local rightHigh = splitSignificand // 4096
    local rightLow = splitSignificand - rightHigh * 4096
    local lowest = leftLow * rightLow
    local middle = lowest // 4096 + leftHigh * rightLow + leftLow * rightHigh
    local high = leftHigh * rightHigh + middle // 4096
    local low = lowest % 4096 + middle % 4096 * 4096
    local exponent = leftExponent + splitExponent
    if high < 8388608 then
        high = high * 2 + low // 8388608
        low = low % 8388608 * 2
        exponent = exponent - 1
    end
    productHigh = high
    productLow = low
    productExponent = exponent
end
function ____exports.multiplyFloat32(a, b)
    if a == 0 or b == 0 then
        return a * b + 0.0
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY then
        multiplySplit(a, b)
        local significand = productHigh
        local exponent = productExponent + 24
        if productLow > 8388608 or productLow == 8388608 and significand % 2 ~= 0 then
            significand = significand + 1
            if significand == 16777216 then
                significand = 8388608
                exponent = exponent + 1
            end
        end
        local result = normalResult(significand, exponent, a < 0 ~= (b < 0))
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(a, b, 0.0)
end
--- a * b rounded toward zero, as Warcraft's raw * rounds (wisp:docs/headless.md#raw-float-rounding); a result outside the normal range rounds to nearest.
function ____exports.multiplyFloat32TowardZero(a, b)
    if a == 0 or b == 0 then
        return a * b + 0.0
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY then
        multiplySplit(a, b)
        local result = normalResult(productHigh, productExponent + 24, a < 0 ~= (b < 0))
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(a, b, 0.0)
end
function ____exports.fusedMultiplyAddFloat32(a, b, c)
    if a == 0 or b == 0 then
        return a * b + c
    end
    if a < INFINITY and a > -INFINITY and b < INFINITY and b > -INFINITY and c < INFINITY and c > -INFINITY then
        multiplySplit(a, b)
        local negative = a < 0 ~= (b < 0)
        local result
        if c == 0 then
            result = roundLimbsToNormal(
                productHigh,
                productLow,
                productExponent,
                false,
                negative
            )
        else
            result = addToLimbs(
                productHigh,
                productLow,
                productExponent,
                negative,
                c
            )
        end
        if result ~= nil then
            return result
        end
    end
    return limbFusedMultiplyAdd(a, b, c)
end
function ____exports.divideFloat32(numerator, denominator)
    if denominator == 0 or numerator - numerator + (denominator - denominator) ~= 0 then
        return numerator / denominator
    end
    if numerator == 0 then
        return numerator
    end
    split(numerator)
    local remainder = splitSignificand
    local exponent = splitExponent
    split(denominator)
    local denominatorSignificand = splitSignificand
    exponent = exponent - splitExponent
    local negative = numerator < 0 ~= (denominator < 0)
    if remainder < denominatorSignificand then
        remainder = remainder * 2
        exponent = exponent - 1
    end
    remainder = remainder - denominatorSignificand
    local quotient = 1
    do
        local chunk = 1
        while chunk <= 4 do
            remainder = remainder * 64
            local digits = remainder // denominatorSignificand
            remainder = remainder - digits * denominatorSignificand
            quotient = quotient * 64 + digits
            chunk = chunk + 1
        end
    end
    remainder = remainder * 4
    local lastDigits = remainder // denominatorSignificand
    remainder = remainder - lastDigits * denominatorSignificand
    quotient = quotient * 4 + lastDigits
    local rounded = quotient // 8
    local roundingBits = quotient % 8
    if roundingBits > 4 or roundingBits == 4 and (remainder ~= 0 or rounded % 2 ~= 0) then
        rounded = rounded + 1
    end
    local scale = exponent - 23
    if exponent < -126 then
        local subnormalShift = exponent + 149
        if subnormalShift < -1 then
            return 0.0
        end
        if subnormalShift == -1 then
            rounded = (quotient ~= 67108864 or remainder ~= 0) and 1 or 0
        else
            local divisor = 1
            do
                local i = 1
                while i <= 26 - subnormalShift do
                    divisor = divisor * 2
                    i = i + 1
                end
            end
            rounded = quotient // divisor
            local roundingRemainder = quotient % divisor
            if roundingRemainder * 2 > divisor or roundingRemainder * 2 == divisor and (remainder ~= 0 or rounded % 2 ~= 0) then
                rounded = rounded + 1
            end
        end
        scale = -149
    elseif rounded == 16777216 then
        rounded = 8388608
        exponent = exponent + 1
        scale = exponent - 23
    end
    if exponent > 127 or exponent == 127 and rounded == 16777216 then
        return negative and -INFINITY or INFINITY
    end
    local result = scaleByPowerOfTwo(rounded, scale)
    return negative and -result or result
end
function ____exports.squareRootFloat32(value)
    if value == 0 or value ~= value then
        return value
    end
    if value < 0 then
        return INFINITY - INFINITY
    end
    if value - value ~= 0 then
        return value
    end
    split(value)
    local significand = splitSignificand
    local exponent = splitExponent + 23
    if exponent % 2 ~= 0 then
        significand = significand * 2
        exponent = exponent - 1
    end
    local high = significand // 2
    local low = significand % 2 * 8388608
    local remainder = 0
    local root = 0
    do
        local i = 0
        while i < 24 do
            local pair = high // 4194304
            high = high % 4194304 * 4 + low // 4194304
            low = low % 4194304 * 4
            remainder = remainder * 4 + pair
            local trial = root * 4 + 1
            root = root * 2
            if remainder >= trial then
                remainder = remainder - trial
                root = root + 1
            end
            i = i + 1
        end
    end
    if remainder > root then
        root = root + 1
    end
    return scaleByPowerOfTwo(root, exponent // 2 - 23)
end
return ____exports
