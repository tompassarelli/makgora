local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__ArraySort = ____lualib.__TS__ArraySort
local __TS__ArrayFlatMap = ____lualib.__TS__ArrayFlatMap
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local __TS__ArrayFrom = ____lualib.__TS__ArrayFrom
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__SetDescriptor = ____lualib.__TS__SetDescriptor
local __TS__ArrayEvery = ____lualib.__TS__ArrayEvery
local ____exports = {}
local CHECKS_PER_PACKET = 4
local Remote = __TS__Class()
Remote.name = "Remote"
function Remote.prototype.____constructor(self, slot)
    self.slot = slot
    self.frontier = 0
    self.ack = 0
    self.done = false
    self.departed = false
    self.lastCompared = 0
    self.incoming = __TS__New(Map)
    self.checks = __TS__New(Map)
end
--- One process's side of a match with up to four humans: its own events by due frame, each peer's as packets bring them, and checksum agreement (wisp:docs/network-model.md).
____exports.TurnLedger = __TS__Class()
local TurnLedger = ____exports.TurnLedger
TurnLedger.name = "TurnLedger"
function TurnLedger.prototype.____constructor(self, ____local, remotes, clock)
    self["local"] = ____local
    self.remotes = remotes
    self.clock = clock
    self.delay = 1
    self.executed = 0
    self.compared = 0
    self.latencies = {}
    self.advertised = 0
    self.outgoing = __TS__New(Map)
    self.localChecks = {}
    self.sent = function(____, frame, event)
        if frame <= self.advertised or frame <= self.executed then
            do
                local ____thrown = __TS__New(
                    Error,
                    ((("an event due at frame " .. tostring(frame)) .. " comes after frame ") .. tostring(math.max(self.advertised, self.executed))) .. " was promised complete"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/turnLedger.ts:93"
                end
                error(____thrown, 0)
            end
        end
        local turn = self.outgoing:get(frame)
        if turn == nil then
            local ____self_1 = self.outgoing
            local ____self_1_set_2 = ____self_1.set
            local ____frame_0 = frame
            turn = {
                at = self.clock(),
                events = {}
            }
            ____self_1_set_2(____self_1, ____frame_0, turn)
        end
        local ____turn_events_3 = turn.events
        ____turn_events_3[#____turn_events_3 + 1] = event
    end
    self.due = function(____, frame)
        if frame ~= self.executed + 1 then
            do
                local ____thrown = __TS__New(
                    Error,
                    (("frame " .. tostring(frame)) .. " runs after frame ") .. tostring(self.executed)
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/turnLedger.ts:101"
                end
                error(____thrown, 0)
            end
        end
        if not self:ready(frame) then
            do
                local ____thrown = __TS__New(
                    Error,
                    ((("frame " .. tostring(frame)) .. " runs before every peer's events for it arrived (they reach frame ") .. tostring(self.remoteFrontier)) .. ")"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/turnLedger.ts:102"
                end
                error(____thrown, 0)
            end
        end
        self.executed = frame
        local ____self_local_6 = self["local"]
        local ____opt_4 = self.outgoing:get(frame)
        local turns = {{slot = ____self_local_6, events = ____opt_4 and ____opt_4.events or ({})}}
        for ____, peer in ipairs(self.peers) do
            do
                local theirs = peer.incoming:get(frame)
                peer.incoming:delete(frame)
                if theirs == nil then
                    goto __continue11
                end
                local ____self_latencies_7 = self.latencies
                ____self_latencies_7[#____self_latencies_7 + 1] = self.clock() - theirs.at
                turns[#turns + 1] = {slot = peer.slot, events = theirs.events}
            end
            ::__continue11::
        end
        self:prune()
        return __TS__ArrayFlatMap(
            __TS__ArraySort(
                turns,
                function(____, a, b) return a.slot - b.slot end
            ),
            function(____, ____bindingPattern0)
                local events
                events = ____bindingPattern0.events
                return events
            end
        )
    end
    self.peers = __TS__ArrayMap(
        remotes,
        function(____, slot) return __TS__New(Remote, slot) end
    )
end
function TurnLedger.prototype.frontierOf(self, slot)
    local ____opt_8 = self:peer(slot)
    return ____opt_8 and ____opt_8.frontier or 0
end
function TurnLedger.prototype.frontier(self)
    return self.executed + self.delay
end
function TurnLedger.prototype.ready(self, frame)
    return frame <= self.remoteFrontier
end
function TurnLedger.prototype.depart(self, slot)
    local peer = self:peer(slot)
    if peer ~= nil then
        peer.departed = true
    end
    self:prune()
end
function TurnLedger.prototype.check(self, frame, checksum)
    local ____self_localChecks_10 = self.localChecks
    ____self_localChecks_10[#____self_localChecks_10 + 1] = {frame, checksum}
    if #self.localChecks > CHECKS_PER_PACKET then
        table.remove(self.localChecks, 1)
    end
    for ____, peer in ipairs(self.peers) do
        self:compare(
            peer,
            frame,
            checksum,
            peer.checks:get(frame)
        )
    end
end
function TurnLedger.prototype.packet(self, done)
    if done == nil then
        done = false
    end
    local frontier = self:frontier()
    self.advertised = math.max(self.advertised, frontier)
    local turns = {}
    local behind = self.peerAck
    local frames = __TS__ArraySort(
        __TS__ArrayFilter(
            {__TS__Spread(self.outgoing:keys())},
            function(____, frame) return frame > behind and frame <= frontier end
        ),
        function(____, a, b) return a - b end
    )
    for ____, frame in ipairs(frames) do
        local turn = self.outgoing:get(frame)
        if turn ~= nil then
            turns[#turns + 1] = {frame = frame, at = turn.at, events = turn.events}
        end
    end
    local acks = __TS__ArrayFrom(
        {length = math.max(
            self["local"],
            table.unpack(self.remotes)
        ) + 1},
        function(____, _, slot)
            local ____opt_11 = self:peer(slot)
            return ____opt_11 and ____opt_11.frontier or 0
        end
    )
    return {
        from = self["local"],
        frontier = frontier,
        acks = acks,
        turns = turns,
        checks = {table.unpack(self.localChecks)},
        done = done
    }
end
function TurnLedger.prototype.receive(self, packet)
    local peer = self:peer(packet.from)
    if peer == nil then
        return
    end
    if packet.done then
        peer.done = true
    end
    peer.ack = math.max(peer.ack, packet.acks[self["local"] + 1] or 0)
    if packet.frontier > peer.frontier then
        for ____, turn in ipairs(packet.turns) do
            if turn.frame > peer.frontier then
                peer.incoming:set(turn.frame, turn)
            end
        end
        peer.frontier = packet.frontier
    end
    for ____, ____value in ipairs(packet.checks) do
        local frame = ____value[1]
        local checksum = ____value[2]
        do
            if peer.checks:has(frame) or frame <= peer.lastCompared then
                goto __continue39
            end
            peer.checks:set(frame, checksum)
            local ____local = __TS__ArrayFind(
                self.localChecks,
                function(____, ____bindingPattern0)
                    local at
                    at = ____bindingPattern0[1]
                    return at == frame
                end
            )
            if ____local ~= nil then
                self:compare(peer, frame, ____local[2], checksum)
            end
        end
        ::__continue39::
    end
    self:prune()
end
function TurnLedger.prototype.peer(self, slot)
    return __TS__ArrayFind(
        self.peers,
        function(____, peer) return peer.slot == slot end
    )
end
function TurnLedger.prototype.present(self)
    return __TS__ArrayFilter(
        self.peers,
        function(____, peer) return not peer.departed end
    )
end
function TurnLedger.prototype.compare(self, peer, frame, ____local, remote)
    if remote == nil then
        return
    end
    self.compared = self.compared + 1
    peer.lastCompared = math.max(peer.lastCompared, frame)
    peer.checks:delete(frame)
    if ____local ~= remote and self.mismatch == nil then
        self.mismatch = {frame = frame, peer = peer.slot, ["local"] = ____local, remote = remote}
    end
end
function TurnLedger.prototype.prune(self)
    local acked = self.peerAck
    for ____, frame in ipairs({__TS__Spread(self.outgoing:keys())}) do
        if frame <= acked and frame <= self.executed then
            self.outgoing:delete(frame)
        end
    end
end
__TS__SetDescriptor(
    TurnLedger.prototype,
    "remoteFrontier",
    {get = function(self)
        return math.min(table.unpack(__TS__ArrayMap(
            self.peers,
            function(____, peer) return peer.frontier end
        )))
    end},
    true
)
__TS__SetDescriptor(
    TurnLedger.prototype,
    "peerAck",
    {get = function(self)
        return math.min(
            math.huge,
            table.unpack(__TS__ArrayMap(
                self:present(),
                function(____, peer) return peer.ack end
            ))
        )
    end},
    true
)
__TS__SetDescriptor(
    TurnLedger.prototype,
    "remoteDone",
    {get = function(self)
        return __TS__ArrayEvery(
            self.peers,
            function(____, peer) return peer.done or peer.departed end
        )
    end},
    true
)
__TS__SetDescriptor(
    TurnLedger.prototype,
    "lastCompared",
    {get = function(self)
        return math.min(
            math.huge,
            table.unpack(__TS__ArrayMap(
                self:present(),
                function(____, peer) return peer.lastCompared end
            ))
        )
    end},
    true
)
return ____exports
