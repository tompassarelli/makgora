local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
--- Whether the map says a match is on (`WispSetPlaying`), so the native window does no background art work and keeps its art until play stops.
____exports.Playing = __TS__Class()
local Playing = ____exports.Playing
Playing.name = "Playing"
function Playing.prototype.____constructor(self)
    self.on = false
end
function Playing.prototype.behaviors(self)
    return {WispSetPlaying = function(playing)
        self.on = playing == true
    end}
end
return ____exports
