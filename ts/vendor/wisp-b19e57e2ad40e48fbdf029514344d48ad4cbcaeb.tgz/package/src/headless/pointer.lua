local ____exports = {}
local ____f32 = require("src.sim.f32")
local UI_HALF_WIDTH = 0xcccccdp-25
local UI_HEIGHT = 0x4ccccdp-23
function ____exports.point(client, x, y, left)
    client.mouseScreenX = x
    client.mouseScreenY = y
    if left == true then
        client.heldMouseButtons:add(client.natives.MOUSE_BUTTON_TYPE_LEFT)
    elseif left == false then
        client.heldMouseButtons:delete(client.natives.MOUSE_BUTTON_TYPE_LEFT)
    end
end
____exports.POINTER_LEFT = 1
____exports.POINTER_RIGHT = 2
local POINTER_MIDDLE = 4
--- The cursor on Warcraft's 0.8 by 0.6 UI screen, Y up: the window draws the 4:3 UI area centred in the window and scaled by the window's height (`layout::pixels` in the window's ui/layout.rs).
function ____exports.uiPoint(reading)
    local scale = UI_HEIGHT / math.max(1, reading.height)
    return {x = UI_HALF_WIDTH + (reading.x - reading.width / 2) * scale, y = UI_HEIGHT - reading.y * scale}
end
--- The cursor in the pixels of a client's screen, Y down, which is what `BlzGetMouseScreenPosX`/`Y` return: the window is mapped by height so the 4:3 area keeps its place whatever the two aspect ratios, and the game's `pointerX`/`pointerY` read back the point the window drew under the cursor.
function ____exports.screenPoint(reading, screen)
    local scale = screen.height / math.max(1, reading.height)
    return {
        x = math.floor((reading.x - reading.width / 2) * scale + screen.width / 2 + 0x1p-1),
        y = math.floor(reading.y * scale + 0x1p-1)
    }
end
--- Feeds one player's window mouse to the clients: the cursor and held buttons are that client's local mouse natives, and a left press and release on the same frame that takes clicks is the player's `FRAMEEVENT_CONTROL_CLICK`,
-- which goes through the lockstep like a key so every client runs the handler on the same frame. The frame under the cursor is the topmost one that takes clicks (`Frames.at`).
function ____exports.createPointerFeed(clients, slot)
    local pressedOn
    return function(reading)
        local client = clients:client(slot)
        local natives = client.natives
        local buttons = {{____exports.POINTER_LEFT, natives.MOUSE_BUTTON_TYPE_LEFT}, {____exports.POINTER_RIGHT, natives.MOUSE_BUTTON_TYPE_RIGHT}, {POINTER_MIDDLE, natives.MOUSE_BUTTON_TYPE_MIDDLE}}
        if reading.inside then
            local screen = ____exports.screenPoint(reading, client.screen)
            client.mouseScreenX = screen.x
            client.mouseScreenY = screen.y
        end
        for ____, ____value in ipairs(buttons) do
            local ____bit = ____value[1]
            local button = ____value[2]
            if reading.held & ____bit ~= 0 then
                client.heldMouseButtons:add(button)
            else
                client.heldMouseButtons:delete(button)
            end
        end
        local at = ____exports.uiPoint(reading)
        if reading.pressed & ____exports.POINTER_LEFT ~= 0 then
            pressedOn = client:clickTarget(at.x, at.y)
        end
        if reading.released & ____exports.POINTER_LEFT ~= 0 then
            local target = client:clickTarget(at.x, at.y)
            if target ~= nil and target == pressedOn then
                clients:click(slot, at.x, at.y)
            end
            pressedOn = nil
        end
    end
end
return ____exports
