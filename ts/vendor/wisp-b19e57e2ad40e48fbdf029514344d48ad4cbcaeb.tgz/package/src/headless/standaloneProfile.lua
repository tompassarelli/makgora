local ____lualib = require("lualib_bundle")
local Set = ____lualib.Set
local __TS__New = ____lualib.__TS__New
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local reportedOnce
function reportedOnce(name, inner, outside)
    local reported = false
    return function(...)
        if not reported then
            outside(name)
        end
        reported = true
        return inner(...)
    end
end
function ____exports.enforceStandaloneProfile(profile, declared, natives, outside)
    if profile == nil then
        return
    end
    local allowed = __TS__New(Set, profile)
    for ____, name in __TS__Iterator(allowed) do
        if not declared:has(name) then
            do
                local ____thrown = __TS__New(Error, ("standalone profile native " .. name) .. " is not a declared native")
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/headless/standaloneProfile.ts:6"
                end
                error(____thrown, 0)
            end
        end
    end
    for ____, name in __TS__Iterator(declared) do
        if not allowed:has(name) then
            natives[name] = reportedOnce(name, natives[name], outside)
        end
    end
end
return ____exports
