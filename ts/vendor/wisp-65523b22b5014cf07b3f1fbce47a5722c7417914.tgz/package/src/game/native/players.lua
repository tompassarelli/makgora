local ____exports = {}
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
local function slotOf(player)
    return ____types.asNumber(player)
end
function ____exports.player(slot)
    local ____opt_0 = ____world.boundWorld().log
    if ____opt_0 ~= nil then
        ____opt_0("Player", {slot})
    end
    return ____types.fromValue(slot)
end
function ____exports.playerSlot(player)
    local ____opt_2 = ____world.boundWorld().log
    if ____opt_2 ~= nil then
        ____opt_2("GetPlayerId", {player})
    end
    return slotOf(player)
end
function ____exports.localPlayer()
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("GetLocalPlayer", {})
    end
    local ____fromValue_7 = ____types.fromValue
    local ____self_6 = world.players
    return ____fromValue_7(____self_6["local"](____self_6))
end
function ____exports.eventPlayer()
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("GetTriggerPlayer", {})
    end
    return ____types.fromValue(world.events:triggerPlayer())
end
function ____exports.playerControl(player)
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("GetPlayerController", {player})
    end
    return ____types.fromValue(world.players:control(slotOf(player)))
end
function ____exports.playerSlotState(player)
    local world = ____world.boundWorld()
    local ____opt_12 = world.log
    if ____opt_12 ~= nil then
        ____opt_12("GetPlayerSlotState", {player})
    end
    return ____types.fromValue(world.players:slotState(slotOf(player)))
end
function ____exports.playerName(player)
    local world = ____world.boundWorld()
    local ____opt_14 = world.log
    if ____opt_14 ~= nil then
        ____opt_14("GetPlayerName", {player})
    end
    return world.players:name(slotOf(player))
end
function ____exports.connectionRoundTripMs(player)
    local world = ____world.boundWorld()
    local ____opt_16 = world.log
    if ____opt_16 ~= nil then
        ____opt_16("ConnectionRoundTripMs", {player})
    end
    return world.players:roundTripMs(slotOf(player))
end
function ____exports.setPlayerColor(player, color)
    local world = ____world.boundWorld()
    local ____opt_18 = world.log
    if ____opt_18 ~= nil then
        ____opt_18("ConvertPlayerColor", {color})
    end
    local ____opt_20 = world.log
    if ____opt_20 ~= nil then
        ____opt_20("SetPlayerColor", {player, color})
    end
    world.players:setColor(
        slotOf(player),
        color
    )
end
function ____exports.playerColor(player)
    local world = ____world.boundWorld()
    local ____opt_22 = world.log
    if ____opt_22 ~= nil then
        ____opt_22("GetPlayerColor", {player})
    end
    local color = world.players:color(slotOf(player))
    local index = type(color) == "number" and color or slotOf(player)
    local ____opt_24 = world.log
    if ____opt_24 ~= nil then
        ____opt_24("GetHandleId", {index})
    end
    return index
end
function ____exports.addLeaveEvent(events, player)
    local world = ____world.boundWorld()
    local ____opt_26 = world.log
    if ____opt_26 ~= nil then
        ____opt_26("TriggerRegisterPlayerEvent", {events, player, "EVENT_PLAYER_LEAVE"})
    end
    world.events:registerLeave(
        ____types.asHandle(events),
        slotOf(player)
    )
end
____exports.PlayerControl = {
    user = ____types.fromValue("MAP_CONTROL_USER"),
    computer = ____types.fromValue("MAP_CONTROL_COMPUTER")
}
____exports.PlayerSlotState = {playing = ____types.fromValue("PLAYER_SLOT_STATE_PLAYING")}
return ____exports
