local ____exports = {}
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
function ____exports.createSound(file, looping, positional, stopOutOfRange, fadeInRate, fadeOutRate, environment)
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("CreateSound", {
            file,
            looping,
            positional,
            stopOutOfRange,
            fadeInRate,
            fadeOutRate,
            environment
        })
    end
    return ____types.fromHandle(world.sounds:create(file, nil, looping))
end
function ____exports.soundFromLabel(label, looping, positional, stopOutOfRange, fadeInRate, fadeOutRate)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("CreateSoundFromLabel", {
            label,
            looping,
            positional,
            stopOutOfRange,
            fadeInRate,
            fadeOutRate
        })
    end
    return ____types.fromHandle(world.sounds:create(nil, label, looping))
end
function ____exports.playSound(sound)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("StartSound", {sound})
    end
    world.sounds:start(____types.asHandle(sound))
end
function ____exports.stopSound(sound, release, fadeOut)
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("StopSound", {sound, release, fadeOut})
    end
    world.sounds:stop(
        ____types.asHandle(sound),
        release
    )
end
function ____exports.setSoundVolume(sound, volume)
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("SetSoundVolume", {sound, volume})
    end
    world.sounds:setVolume(
        ____types.asHandle(sound),
        volume
    )
end
function ____exports.setSoundPitch(sound, pitch)
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("SetSoundPitch", {sound, pitch})
    end
    world.sounds:setPitch(
        ____types.asHandle(sound),
        pitch
    )
end
function ____exports.setSoundPosition(sound, x, y, z)
    local world = ____world.boundWorld()
    local ____opt_12 = world.log
    if ____opt_12 ~= nil then
        ____opt_12("SetSoundPosition", {sound, x, y, z})
    end
    world.sounds:setPosition(
        ____types.asHandle(sound),
        x,
        y,
        z
    )
end
function ____exports.setSoundDistances(sound, nearest, farthest)
    local ____opt_14 = ____world.boundWorld().log
    if ____opt_14 ~= nil then
        ____opt_14("SetSoundDistances", {sound, nearest, farthest})
    end
end
function ____exports.setSoundCutoff(sound, distance)
    local ____opt_16 = ____world.boundWorld().log
    if ____opt_16 ~= nil then
        ____opt_16("SetSoundDistanceCutoff", {sound, distance})
    end
end
function ____exports.setSoundDuration(sound, milliseconds)
    local world = ____world.boundWorld()
    local ____opt_18 = world.log
    if ____opt_18 ~= nil then
        ____opt_18("SetSoundDuration", {sound, milliseconds})
    end
    world.sounds:setDuration(
        ____types.asHandle(sound),
        milliseconds
    )
end
function ____exports.releaseWhenDone(sound)
    local world = ____world.boundWorld()
    local ____opt_20 = world.log
    if ____opt_20 ~= nil then
        ____opt_20("KillSoundWhenDone", {sound})
    end
    world.sounds:killWhenDone(____types.asHandle(sound))
end
function ____exports.soundFileDuration(file)
    local ____opt_22 = ____world.boundWorld().log
    if ____opt_22 ~= nil then
        ____opt_22("GetSoundFileDuration", {file})
    end
    return 0
end
function ____exports.playMusic(file)
    local world = ____world.boundWorld()
    local ____opt_24 = world.log
    if ____opt_24 ~= nil then
        ____opt_24("PlayMusic", {file})
    end
    world.sounds:playMusic(file)
end
function ____exports.stopMusic(fadeOut)
    local world = ____world.boundWorld()
    local ____opt_26 = world.log
    if ____opt_26 ~= nil then
        ____opt_26("StopMusic", {fadeOut})
    end
    world.sounds:stopMusic()
end
function ____exports.clearMusic()
    local ____opt_28 = ____world.boundWorld().log
    if ____opt_28 ~= nil then
        ____opt_28("ClearMapMusic", {})
    end
end
function ____exports.playTheme(file)
    local world = ____world.boundWorld()
    local ____opt_30 = world.log
    if ____opt_30 ~= nil then
        ____opt_30("PlayThematicMusic", {file})
    end
    world.sounds:playMusic(file, false)
end
function ____exports.endTheme()
    local ____opt_32 = ____world.boundWorld().log
    if ____opt_32 ~= nil then
        ____opt_32("EndThematicMusic", {})
    end
end
function ____exports.setVolumeGroup(group, scale)
    local ____opt_34 = ____world.boundWorld().log
    if ____opt_34 ~= nil then
        ____opt_34("VolumeGroupSetVolume", {group, scale})
    end
end
function ____exports.resetVolumeGroups()
    local ____opt_36 = ____world.boundWorld().log
    if ____opt_36 ~= nil then
        ____opt_36("VolumeGroupReset", {})
    end
end
____exports.VolumeGroup = {
    combat = ____types.fromValue("SOUND_VOLUMEGROUP_COMBAT"),
    spells = ____types.fromValue("SOUND_VOLUMEGROUP_SPELLS")
}
return ____exports
