local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Set = ____lualib.Set
local __TS__New = ____lualib.__TS__New
local ____exports = {}
--- What a player's keyboard, mouse and window hold now on one running game's client, which the host's window feed or a test sets and the native backend's local input reads return.
____exports.Input = __TS__Class()
local Input = ____exports.Input
Input.name = "Input"
function Input.prototype.____constructor(self)
    self.heldMouseButtons = __TS__New(Set)
    self.pointerX = 0
    self.pointerY = 0
    self.heldKeys = __TS__New(Set)
    self.heldMeta = 0
end
function Input.prototype.hold(self, key, meta, down)
    self.heldMeta = meta
    if down then
        self.heldKeys:add(key)
    else
        self.heldKeys:delete(key)
    end
end
function Input.prototype.keyHeld(self, key)
    return self.heldKeys:has(key)
end
function Input.prototype.metaHeld(self, meta)
    return self.heldMeta & meta == meta
end
function Input.prototype.mouseButtonHeld(self, button)
    return self.heldMouseButtons:has(button)
end
function Input.prototype.focused(self)
    return true
end
return ____exports
