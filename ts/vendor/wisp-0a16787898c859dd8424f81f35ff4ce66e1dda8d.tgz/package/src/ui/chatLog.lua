local ____lualib = require("lualib_bundle")
local __TS__StringCharAt = ____lualib.__TS__StringCharAt
local __TS__StringSubstring = ____lualib.__TS__StringSubstring
local __TS__StringSplit = ____lualib.__TS__StringSplit
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ArrayReverse = ____lualib.__TS__ArrayReverse
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____intMath = require("src.sim.intMath")
____exports.createChatLog = function(capacity) return {lines = {}, capacity = capacity, clock = 0.0, revision = 0} end
local HEX = "0123456789abcdef"
local function hexByte(value)
    return __TS__StringCharAt(
        HEX,
        ____intMath.idiv(value, 16)
    ) .. __TS__StringCharAt(
        HEX,
        ____intMath.imod(value, 16)
    )
end
____exports.colourCode = function(rgb) return (("|cff" .. hexByte(____intMath.idiv(rgb, 65536))) .. hexByte(____intMath.imod(
    ____intMath.idiv(rgb, 256),
    256
))) .. hexByte(____intMath.imod(rgb, 256)) end
--- Battle.net names carry a `#1234` tag that chat never shows.
function ____exports.chatName(name)
    local tag = (string.find(name, "#", nil, true) or 0) - 1
    return tag > 0 and __TS__StringSubstring(name, 0, tag) or name
end
function ____exports.addChatLine(log, rgb, name, text)
    local ____log_lines_0 = log.lines
    ____log_lines_0[#____log_lines_0 + 1] = {
        rgb = rgb,
        name = ____exports.chatName(name),
        text = text,
        born = log.clock
    }
    while #log.lines > log.capacity do
        table.remove(log.lines, 1)
    end
    log.revision = log.revision + 1
end
function ____exports.advanceChat(log, seconds)
    log.clock = __wispF32Add(log.clock, seconds)
end
____exports.chatAge = function(log, born) return __wispF32Subtract(log.clock, born) end
--- Splits `text` at spaces into pieces of at most `width` characters; a word longer than `width` is cut.
function ____exports.wrapChat(text, width)
    local pieces = {}
    local current = ""
    for ____, word in ipairs(__TS__StringSplit(text, " ")) do
        local rest = word
        while #rest > width do
            if #current > 0 then
                pieces[#pieces + 1] = current
                current = ""
            end
            pieces[#pieces + 1] = __TS__StringSubstring(rest, 0, width)
            rest = __TS__StringSubstring(rest, width)
        end
        if #current == 0 then
            current = rest
        elseif #current + 1 + #rest <= width then
            current = (current .. " ") .. rest
        else
            pieces[#pieces + 1] = current
            current = rest
        end
    end
    if #current > 0 or #pieces == 0 then
        pieces[#pieces + 1] = current
    end
    return pieces
end
--- One row per wrapped piece: the first holds the coloured name, later ones sit under the message, not the name.
function ____exports.chatRows(line, width)
    local head = line.name .. ": "
    local indent = string.rep(
        " ",
        math.floor(#head)
    )
    local pieces = ____exports.wrapChat(
        line.text,
        math.max(8, width - #head)
    )
    return __TS__ArrayMap(
        pieces,
        function(____, piece, index) return {
            text = index == 0 and ((____exports.colourCode(line.rgb) .. line.name) .. "|r: ") .. piece or indent .. piece,
            born = line.born
        } end
    )
end
--- The last `count` rows of the lines younger than `seconds`, oldest first; `seconds` below 0 keeps every line.
function ____exports.visibleChatRows(log, count, width, seconds)
    local rows = {}
    do
        local index = #log.lines - 1
        while index >= 0 and #rows < count do
            do
                local line = log.lines[index + 1]
                if line == nil or seconds >= 0.0 and ____exports.chatAge(log, line.born) >= seconds then
                    goto __continue23
                end
                local lineRows = ____exports.chatRows(line, width)
                do
                    local row = #lineRows - 1
                    while row >= 0 and #rows < count do
                        rows[#rows + 1] = lineRows[row + 1]
                        row = row - 1
                    end
                end
            end
            ::__continue23::
            index = index - 1
        end
    end
    return __TS__ArrayReverse(rows)
end
--- Full opacity until `fade` seconds before the line expires after `seconds`, then a straight ramp to 0.
function ____exports.chatOpacity(age, seconds, fade)
    if seconds < 0.0 then
        return 1.0
    end
    local left = __wispF32Subtract(seconds, age)
    if left >= fade then
        return 1.0
    end
    return left <= 0.0 and 0.0 or __wispF32Divide(left, fade)
end
return ____exports
