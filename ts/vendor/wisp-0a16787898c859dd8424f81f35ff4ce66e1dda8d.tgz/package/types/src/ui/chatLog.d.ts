/** @noSelfInFile */
export interface ChatLine {
    readonly rgb: number;
    readonly name: string;
    readonly text: string;
    readonly born: number;
}
export interface ChatRow {
    readonly text: string;
    readonly born: number;
}
export interface ChatLog {
    readonly lines: ChatLine[];
    readonly capacity: number;
    clock: number;
    revision: number;
}
export declare const createChatLog: (capacity: number) => ChatLog;
export declare const colourCode: (rgb: number) => string;
/** Battle.net names carry a `#1234` tag that chat never shows. */
export declare function chatName(name: string): string;
export declare function addChatLine(log: ChatLog, rgb: number, name: string, text: string): void;
export declare function advanceChat(log: ChatLog, seconds: number): void;
export declare const chatAge: (log: Readonly<ChatLog>, born: number) => number;
/** Splits `text` at spaces into pieces of at most `width` characters; a word longer than `width` is cut. */
export declare function wrapChat(text: string, width: number): string[];
/** One row per wrapped piece: the first holds the coloured name, later ones sit under the message, not the name. */
export declare function chatRows(line: ChatLine, width: number): ChatRow[];
/** The last `count` rows of the lines younger than `seconds`, oldest first; `seconds` below 0 keeps every line. */
export declare function visibleChatRows(log: Readonly<ChatLog>, count: number, width: number, seconds: number): ChatRow[];
/** Full opacity until `fade` seconds before the line expires after `seconds`, then a straight ramp to 0. */
export declare function chatOpacity(age: number, seconds: number, fade: number): number;
