local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local bound
function ____exports.bindWorld(world)
    bound = world
end
function ____exports.boundWorld()
    if bound == nil then
        do
            local ____thrown = __TS__New(Error, "Wisp's game API was used with no world bound")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/game/native/world.ts:31"
            end
            error(____thrown, 0)
        end
    end
    return bound
end
return ____exports
