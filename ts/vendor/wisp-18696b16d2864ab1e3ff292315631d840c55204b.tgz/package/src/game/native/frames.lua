local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
local function questEntry(world, quest, change)
    local entry = world.quests:entry(____types.asHandle(quest))
    if entry ~= nil then
        change(entry)
    end
end
local function registerFrameEvent(world, events, frame, event)
    local trigger = ____types.asHandle(events)
    if world.events:hasFrame(trigger, frame, event) then
        do
            local ____thrown = __TS__New(Error, "addFrameEvent: this frame already registers this event on these events")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/game/native/frames.ts:13"
            end
            error(____thrown, 0)
        end
    end
    world.events:registerFrame(trigger, frame, event)
end
local function packColor(alpha, red, green, blue)
    local word = ((alpha * 256 + red) * 256 + green) * 256 + blue
    return word >= 2147483648 and word - 4294967296 or word
end
function ____exports.createFrame(template, owner, priority, context)
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("BlzCreateFrame", {template, owner, priority, context})
    end
    return ____types.fromHandle(world.frames:create(template, owner, context))
end
function ____exports.createFrameByType(kind, name, owner, inherits, context)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("BlzCreateFrameByType", {
            kind,
            name,
            owner,
            inherits,
            context
        })
    end
    return ____types.fromHandle(world.frames:createByType(
        kind,
        name,
        owner,
        inherits,
        context
    ))
end
function ____exports.destroyFrame(frame)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("BlzDestroyFrame", {frame})
    end
    world.frames:destroy(frame)
end
function ____exports.clearFramePoints(frame)
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("BlzFrameClearAllPoints", {frame})
    end
    world.frames:clearPoints(frame)
end
function ____exports.frameChild(frame, index)
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("BlzFrameGetChild", {frame, index})
    end
    return ____types.fromHandle(world.frames:child(
        ____types.asHandle(frame),
        index
    ))
end
function ____exports.frameChildCount(frame)
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("BlzFrameGetChildrenCount", {frame})
    end
    return world.frames:childCount(frame)
end
function ____exports.frameEnabled(frame)
    local world = ____world.boundWorld()
    local ____opt_12 = world.log
    if ____opt_12 ~= nil then
        ____opt_12("BlzFrameGetEnable", {frame})
    end
    return world.frames:enabled(frame)
end
function ____exports.frameName(frame)
    local world = ____world.boundWorld()
    local ____opt_14 = world.log
    if ____opt_14 ~= nil then
        ____opt_14("BlzFrameGetName", {frame})
    end
    return world.frames:name(frame)
end
function ____exports.frameText(frame)
    local world = ____world.boundWorld()
    local ____opt_16 = world.log
    if ____opt_16 ~= nil then
        ____opt_16("BlzFrameGetText", {frame})
    end
    return world.frames:text(frame)
end
function ____exports.frameTextLimit(frame)
    local world = ____world.boundWorld()
    local ____opt_18 = world.log
    if ____opt_18 ~= nil then
        ____opt_18("BlzFrameGetTextSizeLimit", {frame})
    end
    return world.frames:textLimit(frame)
end
function ____exports.frameVisible(frame)
    local world = ____world.boundWorld()
    local ____opt_20 = world.log
    if ____opt_20 ~= nil then
        ____opt_20("BlzFrameIsVisible", {frame})
    end
    return world.frames:visible(frame)
end
function ____exports.setFrameAbsPoint(frame, point, x, y)
    local world = ____world.boundWorld()
    local ____opt_22 = world.log
    if ____opt_22 ~= nil then
        ____opt_22("BlzFrameSetAbsPoint", {frame, point, x, y})
    end
    world.frames:setAbsPoint(frame, point, x, y)
end
function ____exports.setFrameAlpha(frame, alpha)
    local world = ____world.boundWorld()
    local ____opt_24 = world.log
    if ____opt_24 ~= nil then
        ____opt_24("BlzFrameSetAlpha", {frame, alpha})
    end
    world.frames:setAlpha(frame, alpha)
end
function ____exports.setFrameEnabled(frame, enabled)
    local world = ____world.boundWorld()
    local ____opt_26 = world.log
    if ____opt_26 ~= nil then
        ____opt_26("BlzFrameSetEnable", {frame, enabled})
    end
    world.frames:setEnabled(frame, enabled)
end
function ____exports.setFrameFocus(frame, focused)
    local world = ____world.boundWorld()
    local ____opt_28 = world.log
    if ____opt_28 ~= nil then
        ____opt_28("BlzFrameSetFocus", {frame, focused})
    end
    world.frames:setFocus(frame, focused)
end
function ____exports.setFrameFont(frame, file, height, flags)
    local world = ____world.boundWorld()
    local ____opt_30 = world.log
    if ____opt_30 ~= nil then
        ____opt_30("BlzFrameSetFont", {frame, file, height, flags})
    end
    world.frames:setFont(frame, file, height, flags)
end
function ____exports.setFrameLevel(frame, level)
    local world = ____world.boundWorld()
    local ____opt_32 = world.log
    if ____opt_32 ~= nil then
        ____opt_32("BlzFrameSetLevel", {frame, level})
    end
    world.frames:setLevel(frame, level)
end
function ____exports.setFramePoint(frame, point, relative, relativePoint, x, y)
    local world = ____world.boundWorld()
    local ____opt_34 = world.log
    if ____opt_34 ~= nil then
        ____opt_34("BlzFrameSetPoint", {
            frame,
            point,
            relative,
            relativePoint,
            x,
            y
        })
    end
    world.frames:setPoint(
        frame,
        point,
        relative,
        relativePoint,
        x,
        y
    )
end
function ____exports.setFrameScale(frame, scale)
    local world = ____world.boundWorld()
    local ____opt_36 = world.log
    if ____opt_36 ~= nil then
        ____opt_36("BlzFrameSetScale", {frame, scale})
    end
    world.frames:setScale(frame, scale)
end
function ____exports.setFrameSize(frame, width, height)
    local world = ____world.boundWorld()
    local ____opt_38 = world.log
    if ____opt_38 ~= nil then
        ____opt_38("BlzFrameSetSize", {frame, width, height})
    end
    world.frames:setSize(frame, width, height)
end
function ____exports.setFrameText(frame, text)
    local world = ____world.boundWorld()
    local ____opt_40 = world.log
    if ____opt_40 ~= nil then
        ____opt_40("BlzFrameSetText", {frame, text})
    end
    world.frames:setText(frame, text)
end
function ____exports.setFrameTextAlignment(frame, vertical, horizontal)
    local world = ____world.boundWorld()
    local ____opt_42 = world.log
    if ____opt_42 ~= nil then
        ____opt_42("BlzFrameSetTextAlignment", {frame, vertical, horizontal})
    end
    world.frames:setTextAlignment(frame, vertical, horizontal)
end
function ____exports.setFrameTextLimit(frame, limit)
    local world = ____world.boundWorld()
    local ____opt_44 = world.log
    if ____opt_44 ~= nil then
        ____opt_44("BlzFrameSetTextSizeLimit", {frame, limit})
    end
    world.frames:setTextLimit(frame, limit)
end
function ____exports.setFrameTexture(frame, file, flag, blend)
    local world = ____world.boundWorld()
    local ____opt_46 = world.log
    if ____opt_46 ~= nil then
        ____opt_46("BlzFrameSetTexture", {frame, file, flag, blend})
    end
    world.frames:setTexture(frame, file)
end
function ____exports.setFrameColor(frame, color)
    local world = ____world.boundWorld()
    local ____opt_48 = world.log
    if ____opt_48 ~= nil then
        ____opt_48("BlzFrameSetVertexColor", {frame, color})
    end
    world.frames:setVertexColor(frame, color)
end
function ____exports.setFrameModel(frame, model, camera)
    local world = ____world.boundWorld()
    local ____opt_50 = world.log
    if ____opt_50 ~= nil then
        ____opt_50("BlzFrameSetModel", {frame, model, camera})
    end
    world.frames:setModel(frame, model, camera)
end
function ____exports.setFrameSpriteAnimation(frame, animation, flags)
    local world = ____world.boundWorld()
    local ____opt_52 = world.log
    if ____opt_52 ~= nil then
        ____opt_52("BlzFrameSetSpriteAnimate", {frame, animation, flags})
    end
    world.frames:setSpriteAnimation(frame, animation)
end
function ____exports.setFrameSpriteTime(frame, seconds)
    local world = ____world.boundWorld()
    local ____opt_54 = world.log
    if ____opt_54 ~= nil then
        ____opt_54("WispFrameSetSpriteTime", {frame, seconds})
    end
    world.frames:setSpriteTime(frame, seconds)
end
function ____exports.setFrameVisible(frame, visible)
    local world = ____world.boundWorld()
    local ____opt_56 = world.log
    if ____opt_56 ~= nil then
        ____opt_56("BlzFrameSetVisible", {frame, visible})
    end
    world.frames:setVisible(frame, visible)
end
function ____exports.namedFrame(name, context)
    local world = ____world.boundWorld()
    local ____opt_58 = world.log
    if ____opt_58 ~= nil then
        ____opt_58("BlzGetFrameByName", {name, context})
    end
    return ____types.fromHandle(world.frames:named(name, context))
end
function ____exports.screenHeight()
    local world = ____world.boundWorld()
    local ____opt_60 = world.log
    if ____opt_60 ~= nil then
        ____opt_60("BlzGetLocalClientHeight", {})
    end
    return world.frames.screen.height
end
function ____exports.screenWidth()
    local world = ____world.boundWorld()
    local ____opt_62 = world.log
    if ____opt_62 ~= nil then
        ____opt_62("BlzGetLocalClientWidth", {})
    end
    return world.frames.screen.width
end
function ____exports.originFrame(origin, index)
    local world = ____world.boundWorld()
    local ____opt_64 = world.log
    if ____opt_64 ~= nil then
        ____opt_64("BlzGetOriginFrame", {origin, index})
    end
    return ____types.fromHandle(world.frames:originFrame(origin, index))
end
function ____exports.eventFrame()
    local world = ____world.boundWorld()
    local ____opt_66 = world.log
    if ____opt_66 ~= nil then
        ____opt_66("BlzGetTriggerFrame", {})
    end
    return ____types.fromHandle(____types.asHandle(world.events:triggerFrame()))
end
function ____exports.eventFrameEvent()
    local world = ____world.boundWorld()
    local ____opt_68 = world.log
    if ____opt_68 ~= nil then
        ____opt_68("BlzGetTriggerFrameEvent", {})
    end
    return world.events:triggerFrameEvent()
end
function ____exports.eventFrameText()
    local world = ____world.boundWorld()
    local ____opt_70 = world.log
    if ____opt_70 ~= nil then
        ____opt_70("BlzGetTriggerFrameText", {})
    end
    return world.events:triggerFrameText()
end
function ____exports.hideOriginFrames(hide)
    local ____opt_72 = ____world.boundWorld().log
    if ____opt_72 ~= nil then
        ____opt_72("BlzHideOriginFrames", {hide})
    end
end
function ____exports.loadFrameFile(path)
    local ____opt_74 = ____world.boundWorld().log
    if ____opt_74 ~= nil then
        ____opt_74("BlzLoadTOCFile", {path})
    end
    return true
end
function ____exports.frameColor(alpha, red, green, blue)
    local world = ____world.boundWorld()
    local ____opt_76 = world.log
    if ____opt_76 ~= nil then
        ____opt_76("BlzConvertColor", {alpha, red, green, blue})
    end
    return packColor(alpha, red, green, blue)
end
function ____exports.addFrameEvent(events, frame, event)
    local world = ____world.boundWorld()
    local ____opt_78 = world.log
    if ____opt_78 ~= nil then
        ____opt_78("BlzTriggerRegisterFrameEvent", {events, frame, event})
    end
    registerFrameEvent(world, events, frame, event)
end
function ____exports.displayText(player, x, y, message)
    local world = ____world.boundWorld()
    local ____opt_80 = world.log
    if ____opt_80 ~= nil then
        ____opt_80("DisplayTextToPlayer", {player, x, y, message})
    end
    world.display(player, message)
end
function ____exports.displayTimedText(player, x, y, seconds, message)
    local world = ____world.boundWorld()
    local ____opt_82 = world.log
    if ____opt_82 ~= nil then
        ____opt_82("DisplayTimedTextToPlayer", {
            player,
            x,
            y,
            seconds,
            message
        })
    end
    world.display(player, message)
end
function ____exports.clearTextMessages()
    local ____opt_84 = ____world.boundWorld().log
    if ____opt_84 ~= nil then
        ____opt_84("ClearTextMessages", {})
    end
end
function ____exports.debugMessage(message)
    local ____opt_86 = ____world.boundWorld().log
    if ____opt_86 ~= nil then
        ____opt_86("BJDebugMsg", {message})
    end
end
function ____exports.createQuest()
    local world = ____world.boundWorld()
    local ____opt_88 = world.log
    if ____opt_88 ~= nil then
        ____opt_88("CreateQuest", {})
    end
    return ____types.fromHandle(world.quests:create())
end
function ____exports.setQuestTitle(quest, title)
    local world = ____world.boundWorld()
    local ____opt_90 = world.log
    if ____opt_90 ~= nil then
        ____opt_90("QuestSetTitle", {quest, title})
    end
    questEntry(
        world,
        quest,
        function(entry)
            entry.title = title
        end
    )
end
function ____exports.setQuestDescription(quest, description)
    local world = ____world.boundWorld()
    local ____opt_92 = world.log
    if ____opt_92 ~= nil then
        ____opt_92("QuestSetDescription", {quest, description})
    end
    questEntry(
        world,
        quest,
        function(entry)
            entry.description = description
        end
    )
end
function ____exports.setQuestIcon(quest, path)
    local world = ____world.boundWorld()
    local ____opt_94 = world.log
    if ____opt_94 ~= nil then
        ____opt_94("QuestSetIconPath", {quest, path})
    end
    questEntry(
        world,
        quest,
        function(entry)
            entry.iconPath = path
        end
    )
end
function ____exports.setQuestRequired(quest, required)
    local world = ____world.boundWorld()
    local ____opt_96 = world.log
    if ____opt_96 ~= nil then
        ____opt_96("QuestSetRequired", {quest, required})
    end
    questEntry(
        world,
        quest,
        function(entry)
            entry.required = required
        end
    )
end
function ____exports.setQuestDiscovered(quest, discovered)
    local world = ____world.boundWorld()
    local ____opt_98 = world.log
    if ____opt_98 ~= nil then
        ____opt_98("QuestSetDiscovered", {quest, discovered})
    end
    questEntry(
        world,
        quest,
        function(entry)
            entry.discovered = discovered
        end
    )
end
function ____exports.setQuestCompleted(quest, completed)
    local world = ____world.boundWorld()
    local ____opt_100 = world.log
    if ____opt_100 ~= nil then
        ____opt_100("QuestSetCompleted", {quest, completed})
    end
    questEntry(
        world,
        quest,
        function(entry)
            entry.completed = completed
        end
    )
end
return ____exports
