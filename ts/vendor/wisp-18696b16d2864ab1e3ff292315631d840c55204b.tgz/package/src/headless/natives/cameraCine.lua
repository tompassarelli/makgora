local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local ____exports = {}
local ____frameRate = require("src.game.native.frameRate")
local ____jassFormat = require("src.headless.jassFormat")
local BLEND_MODES = {
    "BLEND_MODE_NONE",
    "BLEND_MODE_DONT_CARE",
    "BLEND_MODE_KEYALPHA",
    "BLEND_MODE_BLEND",
    "BLEND_MODE_ADDITIVE",
    "BLEND_MODE_MODULATE",
    "BLEND_MODE_MODULATE_2X"
}
local CAMERA_FIELDS = {
    "CAMERA_FIELD_TARGET_DISTANCE",
    "CAMERA_FIELD_FARZ",
    "CAMERA_FIELD_ANGLE_OF_ATTACK",
    "CAMERA_FIELD_FIELD_OF_VIEW",
    "CAMERA_FIELD_ROLL",
    "CAMERA_FIELD_ROTATION",
    "CAMERA_FIELD_ZOFFSET",
    "CAMERA_FIELD_NEARZ",
    "CAMERA_FIELD_LOCAL_PITCH",
    "CAMERA_FIELD_LOCAL_YAW",
    "CAMERA_FIELD_LOCAL_ROLL",
    "CAMERA_FIELD_DEPTH_OF_FIELD_DISTANCE",
    "CAMERA_FIELD_DEPTH_OF_FIELD_SCALE",
    "CAMERA_FIELD_ZABSOLUTE"
}
local function cameraField(field)
    if type(field) == "number" then
        return CAMERA_FIELDS[field + 1] or ____jassFormat.describeValue(field)
    end
    if type(field) == "string" then
        return field
    end
    return ____jassFormat.describeValue(field)
end
____exports.CameraCine = __TS__Class()
local CameraCine = ____exports.CameraCine
CameraCine.name = "CameraCine"
function CameraCine.prototype.____constructor(self, scenery, frame)
    self.scenery = scenery
    self.frame = frame
    self.cameraX = 0
    self.cameraY = 0
    self.cameraFields = {}
    self.cineFilter = {
        texture = "",
        blendMode = "BLEND_MODE_NONE",
        texMapFlags = nil,
        startColor = {255, 255, 255, 255},
        endColor = {255, 255, 255, 255},
        startUV = {0, 0, 1, 1},
        endUV = {0, 0, 1, 1},
        duration = 0,
        shown = nil
    }
end
function CameraCine.prototype.cineFilterPose(self)
    local filter = self.cineFilter
    if filter.shown == nil then
        return nil
    end
    local share = filter.duration <= 0 and 1 or math.min(
        1,
        (self.frame() - filter.shown) / ____frameRate.FRAMES_PER_SECOND / filter.duration
    )
    local function mix(from, to)
        return __TS__ArrayMap(
            {0, 1, 2, 3},
            function(____, i) return (from[i + 1] or 0) + ((to[i + 1] or 0) - (from[i + 1] or 0)) * share end
        )
    end
    return {
        texture = filter.texture,
        blendMode = filter.blendMode,
        texMapFlags = filter.texMapFlags,
        color = mix(filter.startColor, filter.endColor),
        uv = mix(filter.startUV, filter.endUV)
    }
end
function CameraCine.prototype.cameraPose(self)
    return {
        x = self.cameraX,
        y = self.cameraY,
        fields = __TS__ObjectAssign({}, self.cameraFields)
    }
end
function CameraCine.prototype.behaviors(self)
    return {
        SetCameraPosition = function(x, y)
            self.cameraX = x
            self.cameraY = y
        end,
        GetCameraTargetPositionX = function() return self.cameraX end,
        SetCameraTargetController = function()
            self.scenery.cameraAllowsHotkeyTargetLock = false
        end,
        SetCameraOrientController = function()
            self.scenery.cameraAllowsHotkeyTargetLock = false
        end,
        SetCameraField = function(field, value)
            self.cameraFields[cameraField(field)] = value
        end,
        GetCameraField = function(field) return self.cameraFields[cameraField(field)] or 0 end,
        SetCineFilterTexture = function(texture)
            self.cineFilter.texture = texture
        end,
        SetCineFilterBlendMode = function(mode)
            self.cineFilter.blendMode = type(mode) == "number" and (BLEND_MODES[mode + 1] or "BLEND_MODE_NONE") or tostring(mode)
        end,
        SetCineFilterTexMapFlags = function(flags)
            self.cineFilter.texMapFlags = flags
        end,
        SetCineFilterStartUV = function(minU, minV, maxU, maxV)
            self.cineFilter.startUV = {minU, minV, maxU, maxV}
        end,
        SetCineFilterEndUV = function(minU, minV, maxU, maxV)
            self.cineFilter.endUV = {minU, minV, maxU, maxV}
        end,
        SetCineFilterStartColor = function(red, green, blue, alpha)
            self.cineFilter.startColor = {red, green, blue, alpha}
        end,
        SetCineFilterEndColor = function(red, green, blue, alpha)
            self.cineFilter.endColor = {red, green, blue, alpha}
        end,
        SetCineFilterDuration = function(duration)
            self.cineFilter.duration = duration
        end,
        DisplayCineFilter = function(flag)
            self.cineFilter.shown = flag and self.frame() or nil
        end,
        IsCineFilterDisplayed = function() return self.cineFilter.shown ~= nil end
    }
end
return ____exports
