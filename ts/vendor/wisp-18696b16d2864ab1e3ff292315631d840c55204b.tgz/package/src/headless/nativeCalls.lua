local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local ____exports = {}
____exports.EmulatedCalls = __TS__Class()
local EmulatedCalls = ____exports.EmulatedCalls
EmulatedCalls.name = "EmulatedCalls"
function EmulatedCalls.prototype.____constructor(self)
    self.byName = __TS__New(Map)
    self.count = function(____, name)
        self.byName:set(
            name,
            (self.byName:get(name) or 0) + 1
        )
    end
end
function EmulatedCalls.prototype.counting(self, name, behave)
    return function(...)
        self:count(name)
        return behave(...)
    end
end
____exports.logUnlessLocal = function(log, ____local) return function(name, args)
    if ____local[name] == nil then
        log[#log + 1] = {name = name, args = args}
    end
end end
return ____exports
