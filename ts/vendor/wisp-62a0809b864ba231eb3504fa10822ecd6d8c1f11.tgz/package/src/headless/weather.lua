local ____lualib = require("lualib_bundle")
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Spread = ____lualib.__TS__Spread
local __TS__ArrayFilter = ____lualib.__TS__ArrayFilter
local ____exports = {}
local ____intMath = require("src.sim.intMath")
local function fourCC(id)
    return table.concat(
        __TS__ArrayMap(
            {24, 16, 8, 0},
            function(____, shift) return string.char(id // 2 ^ shift % 256) end
        ),
        ""
    )
end
--- The weather effects a map adds over a rect: each starts enabled, and only an enabled one reaches the scene.
____exports.Weathers = __TS__Class()
local Weathers = ____exports.Weathers
Weathers.name = "Weathers"
function Weathers.prototype.____constructor(self)
    self.effects = __TS__New(Map)
end
function Weathers.prototype.behaviors(self, context)
    return {
        AddWeatherEffect = function(rect, id)
            local handle = context.handle("weathereffect")
            self.effects:set(
                handle,
                {
                    handle = handle,
                    id = fourCC(id),
                    rect = {rect.minX, rect.minY, rect.maxX, rect.maxY},
                    enabled = true
                }
            )
            return handle
        end,
        RemoveWeatherEffect = function(value)
            self.effects:delete(value)
        end,
        EnableWeatherEffect = function(value, enable)
            local found = self.effects:get(value)
            if found ~= nil then
                found.enabled = enable
            end
        end
    }
end
function Weathers.prototype.poses(self)
    return __TS__ArrayMap(
        __TS__ArrayFilter(
            {__TS__Spread(self.effects:values())},
            function(____, found) return found.enabled end
        ),
        function(____, found) return {handle = found.handle, id = found.id, rect = found.rect} end
    )
end
return ____exports
