/** @noSelfInFile */
export declare class IntegerKeysUndeclared extends Error {
}
export declare function recordTokens(record: object, keyedByInteger?: readonly string[]): string[] | undefined;
export declare function writeFieldTokens(name: string, value: unknown, keyedByInteger?: readonly string[]): number | undefined;
export interface TokenLines {
    width: number;
    prefix: string;
    lines: string[];
    readonly parts: string[];
    size: number;
    tokens: number;
    length: number;
}
export declare function createTokenLines(prefix: string, width: number, lines?: string[]): TokenLines;
export declare function openTokenLines(sink: TokenLines, prefix: string, width: number, lines: string[]): void;
export declare function addToken(sink: TokenLines, text: string): void;
export declare function addWrittenToken(sink: TokenLines, index: number, name?: string): void;
export declare function addWrittenTokens(sink: TokenLines, count: number): void;
export declare function endTokenLine(sink: TokenLines): void;
export declare function parseRecord(tokens: readonly string[]): Record<string, unknown> | undefined;
export declare function tokenLines(tokens: readonly string[], width: number): string[];
export declare function lineTokens(lines: readonly string[]): string[];
