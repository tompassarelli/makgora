/** @noSelfInFile */
import type { SyncMessage } from "./clientTypes";
import type { SyncDelivery } from "./lockstep";
import { type CallbackTiming } from "./frameRate";
export { type CallbackTiming, EVEN_CALLBACKS } from "./frameRate";
export interface SyncLatency {
    readonly latencyMs: number;
    readonly turnMs: number;
    readonly extraTurns: readonly number[];
}
export declare const MEASURED_BATTLE_NET: SyncLatency;
export declare const CALLBACK_MS: number;
export declare function syncAgeMs(latency: SyncLatency, frame: number, extraTurns: number): number;
export declare function syncDelivery(latency?: SyncLatency, seed?: number): SyncDelivery;
export interface ReplayedArrival {
    readonly accepts: (this: void, message: SyncMessage) => boolean;
    readonly atMs: number;
}
export declare function replayedDelivery(arrivals: (this: void) => readonly ReplayedArrival[], fallback: SyncDelivery, nowMs: (this: void) => number): SyncDelivery;
export interface TurnBurstModel {
    readonly turnMs: number;
    readonly jitterMs: number;
    readonly hitchChance: number;
    readonly hitchMeanMs: number;
}
export declare const MEASURED_TURN_BURSTS: TurnBurstModel;
export declare function turnBursts(model?: TurnBurstModel, seed?: number): CallbackTiming;
