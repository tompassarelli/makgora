/** @noSelfInFile */
import type { CameraPose, CineFilterPose, ClientFiles, EffectDeaths, EffectPose, Handle, IntentionalNoops, LocalNatives, MissingNative, NativeBehaviors, NativeCall, SoundCue, SyncMessage, UnitPose, UnitStateFixtures } from "./clientTypes";
import type { NativeDeclarations } from "./declarations";
import { type Frame, type FrameTemplate, Frames } from "./frames";
import { FRAMES_PER_SECOND } from "./frameRate";
import { Lightnings } from "./lightnings";
import { TextTags } from "./textTags";
import { type AbilityObjectFixtures, Warcraft3Abilities } from "./warcraft3Abilities";
import { Warcraft3Inventory, type Warcraft3InventoryFixtures } from "./warcraft3Inventory";
import { Scenery, type SceneryFixtures } from "./warcraft3Scenery";
export type { CameraPose, CineFilterPose, ClientFiles, EffectDeaths, EffectPose, Handle, IntentionalNoops, LocalNatives, MapEntry, MissingNative, NativeBehavior, NativeBehaviors, NativeCall, SoundCue, SyncMessage, UnitPose, UnitStateFixture, UnitStateFixtures } from "./clientTypes";
export { describeCall, describeNumber, describeValue, sameCall } from "./jassFormat";
export { assertSoundCue } from "./natives/sound";
export { FRAMES_PER_SECOND };
export interface ClientScope {
    enter(this: void, client: HeadlessClient): void;
    leave(this: void, client: HeadlessClient): void;
}
export interface ClientOptions {
    readonly abilityObjects?: AbilityObjectFixtures;
    readonly unitStates?: UnitStateFixtures;
    readonly scenery?: SceneryFixtures;
    readonly inventory?: Warcraft3InventoryFixtures;
    readonly slot: number;
    readonly filePrefix: string;
    readonly humans: readonly number[];
    readonly playerNames?: Readonly<Record<number, string>>;
    readonly declarations: NativeDeclarations;
    readonly localNatives: LocalNatives;
    readonly intentionalNoops?: IntentionalNoops;
    readonly network: SyncMessage[];
    /** Pixels `BlzGetLocalClientWidth/Height`, `BlzPixelToFrame*` and `BlzFrameToPixel*` read. */
    readonly screen: {
        readonly width: number;
        readonly height: number;
    };
    readonly scope?: ClientScope;
    readonly natives?: (this: void, client: HeadlessClient) => NativeBehaviors;
    readonly files?: ClientFiles;
    readonly frames?: readonly FrameTemplate[];
    readonly effectDeaths?: EffectDeaths;
    readonly musicSlider?: number;
}
export declare const WISP_LOCAL_NATIVES: LocalNatives;
export declare class HeadlessClient {
    readonly scenery: Scenery;
    readonly inventory: Warcraft3Inventory;
    readonly abilities: Warcraft3Abilities;
    readonly textTags: TextTags;
    readonly lightnings: Lightnings;
    readonly textAreaAutoScroll: Map<Handle, boolean>;
    readonly heldMouseButtons: Set<unknown>;
    mouseScreenX: number;
    mouseScreenY: number;
    private heldMeta;
    readonly slot: number;
    readonly log: NativeCall[];
    forgotten: number;
    private forgottenHash;
    readonly errors: string[];
    readonly missingNatives: MissingNative[];
    readonly messages: string[];
    readonly thrown: string[];
    readonly files: Map<string, string[]>;
    readonly published: Map<string, readonly string[]>;
    missedLookups: number;
    readonly natives: Record<string, unknown>;
    frame: number;
    private wallSeconds;
    clockSeconds(): number;
    setWallTime(seconds: number): void;
    private nextId;
    private readonly scope;
    private readonly heldKeys;
    private readonly units;
    private readonly effects;
    private readonly sounds;
    private readonly camera;
    private readonly preloadText;
    private readonly timers;
    readonly soundLog: SoundCue[];
    readonly frames: Frames;
    constructor(options: ClientOptions);
    private handle;
    private defaultNative;
    private defaultValue;
    liveHandleCounts(): {
        readonly locations: number;
        readonly groups: number;
    };
    private behaviors;
    preloadedFiles(): string[];
    effectPoses(options?: {
        readonly visibleOnly?: boolean;
    }): EffectPose[];
    cineFilterPose(): CineFilterPose | undefined;
    cameraPose(): CameraPose;
    unitPoses(): UnitPose[];
    run(body: (this: void) => void): void;
    step(draw?: boolean): void;
    draw(seconds: number): void;
    deliverSync(message: SyncMessage): void;
    chat(sender: number, message: string): void;
    key(sender: number, key: number, meta: number, down: boolean): void;
    hold(key: number, meta: number, down: boolean): void;
    keyEvent(sender: number, key: number, meta: number, down: boolean): void;
    type(text: string): boolean;
    clickTarget(x: number, y: number): Frame | undefined;
    frameEvent(sender: number, id: number, event: unknown): void;
    callCount(): number;
    forget(count: number): void;
    checksum(): string;
}
