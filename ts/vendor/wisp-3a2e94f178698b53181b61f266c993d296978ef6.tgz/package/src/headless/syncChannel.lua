local ____lualib = require("lualib_bundle")
local __TS__ArrayReduce = ____lualib.__TS__ArrayReduce
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local Map = ____lualib.Map
local Set = ____lualib.Set
local __TS__ArrayFind = ____lualib.__TS__ArrayFind
local __TS__ArrayAt = ____lualib.__TS__ArrayAt
local ____exports = {}
local ____random = require("src.headless.random")
local ____f32 = require("src.sim.f32")
local ____frameRate = require("src.headless.frameRate")
do
    local ____frameRate = require("src.headless.frameRate")
    ____exports.EVEN_CALLBACKS = ____frameRate.EVEN_CALLBACKS
end
____exports.MEASURED_BATTLE_NET = {latencyMs = 80, turnMs = 25, extraTurns = {
    0xcccccdp-25,
    0xf5c28fp-26,
    0x24dd2fp-24,
    0x2c3c9fp-25,
    0x6a2b17p-27,
    0xfecdd1p-29,
    0x263879p-27,
    0x16eeafp-27,
    0x44cc0dp-28
}}
____exports.CALLBACK_MS = ____frameRate.FRAME_MS
function ____exports.syncAgeMs(latency, frame, extraTurns)
    local sentMs = frame * ____exports.CALLBACK_MS
    local turn = math.ceil((sentMs + latency.latencyMs) / latency.turnMs - 0x89705fp-53) + extraTurns
    return turn * latency.turnMs - sentMs
end
local function turnsFor(probabilities, draw)
    local rest = draw
    do
        local turns = 0
        while turns < #probabilities - 1 do
            rest = rest - (probabilities[turns + 1] or 0)
            if rest <= 0 then
                return turns
            end
            turns = turns + 1
        end
    end
    return #probabilities - 1
end
function ____exports.syncDelivery(latency, seed)
    if latency == nil then
        latency = ____exports.MEASURED_BATTLE_NET
    end
    if seed == nil then
        seed = 1
    end
    local total = __TS__ArrayReduce(
        latency.extraTurns,
        function(____, sum, p) return sum + p end,
        0
    )
    if math.abs(total - 1) > 0x8637bdp-43 then
        do
            local ____thrown = __TS__New(
                Error,
                ("extra-turn probabilities sum to " .. tostring(total)) .. ", not 1"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:46"
            end
            error(____thrown, 0)
        end
    end
    if not (latency.turnMs > 0) or not (latency.latencyMs >= 0) then
        do
            local ____thrown = __TS__New(Error, "turn length must be positive and latency not negative")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:47"
            end
            error(____thrown, 0)
        end
    end
    local senders = __TS__New(Map)
    return {arrivalFrame = function(sender, frame, _message)
        local state = senders:get(sender)
        if state == nil then
            state = {
                random = __TS__New(____random.Random, seed * 7919 + sender * 104729 + 1),
                lastArrivalMs = 0
            }
            senders:set(sender, state)
        end
        local arrivalMs = math.max(
            state.lastArrivalMs,
            frame * ____exports.CALLBACK_MS + ____exports.syncAgeMs(
                latency,
                frame,
                turnsFor(
                    latency.extraTurns,
                    state.random:next()
                )
            )
        )
        state.lastArrivalMs = arrivalMs
        return math.max(
            frame + 1,
            math.ceil(arrivalMs / ____exports.CALLBACK_MS - 0x89705fp-53)
        )
    end}
end
function ____exports.replayedDelivery(arrivals, fallback, nowMs)
    local used = __TS__New(Set)
    local last = __TS__New(Map)
    return {arrivalFrame = function(sender, frame, message)
        local replayed = __TS__ArrayFind(
            arrivals(),
            function(____, arrival) return not used:has(arrival) and arrival.accepts(message) end
        )
        local arrival
        if replayed == nil then
            arrival = fallback.arrivalFrame(sender, frame, message)
        else
            used:add(replayed)
            arrival = frame + math.ceil((replayed.atMs - nowMs()) / ____exports.CALLBACK_MS - 0x89705fp-53)
        end
        arrival = math.max(
            frame + 1,
            last:get(sender) or 0,
            arrival
        )
        last:set(sender, arrival)
        return arrival
    end}
end
____exports.MEASURED_TURN_BURSTS = {turnMs = 25, jitterMs = 12, hitchChance = 0x51eb85p-30, hitchMeanMs = 30}
function ____exports.turnBursts(model, seed)
    if model == nil then
        model = ____exports.MEASURED_TURN_BURSTS
    end
    if seed == nil then
        seed = 1
    end
    if not (model.turnMs >= ____exports.CALLBACK_MS) or not (model.jitterMs >= 0) or not (model.hitchChance >= 0 and model.hitchChance < 1) or not (model.hitchMeanMs >= 0) then
        do
            local ____thrown = __TS__New(Error, "a turn must last at least one callback, and jitter, hitch chance and hitch length must not be negative")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/headless/syncChannel.ts:106"
            end
            error(____thrown, 0)
        end
    end
    local function turnOf(frame)
        return math.max(
            1,
            math.ceil(frame * ____exports.CALLBACK_MS / model.turnMs - 0x89705fp-53)
        )
    end
    local lag = 0
    local cycle = 6000
    do
        local frame = 1
        while frame <= cycle do
            lag = lag + (turnOf(frame) * model.turnMs - frame * ____exports.CALLBACK_MS)
            frame = frame + 1
        end
    end
    local offset = lag / cycle + model.jitterMs / 2 + model.hitchChance * model.hitchMeanMs
    local random = __TS__New(____random.Random, seed * 7919 + 15485863)
    local walls = {}
    local function turnWall(turn)
        while #walls < turn do
            local jitter = random:next() * model.jitterMs
            if random:chance(model.hitchChance) then
                jitter = jitter - model.hitchMeanMs * math.log(1 - random:next())
            end
            walls[#walls + 1] = math.max(
                __TS__ArrayAt(walls, -1) or 0,
                (#walls + 1) * model.turnMs + jitter - offset
            )
        end
        return walls[turn] or 0
    end
    return {wallMs = function(frame) return frame <= 0 and frame * ____exports.CALLBACK_MS or turnWall(turnOf(frame)) end}
end
return ____exports
