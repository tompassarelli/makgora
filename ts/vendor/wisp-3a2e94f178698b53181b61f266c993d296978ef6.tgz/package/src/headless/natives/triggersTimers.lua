local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local __TS__ArraySome = ____lualib.__TS__ArraySome
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__StringSlice = ____lualib.__TS__StringSlice
local ____exports = {}
local ____binary32 = require("src.sim.binary32")
local ____f32 = require("src.sim.f32")
local ____frameRate = require("src.headless.frameRate")
local ____frames = require("src.headless.natives.frames")
local ____timerDeadline = require("src.headless.natives.timerDeadline")
--- The shortest repeating period: a zero period fires about 10,000 times a game second (wisp:docs/warsmash-notes.md#timers-and-frame-stepping).
local MIN_PERIOD = 0xd1b717p-37
local MIN_ONE_SHOT = 0x1p-10
local function frameEnd(frame)
    return ____binary32.divideFloat32(frame, ____frameRate.FRAMES_PER_SECOND)
end
local SYNC_DATA_LIMIT = 255
____exports.TriggersTimers = __TS__Class()
local TriggersTimers = ____exports.TriggersTimers
TriggersTimers.name = "TriggersTimers"
function TriggersTimers.prototype.____constructor(self, handle, units)
    self.handle = handle
    self.units = units
    self.timers = {}
    self.spellHits = {}
    self.timerOrder = 0
    self.now = 0
    self.registrations = {}
    self.event = {
        player = 0,
        syncPrefix = "",
        syncData = "",
        chat = "",
        key = 0,
        timer = nil,
        frame = nil,
        frameEvent = nil
    }
end
function TriggersTimers.prototype.time(self)
    return self.now
end
function TriggersTimers.prototype.hit(self, target, due, damage)
    local ____self_spellHits_0 = self.spellHits
    ____self_spellHits_0[#____self_spellHits_0 + 1] = {target = target, due = due, damage = damage}
end
function TriggersTimers.prototype.fire(self, trigger, event)
    if trigger.destroyed then
        return
    end
    if event.player ~= nil then
        self.event.player = event.player
    end
    if event.syncPrefix ~= nil then
        self.event.syncPrefix = event.syncPrefix
    end
    if event.syncData ~= nil then
        self.event.syncData = event.syncData
    end
    if event.chat ~= nil then
        self.event.chat = event.chat
    end
    if event.key ~= nil then
        self.event.key = event.key
    end
    if event.frame ~= nil then
        self.event.frame = event.frame
    end
    if event.frameEvent ~= nil then
        self.event.frameEvent = event.frameEvent
    end
    local running = trigger.running
    local interrupted = trigger.interrupted
    trigger.running = true
    trigger.interrupted = false
    do
        local ____try, ____error = pcall(function()
            for ____, action in ipairs(trigger.actions) do
                if trigger.interrupted then
                    break
                end
                action()
            end
        end)
        do
            trigger.running = running
            trigger.interrupted = interrupted
        end
        if not ____try then
            error(____error, 0)
        end
    end
end
function TriggersTimers.prototype.timerElapsed(self, timer)
    if timer.paused ~= nil then
        return timer.paused
    end
    if timer.expired then
        return timer.timeout
    end
    if not timer.running then
        return 0
    end
    local remaining = timer.due > self.now and ____binary32.subtractFloat32TowardZero(timer.due, self.now) or 0
    return remaining < timer.period and ____binary32.subtractFloat32TowardZero(timer.period, remaining) or 0
end
function TriggersTimers.prototype.runDue(self, frame)
    local ____end = frameEnd(frame)
    self.now = ____end
    do
        while true do
            do
                local next
                for ____, timer in ipairs(self.timers) do
                    do
                        if not timer.running or timer.callback == nil or timer.due > ____end then
                            goto __continue27
                        end
                        if next == nil or timer.due < next.due or timer.due == next.due and timer.order < next.order then
                            next = timer
                        end
                    end
                    ::__continue27::
                end
                local hitIndex = -1
                do
                    local index = 0
                    while index < #self.spellHits do
                        local hit = self.spellHits[index + 1]
                        local earliest = self.spellHits[hitIndex + 1]
                        if hit ~= nil and hit.due <= ____end and (next == nil or hit.due <= next.due) and (earliest == nil or hit.due < earliest.due) then
                            hitIndex = index
                        end
                        index = index + 1
                    end
                end
                local hit = self.spellHits[hitIndex + 1]
                if hit ~= nil then
                    __TS__ArraySplice(self.spellHits, hitIndex, 1)
                    self.now = hit.due
                    self.units:strike(hit.target, hit.damage)
                    goto __continue26
                end
                if next == nil or next.callback == nil then
                    break
                end
                self.now = next.due
                if next.periodic then
                    next.due = ____timerDeadline.after(next.due, next.period)
                else
                    next.running = false
                    next.expired = true
                end
                self.event.timer = next
                do
                    local ____try, ____error = pcall(function()
                        next.callback()
                    end)
                    do
                        self.now = ____end
                    end
                    if not ____try then
                        error(____error, 0)
                    end
                end
            end
            ::__continue26::
        end
    end
end
function TriggersTimers.prototype.deliverSync(self, ____bindingPattern0)
    local data
    local prefix
    local sender
    sender = ____bindingPattern0.sender
    prefix = ____bindingPattern0.prefix
    data = ____bindingPattern0.data
    for ____, registration in ipairs({table.unpack(self.registrations)}) do
        if registration.kind == "sync" and registration.player == sender and registration.prefix == prefix then
            self:fire(registration.trigger, {player = sender, syncPrefix = prefix, syncData = data})
        end
    end
end
function TriggersTimers.prototype.chat(self, sender, message)
    for ____, registration in ipairs({table.unpack(self.registrations)}) do
        do
            if registration.kind ~= "chat" or registration.player ~= sender then
                goto __continue45
            end
            local ____registration_exact_1
            if registration.exact then
                ____registration_exact_1 = message == registration.text
            else
                ____registration_exact_1 = __TS__StringIncludes(message, registration.text)
            end
            if ____registration_exact_1 then
                self:fire(registration.trigger, {player = sender, chat = message})
            end
        end
        ::__continue45::
    end
end
function TriggersTimers.prototype.keyEvent(self, sender, key, meta, down)
    for ____, registration in ipairs({table.unpack(self.registrations)}) do
        if registration.kind == "key" and registration.player == sender and registration.key == key and registration.meta == meta and registration.down == down then
            self:fire(registration.trigger, {player = sender, key = key})
        end
    end
end
function TriggersTimers.prototype.frameEvent(self, sender, id, event)
    for ____, registration in ipairs({table.unpack(self.registrations)}) do
        if registration.kind == "frame" and registration.frame.id == id and registration.event == event then
            self:fire(registration.trigger, {player = sender, frame = registration.frame, frameEvent = event})
        end
    end
end
function TriggersTimers.prototype.handles(self, frame, event)
    return __TS__ArraySome(
        self.registrations,
        function(____, registration) return registration.kind == "frame" and registration.frame == frame and registration.event == event and not registration.trigger.destroyed end
    )
end
function TriggersTimers.prototype.behaviors(self, slot, network)
    return __TS__ObjectAssign(
        {},
        self:triggerBehaviors(),
        {
            CreateTimer = function()
                local timer = __TS__ObjectAssign(
                    {},
                    self.handle("timer"),
                    {
                        callback = nil,
                        periodic = false,
                        timeout = 0,
                        period = 0,
                        due = 0,
                        order = 0,
                        running = false,
                        expired = false,
                        paused = nil
                    }
                )
                local ____self_timers_2 = self.timers
                ____self_timers_2[#____self_timers_2 + 1] = timer
                return timer
            end,
            TimerStart = function(timer, timeout, periodic, callback)
                local seconds = ____binary32.roundToFloat32(timeout)
                local shortest = periodic and MIN_PERIOD or MIN_ONE_SHOT
                timer.callback = callback
                timer.periodic = periodic
                timer.timeout = seconds
                timer.period = seconds >= shortest and seconds or shortest
                timer.due = ____timerDeadline.after(self.now, timer.period)
                local ____timer_6 = timer
                local ____self_3, ____timerOrder_4 = self, "timerOrder"
                local ____self_timerOrder_5 = ____self_3[____timerOrder_4] + 1
                ____self_3[____timerOrder_4] = ____self_timerOrder_5
                ____timer_6.order = ____self_timerOrder_5
                timer.running = true
                timer.expired = false
                timer.paused = nil
            end,
            PauseTimer = function(timer)
                if timer.running then
                    timer.paused = self:timerElapsed(timer)
                end
                timer.running = false
            end,
            DestroyTimer = function(timer)
                timer.running = false
                local index = __TS__ArrayIndexOf(self.timers, timer)
                if index >= 0 then
                    __TS__ArraySplice(self.timers, index, 1)
                end
            end,
            TimerGetElapsed = function(timer) return self:timerElapsed(timer) end,
            BlzSendSyncData = function(prefix, data)
                network[#network + 1] = {
                    sender = slot,
                    prefix = prefix,
                    data = __TS__StringSlice(data, 0, SYNC_DATA_LIMIT)
                }
                return true
            end
        }
    )
end
function TriggersTimers.prototype.triggerBehaviors(self)
    return {
        GetTriggerPlayer = function() return self.event.player end,
        BlzTriggerRegisterFrameEvent = function(trigger, frame, event)
            if ____frames.isFrame(frame) then
                local ____self_registrations_7 = self.registrations
                ____self_registrations_7[#____self_registrations_7 + 1] = {kind = "frame", trigger = trigger, frame = frame, event = event}
            end
            return self.handle("event")
        end,
        BlzGetTriggerFrame = function() return self.event.frame end,
        BlzGetTriggerFrameEvent = function() return self.event.frameEvent end,
        BlzGetTriggerFrameText = function()
            local ____opt_8 = self.event.frame
            return ____opt_8 and ____opt_8.text or ""
        end,
        BlzGetTriggerSyncData = function() return self.event.syncData end,
        BlzGetTriggerSyncPrefix = function() return self.event.syncPrefix end,
        GetEventPlayerChatString = function() return self.event.chat end,
        BlzGetTriggerPlayerKey = function() return self.event.key end,
        GetExpiredTimer = function() return self.event.timer end,
        CreateTrigger = function() return __TS__ObjectAssign(
            {},
            self.handle("trigger"),
            {actions = {}, destroyed = false, running = false, interrupted = false}
        ) end,
        BlzTriggerIsRunning = function(trigger) return trigger.running end,
        BlzTriggerInterrupt = function(trigger)
            trigger.interrupted = true
        end,
        DestroyTrigger = function(trigger)
            trigger.destroyed = true
        end,
        TriggerAddAction = function(trigger, action)
            local ____trigger_actions_10 = trigger.actions
            ____trigger_actions_10[#____trigger_actions_10 + 1] = action
            return self.handle("triggeraction")
        end,
        BlzTriggerRegisterPlayerSyncEvent = function(trigger, player, prefix)
            local ____self_registrations_11 = self.registrations
            ____self_registrations_11[#____self_registrations_11 + 1] = {kind = "sync", trigger = trigger, player = player, prefix = prefix}
            return self.handle("event")
        end,
        TriggerRegisterPlayerChatEvent = function(trigger, player, text, exact)
            local ____self_registrations_12 = self.registrations
            ____self_registrations_12[#____self_registrations_12 + 1] = {
                kind = "chat",
                trigger = trigger,
                player = player,
                text = text,
                exact = exact
            }
            return self.handle("event")
        end,
        BlzTriggerRegisterPlayerKeyEvent = function(trigger, player, key, meta, down)
            local ____self_registrations_13 = self.registrations
            ____self_registrations_13[#____self_registrations_13 + 1] = {
                kind = "key",
                trigger = trigger,
                player = player,
                key = key,
                meta = meta,
                down = down
            }
            return self.handle("event")
        end
    }
end
return ____exports
