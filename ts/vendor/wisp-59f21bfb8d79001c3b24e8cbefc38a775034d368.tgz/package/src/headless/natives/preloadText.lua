local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__Spread = ____lualib.__TS__Spread
local __TS__StringSlice = ____lualib.__TS__StringSlice
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
____exports.PreloadText = __TS__Class()
local PreloadText = ____exports.PreloadText
PreloadText.name = "PreloadText"
function PreloadText.prototype.____constructor(self, context)
    self.context = context
    self.tooltips = __TS__New(Map)
    self.preloaded = __TS__New(Map)
    self.preload = {}
end
function PreloadText.prototype.preloadedFiles(self)
    return {__TS__Spread(self.preloaded:keys())}
end
function PreloadText.prototype.report(self, lines)
    local heading = lines[1] or ""
    local ____self_context_errors_0 = self.context.errors
    ____self_context_errors_0[#____self_context_errors_0 + 1] = (("error in " .. __TS__StringSlice(
        heading,
        (string.find(heading, " in ", nil, true) or 0) - 1 + 4
    )) .. ": ") .. (lines[2] or "")
end
function PreloadText.prototype.behaviors(self)
    local ____self_context_1 = self.context
    local slot = ____self_context_1.slot
    local filePrefix = ____self_context_1.filePrefix
    local stored = ____self_context_1.stored
    local files = ____self_context_1.files
    local published = ____self_context_1.published
    local messages = ____self_context_1.messages
    local function show(text)
        messages[#messages + 1] = text
    end
    return {
        DisplayTextToPlayer = function(player, _x, _y, text)
            if player == slot then
                show(text)
            end
        end,
        DisplayTimedTextToPlayer = function(player, _x, _y, _duration, text)
            if player == slot then
                show(text)
            end
        end,
        DisplayTextToForce = function(_force, text) return show(text) end,
        PreloadGenClear = function()
            self.preload = {}
        end,
        PreloadGenStart = function() return nil end,
        Preload = function(line)
            local ____self_preload_2 = self.preload
            ____self_preload_2[#____self_preload_2 + 1] = line
        end,
        PreloadGenEnd = function(name)
            files:set(name, self.preload)
            if name == ____gameFiles.errorFile(slot, filePrefix) then
                self:report(self.preload)
            end
            if stored ~= nil then
                stored.written(name, self.preload)
            end
        end,
        Preloader = function(name)
            local chunks = self.preloaded:get(name) or published:get(name) or stored and stored.read(name)
            if chunks == nil then
                self.context.missed()
                return
            end
            self.preloaded:set(name, chunks)
            do
                local level = 0
                while level < #chunks do
                    self.tooltips:set(
                        (tostring(____gameFiles.FILE_IO_ABILITY) .. " ") .. tostring(level),
                        chunks[level + 1] or ""
                    )
                    level = level + 1
                end
            end
        end,
        BlzSetAbilityTooltip = function(ability, text, level)
            self.tooltips:set(
                (tostring(ability) .. " ") .. tostring(level),
                text
            )
        end,
        BlzGetAbilityTooltip = function(ability, level) return self.tooltips:get((tostring(ability) .. " ") .. tostring(level)) or "" end
    }
end
return ____exports
