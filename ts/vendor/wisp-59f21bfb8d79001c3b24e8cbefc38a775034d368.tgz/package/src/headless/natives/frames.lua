local ____lualib = require("lualib_bundle")
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local __TS__StringSlice = ____lualib.__TS__StringSlice
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__StringReplace = ____lualib.__TS__StringReplace
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____frames = require("src.headless.frames")
local ____jassFormat = require("src.headless.jassFormat")
____exports.isFrame = function(value) return type(value) == "table" and value ~= nil and value.points ~= nil end
function ____exports.inputNatives(____bindingPattern0)
    local mouseY
    local mouseX
    local mouseButtonPressed
    local metaPressed
    local keyPressed
    local textAreaAutoScroll
    local screen
    screen = ____bindingPattern0.screen
    textAreaAutoScroll = ____bindingPattern0.textAreaAutoScroll
    keyPressed = ____bindingPattern0.keyPressed
    metaPressed = ____bindingPattern0.metaPressed
    mouseButtonPressed = ____bindingPattern0.mouseButtonPressed
    mouseX = ____bindingPattern0.mouseX
    mouseY = ____bindingPattern0.mouseY
    return {
        BlzGetLocalClientWidth = function() return screen.width end,
        BlzGetLocalClientHeight = function() return screen.height end,
        BlzIsLocalClientActive = function() return true end,
        BlzIsKeyPressed = function(key) return keyPressed(key) end,
        BlzIsMetaKeyPressed = function(meta) return metaPressed(meta) end,
        BlzIsMouseButtonPressed = function(button) return mouseButtonPressed(button) end,
        BlzGetMouseScreenPosX = function() return mouseX() end,
        BlzGetMouseScreenPosY = function() return mouseY() end,
        BlzPixelToFrameX = function(pixel) return __wispF32Divide(pixel * 0xcccccdp-24, screen.width) end,
        BlzPixelToFrameY = function(pixel) return __wispF32Divide(pixel * 0x4ccccdp-23, screen.height) end,
        BlzFrameToPixelX = function(frame) return math.floor(frame * screen.width / 0xcccccdp-24 + 0x1p-1) end,
        BlzFrameToPixelY = function(frame) return math.floor(frame * screen.height / 0x4ccccdp-23 + 0x1p-1) end,
        BlzTextAreaFrameSetAutoScroll = function(frame, value)
            textAreaAutoScroll:set(frame, value)
        end,
        BlzLoadTOCFile = function() return true end
    }
end
function ____exports.frameNatives(____bindingPattern0)
    local gameUiOrigin
    local frames
    local handle
    handle = ____bindingPattern0.handle
    frames = ____bindingPattern0.frames
    gameUiOrigin = ____bindingPattern0.gameUiOrigin
    local memo = __TS__New(Map)
    local function memoized(key, name)
        if name == nil then
            name = ""
        end
        local known = memo:get(key)
        if known ~= nil then
            return known
        end
        local created = frames():add(
            handle("framehandle"),
            "",
            name,
            nil,
            0
        )
        memo:set(key, created)
        return created
    end
    local function created(____type, name, owner, context)
        return frames():add(
            handle("framehandle"),
            ____type,
            name,
            ____exports.isFrame(owner) and owner or nil,
            context
        )
    end
    return {
        BlzGetOriginFrame = function(____type, index)
            local frame = memoized((("origin " .. ____jassFormat.describeValue(____type)) .. " ") .. tostring(index))
            if ____type == gameUiOrigin() then
                frames().gameUi:add(frame)
            end
            return frame
        end,
        BlzGetFrameByName = function(name, context) return frames():named(name, context) or memoized(
            (("name " .. name) .. " ") .. tostring(context),
            name
        ) end,
        BlzFrameGetChildrenCount = function(frame) return ____exports.isFrame(frame) and #frames():children(frame) or 0 end,
        BlzFrameGetChild = function(frame, index)
            local ____isFrame_result_0
            if ____exports.isFrame(frame) then
                ____isFrame_result_0 = frames():children(frame)[index + 1]
            else
                ____isFrame_result_0 = nil
            end
            return ____isFrame_result_0 or memoized((("child " .. tostring(frame.id)) .. " ") .. tostring(index))
        end,
        BlzCreateFrame = function(name, owner, _priority, context) return frames():create(
            function() return handle("framehandle") end,
            name,
            ____exports.isFrame(owner) and owner or nil,
            context
        ) end,
        BlzCreateSimpleFrame = function(name, owner, context) return created(name, name, owner, context) end,
        BlzCreateFrameByType = function(____type, name, owner, _inherits, context) return created(____type, name, owner, context) end,
        BlzDestroyFrame = function(frame)
            if ____exports.isFrame(frame) then
                frames():destroy(frame)
            end
        end,
        BlzFrameGetName = function(frame) return ____exports.isFrame(frame) and frame.name or "" end,
        BlzFrameGetParent = function(frame)
            local ____isFrame_result_1
            if ____exports.isFrame(frame) then
                ____isFrame_result_1 = frame.parent
            else
                ____isFrame_result_1 = nil
            end
            return ____isFrame_result_1
        end,
        BlzFrameSetText = function(frame, text)
            if ____exports.isFrame(frame) then
                frame.text = frame.textLimit >= 0 and __TS__StringSlice(text, 0, frame.textLimit) or text
            end
        end,
        BlzFrameGetText = function(frame) return ____exports.isFrame(frame) and frame.text or "" end,
        BlzFrameSetTexture = function(frame, texture)
            if ____exports.isFrame(frame) then
                frame.texture = texture
            end
        end,
        BlzFrameSetVertexColor = function(frame, color)
            if ____exports.isFrame(frame) then
                frame.color = color
            end
        end,
        BlzFrameSetTextColor = function(frame, color)
            if ____exports.isFrame(frame) then
                frame.textColor = color
            end
        end,
        BlzFrameSetAlpha = function(frame, alpha)
            if ____exports.isFrame(frame) then
                frame.alpha = alpha
            end
        end,
        BlzFrameGetAlpha = function(frame) return ____exports.isFrame(frame) and frame.alpha or 0 end,
        BlzFrameSetTextSizeLimit = function(frame, size)
            if ____exports.isFrame(frame) then
                frame.textLimit = size
            end
        end,
        BlzFrameGetTextSizeLimit = function(frame) return ____exports.isFrame(frame) and frame.textLimit or 0 end,
        BlzFrameSetFont = function(frame, file, height, flags)
            if ____exports.isFrame(frame) then
                frame.font = {file = file, height = height, flags = flags}
            end
        end,
        BlzFrameSetTextAlignment = function(frame, vertical, horizontal)
            if ____exports.isFrame(frame) then
                frame.alignment = {vertical = vertical, horizontal = horizontal}
            end
        end,
        BlzFrameSetScale = function(frame, scale)
            if ____exports.isFrame(frame) then
                frame.scale = scale
            end
        end,
        BlzFrameSetVisible = function(frame, visible)
            if ____exports.isFrame(frame) then
                frame.visible = visible
            end
        end,
        BlzFrameIsVisible = function(frame)
            local ____isFrame_result_2
            if ____exports.isFrame(frame) then
                ____isFrame_result_2 = frames():shown(frame)
            else
                ____isFrame_result_2 = false
            end
            return ____isFrame_result_2
        end,
        BlzFrameSetEnable = function(frame, enabled)
            if ____exports.isFrame(frame) then
                frame.enabled = enabled
            end
        end,
        BlzFrameGetEnable = function(frame)
            local ____isFrame_result_3
            if ____exports.isFrame(frame) then
                ____isFrame_result_3 = frame.enabled
            else
                ____isFrame_result_3 = false
            end
            return ____isFrame_result_3
        end,
        BlzFrameSetFocus = function(frame, flag)
            if ____exports.isFrame(frame) then
                frames():focus(frame, flag)
            end
        end,
        BlzFrameSetLevel = function(frame, level)
            if ____exports.isFrame(frame) then
                frame.level = level
            end
        end,
        BlzFrameSetSize = function(frame, width, height)
            if ____exports.isFrame(frame) then
                frame.width = width
                frame.height = height
            end
        end,
        BlzFrameSetAbsPoint = function(frame, point, x, y)
            if ____exports.isFrame(frame) then
                frame.points:set(point, {x = x, y = y})
            end
        end,
        BlzFrameClearAllPoints = function(frame)
            if ____exports.isFrame(frame) then
                frame.points:clear()
                __TS__ArraySetLength(frame.anchors, 0)
            end
        end,
        BlzFrameSetPoint = function(frame, point, relative, relativePoint, x, y)
            if not ____exports.isFrame(frame) or not ____exports.isFrame(relative) then
                return
            end
            local function name(value)
                local ____temp_6
                if type(value) == "number" then
                    local ____opt_4 = ____frames.FRAME_POINTS[value + 1]
                    ____temp_6 = ____opt_4 and ____opt_4[1] or ""
                else
                    ____temp_6 = type(value) == "string" and value or ""
                end
                return ____temp_6
            end
            local ownPoint = __TS__StringReplace(
                name(point),
                "FRAMEPOINT_",
                ""
            )
            do
                local index = #frame.anchors - 1
                while index >= 0 do
                    local ____opt_7 = frame.anchors[index + 1]
                    if (____opt_7 and ____opt_7.point) == ownPoint then
                        __TS__ArraySplice(frame.anchors, index, 1)
                    end
                    index = index - 1
                end
            end
            local ____frame_anchors_9 = frame.anchors
            ____frame_anchors_9[#____frame_anchors_9 + 1] = {
                point = ownPoint,
                relative = relative,
                relativePoint = __TS__StringReplace(
                    name(relativePoint),
                    "FRAMEPOINT_",
                    ""
                ),
                x = x,
                y = y
            }
        end,
        BlzFrameSetAllPoints = function(frame, relative)
            if not ____exports.isFrame(frame) or not ____exports.isFrame(relative) then
                return false
            end
            frame.points:clear()
            __TS__ArraySetLength(frame.anchors, 0)
            for ____, point in ipairs({"TOPLEFT", "BOTTOMRIGHT"}) do
                local ____frame_anchors_10 = frame.anchors
                ____frame_anchors_10[#____frame_anchors_10 + 1] = {
                    point = point,
                    relative = relative,
                    relativePoint = point,
                    x = 0,
                    y = 0
                }
            end
            return true
        end
    }
end
return ____exports
