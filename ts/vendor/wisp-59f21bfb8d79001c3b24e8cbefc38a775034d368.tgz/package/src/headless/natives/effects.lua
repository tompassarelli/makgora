local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local WeakMap = ____lualib.WeakMap
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local __TS__Iterator = ____lualib.__TS__Iterator
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local __TS__ArrayIncludes = ____lualib.__TS__ArrayIncludes
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____animation = require("src.headless.animation")
local ____frameRate = require("src.headless.frameRate")
local ____units = require("src.headless.natives.units")
____exports.Effects = __TS__Class()
local Effects = ____exports.Effects
Effects.name = "Effects"
function Effects.prototype.____constructor(self, handle, deaths, frame)
    self.handle = handle
    self.deaths = deaths
    self.frame = frame
    self.poses = __TS__New(Map)
    self.dying = {}
    self.settled = __TS__New(WeakMap)
    self.draws = 0
    self.drawSeconds = 0
end
function Effects.prototype.create(self, model, x, y)
    local handle = self.handle("effect")
    local pose = __TS__ObjectAssign(
        {},
        ____animation.freshAnimation(),
        {
            handle = handle,
            model = model,
            created = self.frame(),
            x = x,
            y = y,
            z = 0,
            alpha = 255,
            scale = 1,
            timeScale = 1,
            flat = false,
            queuedAnimations = {},
            yaw = 0,
            pitch = 0,
            roll = 0,
            color = {255, 255, 255},
            teamColor = 0,
            matrixScale = {1, 1, 1}
        }
    )
    self.poses:set(handle, pose)
    self.settled:set(pose, self.draws)
    return handle
end
function Effects.prototype.live(self, effect)
    local pose = self.poses:get(effect)
    local ____temp_2
    if (pose and pose.destroyed) == nil then
        ____temp_2 = pose
    else
        ____temp_2 = nil
    end
    return ____temp_2
end
function Effects.prototype.settle(self, pose)
    local settled = self.settled:get(pose) or self.draws
    if settled == self.draws then
        return
    end
    ____animation.settleAnimation(pose, pose.timeScale, self.drawSeconds, self.draws - settled)
    self.settled:set(pose, self.draws)
end
function Effects.prototype.destroy(self, effect)
    local pose = self:live(effect)
    if pose == nil then
        return
    end
    local ____opt_3 = self.deaths
    local death = ____opt_3 and ____opt_3(pose.model)
    self:settle(pose)
    pose.destroyed = self.frame()
    local ____self_dying_5 = self.dying
    ____self_dying_5[#____self_dying_5 + 1] = pose
    __TS__ArraySetLength(pose.queuedAnimations, 0)
    if death ~= nil and death > 0 then
        pose.death = death
        ____animation.selectAnimation(pose, "death", {})
    end
end
function Effects.prototype.play(self, effect, animation, timeScale)
    local pose = self:live(effect)
    if pose == nil then
        return
    end
    self:settle(pose)
    ____animation.selectAnimation(pose, animation, nil, true)
    if timeScale ~= nil then
        pose.timeScale = timeScale
    end
end
function Effects.prototype.snapshot(self, options)
    local poses = {}
    for ____, pose in __TS__Iterator(self.poses:values()) do
        if options.visibleOnly ~= true or pose.alpha > 0 and pose.scale > 0 and not pose.flat then
            self:settle(pose)
            poses[#poses + 1] = __TS__ObjectAssign(
                {},
                pose,
                {
                    subAnimations = {table.unpack(pose.subAnimations)},
                    animationBlend = ____units.copyBlend(pose.animationBlend),
                    color = {table.unpack(pose.color)},
                    matrixScale = {table.unpack(pose.matrixScale)}
                }
            )
        end
    end
    return poses
end
function Effects.prototype.draw(self, step)
    if step ~= self.drawSeconds then
        for ____, pose in __TS__Iterator(self.poses:values()) do
            self:settle(pose)
        end
        self.drawSeconds = step
    end
    self.draws = self.draws + 1
end
function Effects.prototype.expire(self, frame)
    local expired = 0
    while true do
        local ____temp_9 = expired < #self.dying
        if ____temp_9 then
            local ____frame_8 = frame
            local ____opt_6 = self.dying[expired + 1]
            ____temp_9 = ____frame_8 - (____opt_6 and ____opt_6.destroyed or frame) >= 5 * ____frameRate.FRAMES_PER_SECOND
        end
        if not ____temp_9 then
            break
        end
        expired = expired + 1
    end
    if expired > 0 then
        for ____, pose in ipairs(__TS__ArraySplice(self.dying, 0, expired)) do
            if self.poses:get(pose.handle) == pose then
                self.poses:delete(pose.handle)
            end
        end
    end
end
function Effects.prototype.behaviors(self)
    return __TS__ObjectAssign(
        {
            AddSpecialEffect = function(model, x, y) return self:create(model, x, y) end,
            AddSpecialEffectLoc = function(model) return self:create(model, 0, 0) end,
            AddSpecialEffectTarget = function(model) return self:create(model, 0, 0) end,
            DestroyEffect = function(effect) return self:destroy(effect) end,
            BlzRemoveEffect = function(effect)
                if self:live(effect) ~= nil then
                    self.poses:delete(effect)
                end
            end,
            BlzSetSpecialEffectAnimationBlendTime = function(effect, time)
                local pose = self:live(effect)
                if pose ~= nil then
                    pose.animationBlendTime = time
                end
            end,
            BlzSetSpecialEffectAnimation = function(effect, animation)
                local pose = self:live(effect)
                if pose ~= nil then
                    __TS__ArraySetLength(pose.queuedAnimations, 0)
                    self:play(effect, animation)
                end
            end,
            BlzQueueSpecialEffectAnimation = function(effect, animation)
                local pose = self:live(effect)
                if pose ~= nil then
                    local ____pose_queuedAnimations_10 = pose.queuedAnimations
                    ____pose_queuedAnimations_10[#____pose_queuedAnimations_10 + 1] = animation
                end
            end,
            BlzSetSpecialEffectTimeScale = function(effect, timeScale)
                local pose = self:live(effect)
                if pose == nil then
                    return
                end
                self:settle(pose)
                pose.timeScale = timeScale
            end,
            BlzSetSpecialEffectTime = function(effect, time)
                local pose = self:live(effect)
                if pose == nil then
                    return
                end
                self:settle(pose)
                ____animation.seekAnimation(pose, time)
            end,
            BlzPlaySpecialEffect = function(effect, animation) return self:play(effect, animation) end,
            BlzPlaySpecialEffectWithTimeScale = function(effect, animation, timeScale) return self:play(effect, animation, timeScale) end,
            BlzSpecialEffectClearSubAnimations = function(effect)
                local pose = self:live(effect)
                if pose ~= nil then
                    __TS__ArraySetLength(pose.subAnimations, 0)
                end
            end,
            BlzSpecialEffectAddSubAnimation = function(effect, animation)
                local pose = self:live(effect)
                if pose ~= nil and not __TS__ArrayIncludes(pose.subAnimations, animation) then
                    local ____pose_subAnimations_11 = pose.subAnimations
                    ____pose_subAnimations_11[#____pose_subAnimations_11 + 1] = animation
                end
            end,
            BlzSpecialEffectRemoveSubAnimation = function(effect, animation)
                local pose = self:live(effect)
                if pose == nil then
                    return
                end
                local index = __TS__ArrayIndexOf(pose.subAnimations, animation)
                if index >= 0 then
                    __TS__ArraySplice(pose.subAnimations, index, 1)
                end
            end,
            BlzGetLocalSpecialEffectX = function(effect)
                local ____opt_12 = self.poses:get(effect)
                return ____opt_12 and ____opt_12.x or 0
            end,
            BlzGetLocalSpecialEffectY = function(effect)
                local ____opt_14 = self.poses:get(effect)
                return ____opt_14 and ____opt_14.y or 0
            end,
            BlzGetLocalSpecialEffectZ = function(effect)
                local ____opt_16 = self.poses:get(effect)
                return ____opt_16 and ____opt_16.z or 0
            end
        },
        self:placement()
    )
end
function Effects.prototype.placement(self)
    return {
        BlzSetSpecialEffectPosition = function(effect, x, y, z)
            local pose = self:live(effect)
            if pose == nil then
                return
            end
            pose.x = x
            pose.y = y
            pose.z = z
        end,
        BlzSetSpecialEffectX = function(effect, x)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.x = x
            end
        end,
        BlzSetSpecialEffectY = function(effect, y)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.y = y
            end
        end,
        BlzSetSpecialEffectZ = function(effect, z)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.z = z
            end
        end,
        BlzSetSpecialEffectAlpha = function(effect, alpha)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.alpha = alpha
            end
        end,
        BlzSetSpecialEffectScale = function(effect, scale)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.scale = scale
            end
        end,
        BlzSetSpecialEffectOrientation = function(effect, yaw, pitch, roll)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.yaw = yaw
                pose.pitch = pitch
                pose.roll = roll
                pose.matrixScale = {1, 1, 1}
                pose.flat = false
            end
        end,
        BlzSetSpecialEffectYaw = function(effect, yaw)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.yaw = yaw
                pose.matrixScale = {1, 1, 1}
                pose.flat = false
            end
        end,
        BlzSetSpecialEffectPitch = function(effect, pitch)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.pitch = pitch
                pose.matrixScale = {1, 1, 1}
                pose.flat = false
            end
        end,
        BlzSetSpecialEffectRoll = function(effect, roll)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.roll = roll
                pose.matrixScale = {1, 1, 1}
                pose.flat = false
            end
        end,
        BlzSetSpecialEffectColor = function(effect, r, g, b)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.color = {r, g, b}
            end
        end,
        BlzSetSpecialEffectColorByPlayer = function(effect, player)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.teamColor = player
            end
        end,
        BlzSetSpecialEffectMatrixScale = function(effect, x, y, z)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.matrixScale = {
                    __wispF32Multiply(pose.matrixScale[1], x),
                    __wispF32Multiply(pose.matrixScale[2], y),
                    __wispF32Multiply(pose.matrixScale[3], z)
                }
                pose.flat = __TS__ArrayIncludes(pose.matrixScale, 0)
            end
        end,
        BlzResetSpecialEffectMatrix = function(effect)
            local pose = self:live(effect)
            if pose ~= nil then
                pose.flat = false
                pose.matrixScale = {1, 1, 1}
                pose.yaw = 0
                pose.pitch = 0
                pose.roll = 0
            end
        end
    }
end
return ____exports
