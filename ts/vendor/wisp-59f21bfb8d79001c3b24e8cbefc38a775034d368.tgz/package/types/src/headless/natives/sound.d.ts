/** @noSelfInFile */
import type { HandleFactory, NativeBehavior, SoundCue } from "../clientTypes";
export declare function assertSoundCue(log: readonly SoundCue[], expected: {
    readonly source?: string;
    readonly label?: string;
    readonly frame?: number;
    readonly count?: number;
}): void;
export declare class Sounds {
    private readonly handle;
    private readonly musicSlider;
    private readonly frame;
    readonly log: SoundCue[];
    private readonly sounds;
    private music;
    private musicVolume;
    constructor(handle: HandleFactory, musicSlider: number, frame: (this: void) => number);
    private create;
    private cue;
    private stop;
    private playMusic;
    private start;
    tick(): void;
    behaviors(): Readonly<Record<string, NativeBehavior>>;
}
