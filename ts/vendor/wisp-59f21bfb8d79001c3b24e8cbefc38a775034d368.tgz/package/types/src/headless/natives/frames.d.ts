/** @noSelfInFile */
import type { Handle, HandleFactory, NativeBehavior } from "../clientTypes";
import { type Frame, type Frames } from "../frames";
export declare const isFrame: (value: unknown) => value is Frame;
export interface FrameContext {
    readonly handle: HandleFactory;
    readonly frames: (this: void) => Frames;
    readonly gameUiOrigin: (this: void) => unknown;
    readonly screen: {
        readonly width: number;
        readonly height: number;
    };
    readonly textAreaAutoScroll: Map<Handle, boolean>;
    readonly keyPressed: (this: void, key: number) => boolean;
    readonly metaPressed: (this: void, meta: number) => boolean;
    readonly mouseButtonPressed: (this: void, button: unknown) => boolean;
    readonly mouseX: (this: void) => number;
    readonly mouseY: (this: void) => number;
}
export declare function inputNatives({ screen, textAreaAutoScroll, keyPressed, metaPressed, mouseButtonPressed, mouseX, mouseY }: FrameContext): Readonly<Record<string, NativeBehavior>>;
export declare function frameNatives({ handle, frames, gameUiOrigin }: FrameContext): Readonly<Record<string, NativeBehavior>>;
