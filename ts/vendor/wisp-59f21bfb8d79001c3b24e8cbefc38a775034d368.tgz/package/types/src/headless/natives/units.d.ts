/** @noSelfInFile */
import { type AnimationBlend } from "../animation";
import type { Handle, HandleFactory, NativeBehavior, UnitPose, UnitStateFixtures } from "../clientTypes";
import type { Warcraft3Abilities } from "../warcraft3Abilities";
export interface Unit extends Handle, UnitPose {
    moveSpeed: number;
    attackCooldown: number;
    life: number | undefined;
    maxLife: number | undefined;
    mana: number | undefined;
    maxMana: number | undefined;
    dead: boolean;
    removed: boolean;
}
export interface PlayerContext {
    readonly slot: number;
    readonly humans: readonly number[];
    readonly playerNames: Readonly<Record<number, string>> | undefined;
}
export declare const copyBlend: (blend: AnimationBlend | undefined) => AnimationBlend | undefined;
export declare class Units {
    private readonly states;
    private readonly handle;
    private readonly abilities;
    readonly live: Map<Handle, Unit>;
    private removals;
    private readonly passiveAlliances;
    private readonly locations;
    private readonly groups;
    private allPlayers;
    constructor(states: UnitStateFixtures, handle: HandleFactory, abilities: Warcraft3Abilities);
    liveHandleCounts(): {
        readonly locations: number;
        readonly groups: number;
    };
    create(owner: number, typeId: number, x: number, y: number, facing: number): Unit;
    value(unit: Unit, field: "life" | "maxLife" | "mana" | "maxMana"): number;
    setLife(unit: Unit, life: number): void;
    strike(target: Unit, damage: number): void;
    engageable(caster: Unit, target: Unit, range: number): boolean;
    draw(seconds: number): void;
    settleRemovals(): void;
    poses(): UnitPose[];
    playerBehaviors({ slot, humans, playerNames }: PlayerContext): Readonly<Record<string, NativeBehavior>>;
    behaviors(): Readonly<Record<string, NativeBehavior>>;
}
