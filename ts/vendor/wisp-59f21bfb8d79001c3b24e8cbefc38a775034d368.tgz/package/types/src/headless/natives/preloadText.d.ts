/** @noSelfInFile */
import type { ClientFiles, NativeBehavior } from "../clientTypes";
export interface PreloadContext {
    readonly slot: number;
    readonly filePrefix: string;
    readonly stored: ClientFiles | undefined;
    readonly files: Map<string, string[]>;
    readonly published: ReadonlyMap<string, readonly string[]>;
    readonly messages: string[];
    readonly errors: string[];
    readonly missed: (this: void) => void;
}
export declare class PreloadText {
    private readonly context;
    private readonly tooltips;
    /** Preloader runs the content it first read from a path for the rest of the session. */
    private readonly preloaded;
    private preload;
    constructor(context: PreloadContext);
    preloadedFiles(): string[];
    private report;
    behaviors(): Readonly<Record<string, NativeBehavior>>;
}
