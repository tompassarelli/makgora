/** @noSelfInFile */
import type { EffectDeaths, EffectPose, Handle, HandleFactory, NativeBehavior } from "../clientTypes";
export declare class Effects {
    private readonly handle;
    private readonly deaths;
    private readonly frame;
    private readonly poses;
    /** Destroyed effects in destruction order, so expiry reads only the oldest. */
    private readonly dying;
    private readonly settled;
    private draws;
    private drawSeconds;
    constructor(handle: HandleFactory, deaths: EffectDeaths | undefined, frame: (this: void) => number);
    create(model: string, x: number, y: number): Handle;
    private live;
    /** Brings the pose's animation clocks up to the last draw before anything reads them or changes how they advance. */
    private settle;
    private destroy;
    private play;
    snapshot(options: {
        readonly visibleOnly?: boolean;
    }): EffectPose[];
    draw(step: number): void;
    expire(frame: number): void;
    behaviors(): Readonly<Record<string, NativeBehavior>>;
    private placement;
}
