/** @noSelfInFile */
import type { Handle, NativeCall } from "./clientTypes";
export declare const isHandle: (value: unknown) => value is Handle;
export declare function describeNumber(value: number): string;
export declare function describeValue(value: unknown): string;
export declare function describeCall({ name, args }: NativeCall): string;
export declare function sameCall(left: NativeCall, right: NativeCall): boolean;
export declare function leadingNumber(text: string, fraction: boolean): number;
export declare function fixed(value: number, digits: number): string;
