/** @noSelfInFile */
/** Warcraft III's simulation rate, which headless clients, lockstep peers and the renderers step at. */
export declare const FRAMES_PER_SECOND = 60;
export declare const FRAME_MS: number;
/** Frames headless clients have stepped in this process: a test's deterministic cost (wisp:scripts/wisp/testCostPreload.ts). */
export declare const steppedFrames: {
    count: number;
};
