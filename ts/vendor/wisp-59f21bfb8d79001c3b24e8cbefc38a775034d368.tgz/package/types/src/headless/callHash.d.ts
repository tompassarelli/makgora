/** @noSelfInFile */
import type { NativeCall } from "./clientTypes";
export declare function mixCall(hash: number, { name, args }: NativeCall): number;
