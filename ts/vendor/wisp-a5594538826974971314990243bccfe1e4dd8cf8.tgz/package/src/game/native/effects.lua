local ____exports = {}
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
function ____exports.createEffect(model, x, y)
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("AddSpecialEffect", {model, x, y})
    end
    return ____types.fromHandle(world.effects:create(model, x, y))
end
function ____exports.destroyEffect(effect)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("DestroyEffect", {effect})
    end
    world.effects:destroy(____types.asHandle(effect))
end
function ____exports.setEffectPosition(effect, x, y, z)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("BlzSetSpecialEffectPosition", {effect, x, y, z})
    end
    world.effects:setPosition(
        ____types.asHandle(effect),
        x,
        y,
        z
    )
end
function ____exports.setEffectZ(effect, z)
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("BlzSetSpecialEffectZ", {effect, z})
    end
    world.effects:setZ(
        ____types.asHandle(effect),
        z
    )
end
function ____exports.setEffectScale(effect, scale)
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("BlzSetSpecialEffectScale", {effect, scale})
    end
    world.effects:setScale(
        ____types.asHandle(effect),
        scale
    )
end
function ____exports.setEffectMatrixScale(effect, x, y, z)
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("BlzSetSpecialEffectMatrixScale", {effect, x, y, z})
    end
    world.effects:setMatrixScale(
        ____types.asHandle(effect),
        x,
        y,
        z
    )
end
function ____exports.resetEffectMatrix(effect)
    local world = ____world.boundWorld()
    local ____opt_12 = world.log
    if ____opt_12 ~= nil then
        ____opt_12("BlzResetSpecialEffectMatrix", {effect})
    end
    world.effects:resetMatrix(____types.asHandle(effect))
end
function ____exports.setEffectOrientation(effect, yaw, pitch, roll)
    local world = ____world.boundWorld()
    local ____opt_14 = world.log
    if ____opt_14 ~= nil then
        ____opt_14("BlzSetSpecialEffectOrientation", {effect, yaw, pitch, roll})
    end
    world.effects:setOrientation(
        ____types.asHandle(effect),
        yaw,
        pitch,
        roll
    )
end
function ____exports.setEffectYaw(effect, yaw)
    local world = ____world.boundWorld()
    local ____opt_16 = world.log
    if ____opt_16 ~= nil then
        ____opt_16("BlzSetSpecialEffectYaw", {effect, yaw})
    end
    world.effects:setYaw(
        ____types.asHandle(effect),
        yaw
    )
end
function ____exports.setEffectPitch(effect, pitch)
    local world = ____world.boundWorld()
    local ____opt_18 = world.log
    if ____opt_18 ~= nil then
        ____opt_18("BlzSetSpecialEffectPitch", {effect, pitch})
    end
    world.effects:setPitch(
        ____types.asHandle(effect),
        pitch
    )
end
function ____exports.setEffectRoll(effect, roll)
    local world = ____world.boundWorld()
    local ____opt_20 = world.log
    if ____opt_20 ~= nil then
        ____opt_20("BlzSetSpecialEffectRoll", {effect, roll})
    end
    world.effects:setRoll(
        ____types.asHandle(effect),
        roll
    )
end
function ____exports.setEffectAlpha(effect, alpha)
    local world = ____world.boundWorld()
    local ____opt_22 = world.log
    if ____opt_22 ~= nil then
        ____opt_22("BlzSetSpecialEffectAlpha", {effect, alpha})
    end
    world.effects:setAlpha(
        ____types.asHandle(effect),
        alpha
    )
end
function ____exports.setEffectColor(effect, red, green, blue)
    local world = ____world.boundWorld()
    local ____opt_24 = world.log
    if ____opt_24 ~= nil then
        ____opt_24("BlzSetSpecialEffectColor", {effect, red, green, blue})
    end
    world.effects:setColor(
        ____types.asHandle(effect),
        red,
        green,
        blue
    )
end
function ____exports.setEffectTeamColor(effect, owner)
    local world = ____world.boundWorld()
    local ____opt_26 = world.log
    if ____opt_26 ~= nil then
        ____opt_26("BlzSetSpecialEffectColorByPlayer", {effect, owner})
    end
    world.effects:setTeamColor(
        ____types.asHandle(effect),
        ____types.asNumber(owner)
    )
end
function ____exports.playEffectAnimation(effect, animation)
    local world = ____world.boundWorld()
    local ____opt_28 = world.log
    if ____opt_28 ~= nil then
        ____opt_28("BlzPlaySpecialEffect", {effect, animation})
    end
    world.effects:play(
        ____types.asHandle(effect),
        ____types.asAnimation(animation)
    )
end
function ____exports.setEffectAnimation(effect, animation)
    local world = ____world.boundWorld()
    local ____opt_30 = world.log
    if ____opt_30 ~= nil then
        ____opt_30("BlzSetSpecialEffectAnimation", {effect, animation})
    end
    world.effects:setAnimation(
        ____types.asHandle(effect),
        animation
    )
end
function ____exports.setEffectTime(effect, seconds)
    local world = ____world.boundWorld()
    local ____opt_32 = world.log
    if ____opt_32 ~= nil then
        ____opt_32("BlzSetSpecialEffectTime", {effect, seconds})
    end
    world.effects:setTime(
        ____types.asHandle(effect),
        seconds
    )
end
function ____exports.setEffectTimeScale(effect, timeScale)
    local world = ____world.boundWorld()
    local ____opt_34 = world.log
    if ____opt_34 ~= nil then
        ____opt_34("BlzSetSpecialEffectTimeScale", {effect, timeScale})
    end
    world.effects:setTimeScale(
        ____types.asHandle(effect),
        timeScale
    )
end
function ____exports.setEffectBlendTime(effect, seconds)
    local world = ____world.boundWorld()
    local ____opt_36 = world.log
    if ____opt_36 ~= nil then
        ____opt_36("BlzSetSpecialEffectAnimationBlendTime", {effect, seconds})
    end
    world.effects:setAnimationBlendTime(
        ____types.asHandle(effect),
        seconds
    )
end
function ____exports.clearEffectSubAnimations(effect)
    local world = ____world.boundWorld()
    local ____opt_38 = world.log
    if ____opt_38 ~= nil then
        ____opt_38("BlzSpecialEffectClearSubAnimations", {effect})
    end
    world.effects:clearSubAnimations(____types.asHandle(effect))
end
function ____exports.effectScale(effect)
    local world = ____world.boundWorld()
    local ____opt_40 = world.log
    if ____opt_40 ~= nil then
        ____opt_40("BlzGetSpecialEffectScale", {effect})
    end
    return world.effects:scale(____types.asHandle(effect))
end
function ____exports.effectX(effect)
    local world = ____world.boundWorld()
    local ____opt_42 = world.log
    if ____opt_42 ~= nil then
        ____opt_42("BlzGetLocalSpecialEffectX", {effect})
    end
    return world.effects:x(____types.asHandle(effect))
end
function ____exports.effectY(effect)
    local world = ____world.boundWorld()
    local ____opt_44 = world.log
    if ____opt_44 ~= nil then
        ____opt_44("BlzGetLocalSpecialEffectY", {effect})
    end
    return world.effects:y(____types.asHandle(effect))
end
function ____exports.effectZ(effect)
    local world = ____world.boundWorld()
    local ____opt_46 = world.log
    if ____opt_46 ~= nil then
        ____opt_46("BlzGetLocalSpecialEffectZ", {effect})
    end
    return world.effects:z(____types.asHandle(effect))
end
function ____exports.createBeam(model, x1, y1, z1, x2, y2, z2)
    local world = ____world.boundWorld()
    local ____opt_48 = world.log
    if ____opt_48 ~= nil then
        ____opt_48("AddLightningEx", {
            model,
            false,
            x1,
            y1,
            z1,
            x2,
            y2,
            z2
        })
    end
    return ____types.fromHandle(world.beams:add(
        model,
        x1,
        y1,
        z1,
        x2,
        y2,
        z2
    ))
end
function ____exports.moveBeam(beam, x1, y1, z1, x2, y2, z2)
    local world = ____world.boundWorld()
    local ____opt_50 = world.log
    if ____opt_50 ~= nil then
        ____opt_50("MoveLightningEx", {
            beam,
            false,
            x1,
            y1,
            z1,
            x2,
            y2,
            z2
        })
    end
    return world.beams:move(
        ____types.asHandle(beam),
        x1,
        y1,
        z1,
        x2,
        y2,
        z2
    )
end
function ____exports.setBeamColor(beam, red, green, blue, alpha)
    local world = ____world.boundWorld()
    local ____opt_52 = world.log
    if ____opt_52 ~= nil then
        ____opt_52("SetLightningColor", {
            beam,
            red,
            green,
            blue,
            alpha
        })
    end
    return world.beams:setColor(
        ____types.asHandle(beam),
        red,
        green,
        blue,
        alpha
    )
end
function ____exports.destroyBeam(beam)
    local world = ____world.boundWorld()
    local ____opt_54 = world.log
    if ____opt_54 ~= nil then
        ____opt_54("DestroyLightning", {beam})
    end
    return world.beams:destroy(____types.asHandle(beam))
end
function ____exports.createFloatingText()
    local world = ____world.boundWorld()
    local ____opt_56 = world.log
    if ____opt_56 ~= nil then
        ____opt_56("CreateTextTag", {})
    end
    return ____types.fromHandle(world.floatingText:create())
end
function ____exports.setFloatingText(text, content, height)
    local world = ____world.boundWorld()
    local ____opt_58 = world.log
    if ____opt_58 ~= nil then
        ____opt_58("SetTextTagText", {text, content, height})
    end
    world.floatingText:setText(
        ____types.asHandle(text),
        content,
        height
    )
end
function ____exports.setFloatingTextPosition(text, x, y, heightOffset)
    local world = ____world.boundWorld()
    local ____opt_60 = world.log
    if ____opt_60 ~= nil then
        ____opt_60("SetTextTagPos", {text, x, y, heightOffset})
    end
    world.floatingText:setPosition(
        ____types.asHandle(text),
        x,
        y,
        heightOffset
    )
end
function ____exports.setFloatingTextColor(text, red, green, blue, alpha)
    local world = ____world.boundWorld()
    local ____opt_62 = world.log
    if ____opt_62 ~= nil then
        ____opt_62("SetTextTagColor", {
            text,
            red,
            green,
            blue,
            alpha
        })
    end
    world.floatingText:setColor(
        ____types.asHandle(text),
        red,
        green,
        blue,
        alpha
    )
end
function ____exports.setFloatingTextVisible(text, visible)
    local world = ____world.boundWorld()
    local ____opt_64 = world.log
    if ____opt_64 ~= nil then
        ____opt_64("SetTextTagVisibility", {text, visible})
    end
    world.floatingText:setVisible(
        ____types.asHandle(text),
        visible
    )
end
function ____exports.setFloatingTextPermanent(text, permanent)
    local world = ____world.boundWorld()
    local ____opt_66 = world.log
    if ____opt_66 ~= nil then
        ____opt_66("SetTextTagPermanent", {text, permanent})
    end
    world.floatingText:setPermanent(
        ____types.asHandle(text),
        permanent
    )
end
return ____exports
