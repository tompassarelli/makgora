import { Effect } from "effect";
import { Random } from "../../src/headless/random";
import { NetFailure } from "./failure";

export interface ProxyOptions {
  readonly listen: number;
  readonly to: { readonly address: string; readonly port: number };
  readonly oneWayMs: number;
  readonly loss: number;
  readonly seed: number;
  /** The spread of each datagram's wait: it waits `oneWayMs` plus or minus half of this, drawn evenly, so datagrams can pass one another as netem's jitter lets them. */
  readonly jitterMs?: number;
}

/** Where a datagram due `at` goes in `pending`, which is kept in due order: after every datagram due no later. */
export const dueIndex = (pending: readonly { readonly at: number }[], at: number): number => {
  let low = 0, high = pending.length;
  while (low < high) {
    const middle = (low + high) >> 1;
    if ((pending[middle]?.at ?? 0) <= at) low = middle + 1;
    else high = middle;
  }
  return low;
};

/**
 * A delay and loss proxy between one joiner and a host (the joiner is whoever sent last, so its relay ping and its match may use two sockets), standing in for a network path on one machine:
 * every datagram waits `oneWayMs` (give or take half of `jitterMs`) in each direction and is dropped with probability `loss`. It runs until interrupted.
 */
export const runProxy = (options: ProxyOptions, log: (line: string) => void = console.error) => Effect.scoped(Effect.gen(function*() {
  const random = new Random(options.seed);
  const pending: { readonly at: number; readonly forward: () => void }[] = [];
  let client: { address: string; port: number } | undefined;
  const hold = (forward: () => void) => {
    if (random.chance(options.loss)) return;
    const jitter = options.jitterMs ?? 0;
    const at = performance.now() + Math.max(0, options.oneWayMs + (jitter === 0 ? 0 : (random.next() - 0.5) * jitter));
    pending.splice(dueIndex(pending, at), 0, { at, forward });
  };
  const toHost = yield* Effect.acquireRelease(Effect.tryPromise({
    try: () => Bun.udpSocket({
      hostname: "0.0.0.0",
      socket: {
        data: (_socket, data) => {
          const to = client;
          const copy = new Uint8Array(data);
          if (to !== undefined) hold(() => listener.send(copy, to.port, to.address));
        },
        // A host not yet bound, or gone, answers with ICMP port unreachable, which Bun raises on the next receive.
        error: () => undefined,
      },
    }),
    catch: (cause) => new NetFailure({ problem: `proxy socket: ${String(cause)}` }),
  }), (socket) => Effect.sync(() => socket.close()));
  const listener = yield* Effect.acquireRelease(Effect.tryPromise({
    try: () => Bun.udpSocket({
      hostname: "0.0.0.0",
      port: options.listen,
      socket: {
        data: (_socket, data, port, address) => {
          client = { address, port };
          const copy = new Uint8Array(data);
          hold(() => toHost.send(copy, options.to.port, options.to.address));
        },
        error: () => undefined,
      },
    }),
    catch: (cause) => new NetFailure({ problem: `proxy port ${options.listen}: ${String(cause)}` }),
  }), (socket) => Effect.sync(() => socket.close()));
  log(`net: proxy on UDP port ${listener.port} to ${options.to.address}:${options.to.port}, ${options.oneWayMs} ms each way${(options.jitterMs ?? 0) > 0 ? ` ± ${(options.jitterMs ?? 0) / 2} ms` : ""}, ${options.loss * 100}% loss`);
  for (;;) {
    const now = performance.now();
    while ((pending[0]?.at ?? Infinity) <= now) {
      const due = pending.shift();
      // A peer that has gone answers with ICMP port unreachable; the peers' own silence rules decide that.
      yield* Effect.ignore(Effect.try(() => due?.forward()));
    }
    yield* Effect.sleep(Math.max(0, (pending[0]?.at ?? now + 1) - performance.now()));
  }
}));
