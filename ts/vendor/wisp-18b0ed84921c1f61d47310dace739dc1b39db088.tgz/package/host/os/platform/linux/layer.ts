import { existsSync } from "node:fs";
import { join } from "node:path";
import * as BunServices from "@effect/platform-bun/BunServices";
import { Effect, Layer, Stream } from "effect";
import { ChildProcess, ChildProcessSpawner } from "effect/process";
import {
  AudioIsolation, BackgroundServices, CapacityAdmission, GameLauncher, Namespaces, PageOpener, PlatformFailure, ProcessTable, ResourceAccounting,
} from "../../../contract/services";
import { linuxDesktopLayer } from "./desktop";
import * as procfs from "./procfs";
import { startUnit, stopUnit, unitState } from "./systemd";
import { describeCause } from "../../../contract/describeCause";

const failure = (capability: string) => (cause: unknown) =>
  new PlatformFailure({ capability, problem: typeof cause === "object" && cause !== null && "problem" in cause ? String(cause.problem) : describeCause(cause) });

const steam = () => join(process.env["HOME"] ?? "", ".local/share/Steam");
const PROTON = "compatibilitytools.d/GE-Proton11-7-x86_64/proton";
const STEAM_RUNTIME = "steamapps/common/SteamLinuxRuntime_4/_v2-entry-point";

const OFFLINE = ["bwrap", "--dev-bind", "/", "/", "--unshare-net", "--die-with-parent", "--"];

const NAMESPACE_FLAGS = { user: ["--user"], net: ["--net"], mount: ["--mount"] } as const;

const userRuntime = () => `/run/user/${process.getuid?.() ?? 1000}`;

const quiet = (command: string, args: readonly string[], env: Record<string, string>) =>
  ChildProcessSpawner.ChildProcessSpawner.use((spawner) => spawner.string(ChildProcess.make(command, args, { env, extendEnv: true, stderr: "ignore" }))).pipe(
    Effect.timeout("5 seconds"),
    Effect.orElseSucceed(() => ""),
  );

const audio = Layer.effect(AudioIsolation, Effect.gen(function*() {
  const spawner = yield* ChildProcessSpawner.ChildProcessSpawner;
  return AudioIsolation.of({
    sink: (name, sink) => Effect.gen(function*() {
      const pulse = join(userRuntime(), "pulse/native");
      if (!existsSync(pulse)) return { env: {} };
      const pw = { XDG_RUNTIME_DIR: userRuntime() };
      const nodes = yield* quiet("pw-dump", [], pw);
      if (!nodes.includes(`"node.name": "${sink}"`)) {
        const made = yield* Effect.scoped(Effect.gen(function*() {
          const child = yield* ChildProcess.make("pw-cli", ["create-node", "adapter", `{ factory.name=support.null-audio-sink node.name=${sink} node.description="Wisp ${name}" media.class=Audio/Sink object.linger=true audio.position=[ FL FR ] priority.session=0 priority.driver=0 }`], { env: pw, extendEnv: true, stdout: "ignore" });
          const [said, code] = yield* Effect.all([Stream.mkString(Stream.decodeText(child.stderr)), child.exitCode], { concurrency: 2 });
          return { said, code };
        })).pipe(Effect.timeout("5 seconds"), Effect.orElseSucceed(() => ({ said: "pw-cli failed", code: 1 })));
        if (made.code !== 0) return { env: {}, problem: `no sink for ${name} (${made.said.trim()}): it runs without sound` };
      }
      return { env: { PULSE_SERVER: `unix:${pulse}`, PULSE_SINK: sink } };
    }).pipe(Effect.provideService(ChildProcessSpawner.ChildProcessSpawner, spawner)),
  });
}));

// The machine-capacity helper names each lease's scope agent-capacity-<lease id without dashes>.scope.
const leaseScope = (lease: string) => `agent-capacity-${lease.replaceAll("-", "")}.scope`;

const userManager = (args: readonly string[]) => Effect.try({
  try: () => {
    const env = { ...process.env, XDG_RUNTIME_DIR: userRuntime(), DBUS_SESSION_BUS_ADDRESS: `unix:path=${userRuntime()}/bus` };
    const done = Bun.spawnSync(["systemctl", "--user", ...args], { env, cwd: "/", stdin: "ignore", stdout: "pipe", stderr: "pipe" });
    return done.stdout.toString().trim();
  },
  catch: failure("capacity admission"),
});

const admission = Layer.succeed(CapacityAdmission, CapacityAdmission.of({
  session: (helper, owner, memoryGib, waitSeconds) => Effect.succeed([
    process.execPath, helper, "session", "--class", "native", ...(memoryGib === undefined ? [] : ["--memory-gib", String(memoryGib)]), ...(waitSeconds === undefined ? [] : ["--wait-seconds", String(waitSeconds)]), "--owner", owner, "--",
  ]),
  signalLease: (lease, signal) => userManager(["kill", `--signal=${signal}`, leaseScope(lease)]).pipe(Effect.asVoid),
  leaseLive: (lease) => userManager(["show", leaseScope(lease), "--property=ActiveState", "--value"]).pipe(
    Effect.map((state) => !["", "inactive", "failed"].includes(state)),
  ),
}));

const synchronous = Layer.mergeAll(
  Layer.succeed(ProcessTable, ProcessTable.of({
    list: Effect.sync(procfs.listProcesses),
    games: (prefix) => Effect.sync(() => procfs.findGameProcesses(prefix)),
    launcher: (pid) => Effect.try({ try: () => procfs.launcherProcess(pid), catch: failure("process discovery") }),
    alive: (pid) => Effect.sync(() => procfs.alive(pid)),
    residentKiB: (pid) => Effect.sync(() => procfs.residentKiB(pid)),
    networkInterfaces: (pid) => Effect.try({ try: () => procfs.networkInterfaces(pid), catch: failure(`pid ${pid}'s network namespace`) }),
  })),
  Layer.sync(ResourceAccounting, () => {
    let clock: (() => number) | undefined;
    return ResourceAccounting.of({
      cpuPressure: procfs.cpuPressure,
      cpuLimit: procfs.cpuLimit,
      insideCapacityLease: procfs.insideCapacityLease,
      threadCpuMillis: () => (clock ??= procfs.threadClock())(),
    });
  }),
  Layer.succeed(BackgroundServices, BackgroundServices.of({
    start: (unit, command, log) => startUnit(unit, command, log).pipe(Effect.mapError(failure("background services"))),
    state: (unit) => unitState(unit).pipe(Effect.mapError(failure("background services"))),
    stop: (unit) => stopUnit(unit).pipe(Effect.mapError(failure("background services"))),
    owner: (pid) => Effect.sync(() => procfs.ownerOf(pid)),
  })),
  Layer.succeed(GameLauncher, GameLauncher.of({
    inPrefix: (launch) => Effect.succeed({
      command: [
        ...(launch.isolateNetwork === true ? OFFLINE : []),
        ...(launch.sessionBus === true ? ["dbus-run-session", "--"] : []),
        "steam-run", "env", join(steam(), STEAM_RUNTIME), "--verb=waitforexitandrun", "--",
        join(steam(), PROTON), "waitforexitandrun", launch.exe, ...launch.args,
      ],
      env: {
        ...(launch.sessionBus === true ? { XDG_RUNTIME_DIR: userRuntime(), DBUS_SESSION_BUS_ADDRESS: `unix:path=${userRuntime()}/bus` } : {}),
        STEAM_COMPAT_DATA_PATH: launch.root, STEAM_COMPAT_CLIENT_INSTALL_PATH: steam(), STEAM_COMPAT_APP_ID: launch.appId, SteamAppId: launch.appId,
      },
    }),
  })),
  Layer.succeed(Namespaces, Namespaces.of({
    offline: (command) => Effect.succeed([...OFFLINE, ...command]),
    enter: (pid, namespaces, command, options) => Effect.succeed([
      "nsenter", "--target", String(pid), ...namespaces.flatMap((namespace) => NAMESPACE_FLAGS[namespace]), "--preserve-credentials",
      ...(options?.keepCapabilities === true ? ["--keep-caps"] : []),
      ...(options?.workingDirectory === undefined ? [] : [`--wd=${options.workingDirectory}`]), ...command,
    ]),
  })),
  Layer.succeed(PageOpener, PageOpener.of({
    open: (url) => Effect.try({ try: () => { Bun.spawn(["xdg-open", url], { stdout: "ignore", stderr: "ignore" }); }, catch: failure("opening a page") }),
  })),
);

// ./desktop reaches this module back through warcraft/desktop, so its layer may not exist yet when this one loads.
export const linuxLayer = Layer.mergeAll(synchronous, Layer.suspend(() => linuxDesktopLayer), audio, admission).pipe(Layer.provide(BunServices.layer));
