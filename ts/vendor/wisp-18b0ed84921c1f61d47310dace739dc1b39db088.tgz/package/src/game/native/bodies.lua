local ____exports = {}
local ____bodyStore = require("src.game.native.bodyStore")
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
local stored = ____bodyStore.asBody
function ____exports.mapCenter()
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("GetPlayableMapRect", {})
    end
    local center = world.bodies:mapCenter()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("GetRectCenter", {center.rect})
    end
    return ____types.fromHandle(center.location)
end
function ____exports.locationX(location)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("GetLocationX", {location})
    end
    return world.bodies:locationAt(____types.asHandle(location)).x
end
function ____exports.locationY(location)
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("GetLocationY", {location})
    end
    return world.bodies:locationAt(____types.asHandle(location)).y
end
function ____exports.removeLocation(location)
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("RemoveLocation", {location})
    end
    world.bodies:removeLocation(____types.asHandle(location))
end
function ____exports.createLocation(x, y)
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("Location", {x, y})
    end
    return ____types.fromHandle(world.bodies:location(x, y))
end
function ____exports.locationZ(location)
    local ____opt_12 = ____world.boundWorld().log
    if ____opt_12 ~= nil then
        ____opt_12("GetLocationZ", {location})
    end
    return 0
end
function ____exports.bodyX(body)
    local ____opt_14 = ____world.boundWorld().log
    if ____opt_14 ~= nil then
        ____opt_14("GetUnitX", {body})
    end
    return stored(body).x
end
function ____exports.bodyY(body)
    local ____opt_16 = ____world.boundWorld().log
    if ____opt_16 ~= nil then
        ____opt_16("GetUnitY", {body})
    end
    return stored(body).y
end
function ____exports.createBody(player, kind, x, y, facing)
    local world = ____world.boundWorld()
    local ____opt_18 = world.log
    if ____opt_18 ~= nil then
        ____opt_18("CreateUnit", {
            player,
            kind,
            x,
            y,
            facing
        })
    end
    return ____types.fromHandle(world.bodies:create(
        ____types.asNumber(player),
        kind,
        x,
        y,
        facing
    ))
end
function ____exports.removeBody(body)
    local world = ____world.boundWorld()
    local ____opt_20 = world.log
    if ____opt_20 ~= nil then
        ____opt_20("RemoveUnit", {body})
    end
    world.bodies:remove(stored(body))
end
function ____exports.setBodyX(body, x)
    local world = ____world.boundWorld()
    local ____opt_22 = world.log
    if ____opt_22 ~= nil then
        ____opt_22("SetUnitX", {body, x})
    end
    world.bodies:setX(
        stored(body),
        x
    )
end
function ____exports.setBodyY(body, y)
    local world = ____world.boundWorld()
    local ____opt_24 = world.log
    if ____opt_24 ~= nil then
        ____opt_24("SetUnitY", {body, y})
    end
    world.bodies:setY(
        stored(body),
        y
    )
end
function ____exports.setBodyHeight(body, height, rate)
    local world = ____world.boundWorld()
    local ____opt_26 = world.log
    if ____opt_26 ~= nil then
        ____opt_26("SetUnitFlyHeight", {body, height, rate})
    end
    world.bodies:setHeight(
        stored(body),
        height
    )
end
function ____exports.setBodyFacing(body, degrees)
    local world = ____world.boundWorld()
    local ____opt_28 = world.log
    if ____opt_28 ~= nil then
        ____opt_28("BlzSetUnitFacingEx", {body, degrees})
    end
    world.bodies:setFacing(
        stored(body),
        degrees
    )
end
function ____exports.setBodyColor(body, color)
    local world = ____world.boundWorld()
    local ____opt_30 = world.log
    if ____opt_30 ~= nil then
        ____opt_30("ConvertPlayerColor", {color})
    end
    local ____opt_32 = world.log
    if ____opt_32 ~= nil then
        ____opt_32("SetUnitColor", {body, color})
    end
    world.bodies:setColor(
        stored(body),
        color
    )
end
function ____exports.setBodyTint(body, red, green, blue, alpha)
    local world = ____world.boundWorld()
    local ____opt_34 = world.log
    if ____opt_34 ~= nil then
        ____opt_34("SetUnitVertexColor", {
            body,
            red,
            green,
            blue,
            alpha
        })
    end
    world.bodies:setTint(
        stored(body),
        red,
        green,
        blue,
        alpha
    )
end
function ____exports.setBodyScale(body, x, y, z)
    local world = ____world.boundWorld()
    local ____opt_36 = world.log
    if ____opt_36 ~= nil then
        ____opt_36("SetUnitScale", {body, x, y, z})
    end
    world.bodies:setScale(
        stored(body),
        x,
        y,
        z
    )
end
function ____exports.setBodyTimeScale(body, scale)
    local world = ____world.boundWorld()
    local ____opt_38 = world.log
    if ____opt_38 ~= nil then
        ____opt_38("SetUnitTimeScale", {body, scale})
    end
    world.bodies:setTimeScale(
        stored(body),
        scale
    )
end
function ____exports.setBodyAnimation(body, name)
    local world = ____world.boundWorld()
    local ____opt_40 = world.log
    if ____opt_40 ~= nil then
        ____opt_40("SetUnitAnimation", {body, name})
    end
    world.bodies:animate(
        stored(body),
        name
    )
end
function ____exports.setBodyAnimationIndex(body, index)
    local world = ____world.boundWorld()
    local ____opt_42 = world.log
    if ____opt_42 ~= nil then
        ____opt_42("SetUnitAnimationByIndex", {body, index})
    end
    world.bodies:animate(
        stored(body),
        index
    )
end
function ____exports.showBody(body, show)
    local world = ____world.boundWorld()
    local ____opt_44 = world.log
    if ____opt_44 ~= nil then
        ____opt_44("ShowUnit", {body, show})
    end
    world.bodies:show(
        stored(body),
        show
    )
end
function ____exports.setBodyTeamGlow(body, show)
    local ____opt_46 = ____world.boundWorld().log
    if ____opt_46 ~= nil then
        ____opt_46("BlzShowUnitTeamGlow", {body, show})
    end
end
function ____exports.bodyHidden(body)
    local ____opt_48 = ____world.boundWorld().log
    if ____opt_48 ~= nil then
        ____opt_48("IsUnitHidden", {body})
    end
    return not stored(body).visible
end
function ____exports.bodyKind(body)
    local world = ____world.boundWorld()
    local ____opt_50 = world.log
    if ____opt_50 ~= nil then
        ____opt_50("GetUnitTypeId", {body})
    end
    return world.bodies:kind(stored(body))
end
function ____exports.bodyMoveSpeed(body)
    local ____opt_52 = ____world.boundWorld().log
    if ____opt_52 ~= nil then
        ____opt_52("GetUnitMoveSpeed", {body})
    end
    return stored(body).moveSpeed
end
function ____exports.bodyAttackCooldown(body)
    local ____opt_54 = ____world.boundWorld().log
    if ____opt_54 ~= nil then
        ____opt_54("BlzGetUnitAttackCooldown", {body, 0})
    end
    return stored(body).attackCooldown
end
function ____exports.setBodyName(body, name)
    local world = ____world.boundWorld()
    local ____opt_56 = world.log
    if ____opt_56 ~= nil then
        ____opt_56("BlzSetUnitName", {body, name})
    end
    world.bodies:setName(
        stored(body),
        name
    )
end
function ____exports.setBodySelectionScale(body, scale)
    local ____opt_58 = ____world.boundWorld().log
    if ____opt_58 ~= nil then
        ____opt_58("BlzSetUnitRealField", {body, "UNIT_RF_SELECTION_SCALE", scale})
    end
end
function ____exports.setBodyMoveSpeed(body, speed)
    local world = ____world.boundWorld()
    local ____opt_60 = world.log
    if ____opt_60 ~= nil then
        ____opt_60("SetUnitMoveSpeed", {body, speed})
    end
    world.bodies:setMoveSpeed(
        stored(body),
        speed
    )
end
function ____exports.setBodyAttackCooldown(body, cooldown)
    local world = ____world.boundWorld()
    local ____opt_62 = world.log
    if ____opt_62 ~= nil then
        ____opt_62("BlzSetUnitAttackCooldown", {body, cooldown, 0})
    end
    world.bodies:setAttackCooldown(
        stored(body),
        cooldown
    )
end
function ____exports.setBodyBlendTime(body, seconds)
    local world = ____world.boundWorld()
    local ____opt_64 = world.log
    if ____opt_64 ~= nil then
        ____opt_64("SetUnitBlendTime", {body, seconds})
    end
    world.bodies:setBlendTime(
        stored(body),
        seconds
    )
end
function ____exports.setBodyInvulnerable(body, invulnerable)
    local ____opt_66 = ____world.boundWorld().log
    if ____opt_66 ~= nil then
        ____opt_66("SetUnitInvulnerable", {body, invulnerable})
    end
end
function ____exports.setBodyPathing(body, pathing)
    local ____opt_68 = ____world.boundWorld().log
    if ____opt_68 ~= nil then
        ____opt_68("SetUnitPathing", {body, pathing})
    end
end
function ____exports.pauseBody(body, paused)
    local ____opt_70 = ____world.boundWorld().log
    if ____opt_70 ~= nil then
        ____opt_70("PauseUnit", {body, paused})
    end
end
function ____exports.addBodyAbility(body, ability)
    local world = ____world.boundWorld()
    local ____opt_72 = world.log
    if ____opt_72 ~= nil then
        ____opt_72("UnitAddAbility", {body, ability})
    end
    world.bodies:addAbility(
        stored(body),
        ability
    )
end
function ____exports.removeBodyAbility(body, ability)
    local world = ____world.boundWorld()
    local ____opt_74 = world.log
    if ____opt_74 ~= nil then
        ____opt_74("UnitRemoveAbility", {body, ability})
    end
    world.bodies:removeAbility(
        stored(body),
        ability
    )
end
function ____exports.setAbilityTooltip(ability, tooltip, level)
    local world = ____world.boundWorld()
    local ____opt_76 = world.log
    if ____opt_76 ~= nil then
        ____opt_76("BlzSetAbilityTooltip", {ability, tooltip, level})
    end
    world.bodies:setTooltip(ability, level, tooltip)
end
function ____exports.abilityTooltip(ability, level)
    local world = ____world.boundWorld()
    local ____opt_78 = world.log
    if ____opt_78 ~= nil then
        ____opt_78("BlzGetAbilityTooltip", {ability, level})
    end
    return world.bodies:tooltip(ability, level)
end
function ____exports.bodyName(body)
    local world = ____world.boundWorld()
    local ____opt_80 = world.log
    if ____opt_80 ~= nil then
        ____opt_80("GetUnitName", {body})
    end
    return world.bodies:name(stored(body))
end
function ____exports.bodyAbilityLevel(body, ability)
    local world = ____world.boundWorld()
    local ____opt_82 = world.log
    if ____opt_82 ~= nil then
        ____opt_82("GetUnitAbilityLevel", {body, ability})
    end
    return world.bodies:abilityLevel(
        stored(body),
        ability
    )
end
function ____exports.setBodyAbilityLevel(body, ability, level)
    local world = ____world.boundWorld()
    local ____opt_84 = world.log
    if ____opt_84 ~= nil then
        ____opt_84("SetUnitAbilityLevel", {body, ability, level})
    end
    world.bodies:setAbilityLevel(
        stored(body),
        ability,
        level
    )
end
function ____exports.mapCenterX()
    local world = ____world.boundWorld()
    local ____opt_86 = world.log
    if ____opt_86 ~= nil then
        ____opt_86("GetRectCenterX", {world.bodies.playableArea})
    end
    return 0
end
function ____exports.mapCenterY()
    local world = ____world.boundWorld()
    local ____opt_88 = world.log
    if ____opt_88 ~= nil then
        ____opt_88("GetRectCenterY", {world.bodies.playableArea})
    end
    return 0
end
return ____exports
