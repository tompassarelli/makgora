local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__ArraySplice = ____lualib.__TS__ArraySplice
local ____exports = {}
local ____frameRate = require("src.game.native.frameRate")
local TRIM = 1000000.0
--- The frames a span of seconds takes, with the float noise of a binary32 span such as 1/60 or 0.55 s removed: a span within binary32 rounding of whole frames is those frames.
local function framesOf(seconds)
    local frames = seconds * ____frameRate.FRAMES_PER_SECOND
    local whole = math.floor(frames + 0x1p-1)
    return math.abs(frames - whole) <= math.abs(whole) * 2 ^ (-23) and whole or math.floor(frames * TRIM + 0x1p-1) / TRIM
end
--- The timers of one running game, counted in whole simulation frames: a timer fires on the frame at or after its deadline, once per frame at most, in deadline then start order.
____exports.Clock = __TS__Class()
local Clock = ____exports.Clock
Clock.name = "Clock"
function Clock.prototype.____constructor(self, handle)
    self.handle = handle
    self.timers = {}
    self.order = 0
    self.now = 0
    self.speed = "MAP_SPEED_NORMAL"
end
function Clock.prototype.create(self)
    local timer = __TS__ObjectAssign(
        {},
        self.handle("timer"),
        {
            callback = nil,
            periodic = false,
            timeout = 0,
            period = 0,
            due = 0,
            order = 0,
            firedAt = 0,
            running = false,
            expired = false,
            paused = nil
        }
    )
    local ____self_timers_0 = self.timers
    ____self_timers_0[#____self_timers_0 + 1] = timer
    return timer
end
function Clock.prototype.start(self, handle, seconds, periodic, callback)
    local timer = handle
    timer.callback = callback
    timer.periodic = periodic
    timer.timeout = seconds
    timer.period = math.max(
        0,
        framesOf(seconds)
    )
    timer.due = self.now + timer.period
    local ____self_1, ____order_2 = self, "order"
    local ____self_order_3 = ____self_1[____order_2] + 1
    ____self_1[____order_2] = ____self_order_3
    timer.order = ____self_order_3
    timer.firedAt = self.now
    timer.running = true
    timer.expired = false
    timer.paused = nil
end
function Clock.prototype.pause(self, handle)
    local timer = handle
    if timer.running then
        timer.paused = self:elapsed(timer)
    end
    timer.running = false
end
function Clock.prototype.destroy(self, handle)
    local timer = handle
    timer.running = false
    local index = __TS__ArrayIndexOf(self.timers, timer)
    if index >= 0 then
        __TS__ArraySplice(self.timers, index, 1)
    end
end
function Clock.prototype.elapsed(self, handle)
    local timer = handle
    if timer.paused ~= nil then
        return timer.paused
    end
    if timer.expired then
        return timer.timeout
    end
    if not timer.running then
        return 0
    end
    local into = timer.period - math.max(0, timer.due - self.now)
    return math.max(0, into) / ____frameRate.FRAMES_PER_SECOND
end
function Clock.prototype.runDue(self, frame)
    self.now = frame
    do
        while true do
            local next
            for ____, timer in ipairs(self.timers) do
                do
                    if not timer.running or timer.callback == nil or timer.due > frame or timer.firedAt == frame then
                        goto __continue17
                    end
                    if next == nil or timer.due < next.due or timer.due == next.due and timer.order < next.order then
                        next = timer
                    end
                end
                ::__continue17::
            end
            if next == nil or next.callback == nil then
                return
            end
            next.firedAt = frame
            if next.periodic then
                local following = next.due + next.period
                next.due = following > frame and following or frame + next.period
            else
                next.running = false
                next.expired = true
            end
            next.callback()
        end
    end
end
return ____exports
