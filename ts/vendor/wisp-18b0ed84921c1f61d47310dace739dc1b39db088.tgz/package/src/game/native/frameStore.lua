local ____lualib = require("lualib_bundle")
local __TS__ArrayIndexOf = ____lualib.__TS__ArrayIndexOf
local __TS__StringStartsWith = ____lualib.__TS__StringStartsWith
local __TS__StringSlice = ____lualib.__TS__StringSlice
local Map = ____lualib.Map
local __TS__New = ____lualib.__TS__New
local WeakMap = ____lualib.WeakMap
local __TS__StringIncludes = ____lualib.__TS__StringIncludes
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local __TS__Class = ____lualib.__TS__Class
local Set = ____lualib.Set
local __TS__ObjectAssign = ____lualib.__TS__ObjectAssign
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____intMath = require("src.sim.intMath")
____exports.FRAME_POINTS = {
    {"FRAMEPOINT_TOPLEFT", 0, 0},
    {"FRAMEPOINT_TOP", 0x1p-1, 0},
    {"FRAMEPOINT_TOPRIGHT", 1, 0},
    {"FRAMEPOINT_LEFT", 0, 0x1p-1},
    {"FRAMEPOINT_CENTER", 0x1p-1, 0x1p-1},
    {"FRAMEPOINT_RIGHT", 1, 0x1p-1},
    {"FRAMEPOINT_BOTTOMLEFT", 0, 1},
    {"FRAMEPOINT_BOTTOM", 0x1p-1, 1},
    {"FRAMEPOINT_BOTTOMRIGHT", 1, 1}
}
local SIMPLE_FLOOR = -1073741824
local SIMPLE_LAYERS = {"BACKGROUND", "ARTWORK"}
local function shownAlpha(frame)
    local ____frame_simple_2 = frame.simple
    if ____frame_simple_2 then
        local ____opt_0 = frame.parent
        ____frame_simple_2 = (____opt_0 and ____opt_0.simple) == true
    end
    return ____frame_simple_2 and (frame.alpha * frame.parent.alpha + 127) // 255 or frame.alpha
end
local function snapshotUv(frame)
    local texCoord = frame.texCoord
    return texCoord == nil and ({}) or ({uv = {texCoord[1], texCoord[3], texCoord[2], texCoord[4]}})
end
local function simpleLevel(frame, simples)
    local root = frame.type == "SIMPLEFRAME" and frame or frame.parent
    local rank = __TS__ArrayIndexOf(SIMPLE_LAYERS, frame.layer)
    return SIMPLE_FLOOR + (root == nil and 0 or (simples:get(root) or 0)) * 4 + (rank < 0 and 0 or rank)
end
local function textJustify(value)
    if type(value) == "number" then
        return ({
            "top",
            "middle",
            "bottom",
            "left",
            "center",
            "right"
        })[value + 1] or ""
    end
    return type(value) == "string" and string.lower(__TS__StringStartsWith(value, "TEXT_JUSTIFY_") and __TS__StringSlice(value, #"TEXT_JUSTIFY_") or value) or ""
end
local function textAlignment(alignment)
    local vertical = textJustify(alignment.vertical)
    local horizontal = textJustify(alignment.horizontal)
    return {vertical = (vertical == "middle" or vertical == "bottom") and vertical or "top", horizontal = (horizontal == "center" or horizontal == "right") and horizontal or "left"}
end
local BUTTON_ALIGNMENT = {vertical = "MIDDLE", horizontal = "CENTER"}
local buttonTypes = __TS__New(Map)
local alignments = __TS__New(WeakMap)
local function isButton(____type)
    local button = buttonTypes:get(____type)
    if button == nil then
        local ____buttonTypes_set_4 = buttonTypes.set
        local ____type_3 = ____type
        button = __TS__StringIncludes(
            string.lower(____type),
            "button"
        )
        ____buttonTypes_set_4(buttonTypes, ____type_3, button)
    end
    return button
end
local function frameAlignment(frame)
    local declared = frame.alignment or (isButton(frame.type) and BUTTON_ALIGNMENT or nil)
    if declared == nil then
        return nil
    end
    local aligned = alignments:get(declared)
    if aligned == nil then
        local ____alignments_set_5 = alignments.set
        aligned = textAlignment(declared)
        ____alignments_set_5(alignments, declared, aligned)
    end
    return aligned
end
local function styleText(frame, declared)
    if declared.font == nil then
        return
    end
    frame.font = {file = declared.font.file, height = declared.font.size, flags = declared.font.flags or 0}
    local justify = declared.justify or ({horizontal = "CENTER", vertical = "MIDDLE"})
    frame.alignment = {vertical = justify.vertical, horizontal = justify.horizontal}
end
local NAMED_POINTS = __TS__New(
    Map,
    __TS__ArrayMap(
        ____exports.FRAME_POINTS,
        function(____, ____bindingPattern0)
            local fromTop
            local fromLeft
            local name
            name = ____bindingPattern0[1]
            fromLeft = ____bindingPattern0[2]
            fromTop = ____bindingPattern0[3]
            return {
                __TS__StringSlice(name, #"FRAMEPOINT_"),
                {fromLeft, fromTop}
            }
        end
    )
)
local EDGE = 0x29f16bp-38
local DEFAULT_TEXT_LIMIT = -256
local function fitCorners(placed, width, height)
    local corners = {0, 0, 0, 0}
    local found = 0
    for ____, ____value in ipairs(placed) do
        local share = ____value[1]
        local at = ____value[2]
        local left = at.x - share[1] * width
        local top = at.y + share[2] * height
        if found == 0 then
            corners[1] = left
            corners[2] = top
            corners[3] = left + width
            corners[4] = top - height
        else
            if share[1] == 0 then
                corners[1] = at.x
            end
            if share[1] == 1 then
                corners[3] = at.x
            end
            if share[2] == 0 then
                corners[2] = at.y
            end
            if share[2] == 1 then
                corners[4] = at.y
            end
        end
        found = found + 1
    end
    local ____temp_6
    if found == 0 then
        ____temp_6 = nil
    else
        ____temp_6 = corners
    end
    return ____temp_6
end
local Placements = __TS__Class()
Placements.name = "Placements"
function Placements.prototype.____constructor(self)
    self.known = __TS__New(Map)
    self.ancestors = __TS__New(Set)
    self.cycles = 0
end
____exports.Frames = __TS__Class()
local Frames = ____exports.Frames
Frames.name = "Frames"
function Frames.prototype.____constructor(self, points)
    self.points = points
    self.all = {}
    self.templates = __TS__New(Map)
    self.gameUi = __TS__New(Set)
end
function Frames.prototype.add(self, handle, ____type, name, parent, context)
    local frame = __TS__ObjectAssign(
        {},
        handle,
        {
            type = ____type,
            name = name,
            template = "",
            context = context,
            parent = parent,
            text = "",
            visible = true,
            enabled = true,
            level = 0,
            textLimit = DEFAULT_TEXT_LIMIT,
            width = 0,
            height = 0,
            points = __TS__New(Map),
            anchors = {},
            destroyed = false,
            texture = "",
            color = 4294967295,
            textColor = 4294967295,
            alpha = 255,
            font = {file = "", height = 0, flags = 0},
            alignment = nil,
            scale = 1,
            plain = true,
            model = "",
            modelCamera = 0,
            spriteAnimation = 0,
            spriteTime = -1,
            simple = false,
            layer = "",
            texCoord = nil
        }
    )
    local ____self_all_7 = self.all
    ____self_all_7[#____self_all_7 + 1] = frame
    return frame
end
function Frames.prototype.define(self, definitions)
    for ____, definition in ipairs(definitions) do
        self.templates:set(definition.name, definition)
    end
end
function Frames.prototype.create(self, handle, name, parent, context)
    local definition = self.templates:get(name)
    local root = self:add(
        handle(),
        definition and definition.type or name,
        name,
        parent,
        context
    )
    root.plain = false
    root.template = name
    if definition == nil then
        return root
    end
    root.width = definition.width
    root.height = definition.height
    root.texture = definition.texture or ""
    if definition.text ~= nil then
        root.text = definition.text
    end
    styleText(root, definition)
    local byKey = __TS__New(Map, {{"root", root}})
    local placed = {}
    local make
    make = function(nodes, owner)
        for ____, node in ipairs(nodes) do
            local frame = self:add(
                handle(),
                node.type,
                (definition.name .. string.upper(string.sub(node.key, 1, 1))) .. string.sub(node.key, 2),
                owner,
                context
            )
            frame.plain = false
            frame.width = node.width or 0
            frame.height = node.height or 0
            if node.type == "TEXT" and node.text ~= nil then
                frame.text = node.text
            end
            if node.type == "TEXT" then
                styleText(frame, node)
            end
            frame.texture = node.texture or ""
            byKey:set(node.key, frame)
            placed[#placed + 1] = {node, frame}
            make(node.children or ({}), frame)
        end
    end
    make(definition.children or ({}), root)
    for ____, ____value in ipairs(placed) do
        local node = ____value[1]
        local frame = ____value[2]
        for ____, anchor in ipairs(node.points or ({})) do
            do
                local ____temp_10
                if anchor.relative == nil then
                    ____temp_10 = frame.parent
                else
                    ____temp_10 = byKey:get(anchor.relative)
                end
                local relative = ____temp_10
                if relative == nil then
                    goto __continue40
                end
                local ____frame_anchors_11 = frame.anchors
                ____frame_anchors_11[#____frame_anchors_11 + 1] = {
                    point = anchor.point,
                    relative = relative,
                    relativePoint = anchor.relativePoint or anchor.point,
                    x = anchor.x,
                    y = anchor.y
                }
            end
            ::__continue40::
        end
    end
    return root
end
function Frames.prototype.createSimple(self, handle, name, parent, context)
    local definition = self.templates:get(name)
    if definition == nil or definition.type ~= "SIMPLEFRAME" then
        return nil
    end
    local root = self:add(
        handle(),
        "SIMPLEFRAME",
        name,
        parent,
        context
    )
    root.simple = true
    root.width = definition.width
    root.height = definition.height
    for ____, texture in ipairs(definition.textures or ({})) do
        local frame = self:add(
            handle(),
            "TEXTURE",
            (definition.name .. string.upper(string.sub(texture.key, 1, 1))) .. string.sub(texture.key, 2),
            root,
            context
        )
        frame.simple = true
        frame.layer = texture.layer
        frame.texCoord = texture.texCoord
        frame.texture = texture.file or ""
        frame.width = texture.width or 0
        frame.height = texture.height or 0
        if texture.anchor ~= nil then
            local ____frame_anchors_12 = frame.anchors
            ____frame_anchors_12[#____frame_anchors_12 + 1] = {
                point = texture.anchor.point,
                relative = root,
                relativePoint = texture.anchor.point,
                x = texture.anchor.x,
                y = texture.anchor.y
            }
        elseif texture.width == nil and texture.height == nil then
            for ____, point in ipairs({"TOPLEFT", "BOTTOMRIGHT"}) do
                local ____frame_anchors_13 = frame.anchors
                ____frame_anchors_13[#____frame_anchors_13 + 1] = {
                    point = point,
                    relative = root,
                    relativePoint = point,
                    x = 0,
                    y = 0
                }
            end
        end
    end
    return root
end
function Frames.prototype.named(self, name, context)
    for ____, frame in ipairs(self.all) do
        if not frame.destroyed and frame.name == name and frame.context == context then
            return frame
        end
    end
    return nil
end
function Frames.prototype.byId(self, id)
    for ____, frame in ipairs(self.all) do
        if frame.id == id and not frame.destroyed then
            return frame
        end
    end
    return nil
end
function Frames.prototype.children(self, parent)
    local found = {}
    for ____, frame in ipairs(self.all) do
        if frame.parent == parent and not frame.destroyed then
            found[#found + 1] = frame
        end
    end
    return found
end
function Frames.prototype.destroy(self, frame)
    frame.destroyed = true
    if self.focused == frame then
        self.focused = nil
    end
    for ____, child in ipairs(self.all) do
        if child.parent == frame and not child.destroyed then
            self:destroy(child)
        end
    end
end
function Frames.prototype.focus(self, frame, flag)
    if flag then
        self.focused = frame
    elseif self.focused == frame then
        self.focused = nil
    end
end
function Frames.prototype.point(self, hovered, pushed)
    self.hovered = hovered
    self.pushed = pushed
end
function Frames.prototype.control(self, frame)
    if not frame.enabled then
        return "disabled"
    end
    if frame ~= self.hovered then
        return nil
    end
    return frame == self.pushed and "pushed" or "hover"
end
function Frames.prototype.shown(self, frame)
    do
        local at = frame
        while at ~= nil do
            if at.destroyed or not at.visible then
                return false
            end
            at = at.parent
        end
    end
    return true
end
function Frames.prototype.shownText(self)
    local texts = {}
    for ____, frame in ipairs(self.all) do
        if frame.text ~= "" and self:shown(frame) then
            texts[#texts + 1] = frame.text
        end
    end
    return texts
end
function Frames.prototype.snapshot(self, options)
    if options == nil then
        options = {}
    end
    local snapshots = {}
    local placements = __TS__New(Placements)
    local simples = __TS__New(Map)
    for ____, frame in ipairs(self.all) do
        do
            if frame.destroyed then
                goto __continue85
            end
            if frame.simple and frame.type == "SIMPLEFRAME" then
                simples:set(frame, simples.size)
            end
            local alpha = shownAlpha(frame)
            local visible = self:shown(frame)
            if options.visibleOnly and (not visible or alpha <= 0) then
                goto __continue85
            end
            local ____temp_14
            if frame.template == "" then
                ____temp_14 = nil
            else
                ____temp_14 = self:control(frame)
            end
            local control = ____temp_14
            local ____temp_17 = {kind = frame.kind, id = frame.id}
            local ____frame_name_18 = frame.name
            local ____frame_type_19 = frame.type
            local ____temp_20 = frame.template == "" and ({}) or ({template = frame.template})
            local ____temp_21 = control == nil and ({}) or ({control = control})
            local ____opt_15 = frame.parent
            snapshots[#snapshots + 1] = __TS__ObjectAssign(
                {handle = ____temp_17, name = ____frame_name_18, type = ____frame_type_19},
                ____temp_20,
                ____temp_21,
                {
                    parentId = ____opt_15 and ____opt_15.id,
                    rectangle = self:rectangle(frame, placements),
                    text = frame.text,
                    texture = frame.texture,
                    color = frame.color,
                    textColor = frame.textColor,
                    alpha = alpha,
                    visible = visible,
                    level = frame.simple and simpleLevel(frame, simples) or self:drawLevel(frame),
                    font = frame.font,
                    alignment = frameAlignment(frame),
                    scale = frame.scale,
                    plain = frame.plain
                },
                snapshotUv(frame),
                frame.model == "" and ({}) or ({sprite = {model = frame.model, camera = frame.modelCamera, animation = frame.spriteAnimation, time = frame.spriteTime}})
            )
        end
        ::__continue85::
    end
    return snapshots
end
function Frames.prototype.drawLevel(self, frame)
    do
        local at = frame
        while at ~= nil do
            if at.level ~= 0 then
                return at.level
            end
            at = at.parent
        end
    end
    return 0
end
function Frames.prototype.rectangle(self, frame, placements)
    if placements == nil then
        placements = __TS__New(Placements)
    end
    if placements.known:has(frame) then
        return placements.known:get(frame)
    end
    if placements.ancestors:has(frame) then
        placements.cycles = placements.cycles + 1
        return nil
    end
    local cycles = placements.cycles
    placements.ancestors:add(frame)
    local rectangle = self:place(frame, placements)
    placements.ancestors:delete(frame)
    if placements.cycles == cycles then
        placements.known:set(frame, rectangle)
    end
    return rectangle
end
function Frames.prototype.place(self, frame, placements)
    local scale = 1
    do
        local at = frame
        while at ~= nil do
            scale = scale * at.scale
            at = at.parent
        end
    end
    local corners = fitCorners(
        self:placedPoints(frame, scale, placements),
        frame.width * scale,
        frame.height * scale
    )
    if corners == nil then
        return nil
    end
    if frame.parent ~= nil and self.gameUi:has(frame.parent) and (corners[1] < -EDGE or corners[3] > 0xcccccdp-24 + EDGE) then
        return nil
    end
    return corners
end
function Frames.prototype.placedPoints(self, frame, scale, placements)
    local placed = {}
    for ____, ____value in __TS__Iterator(frame.points) do
        local point = ____value[1]
        local at = ____value[2]
        local share = self.points:get(point)
        if share ~= nil then
            placed[#placed + 1] = {share, at}
        end
    end
    for ____, anchor in ipairs(frame.anchors) do
        do
            local share = NAMED_POINTS:get(anchor.point)
            local relativeShare = NAMED_POINTS:get(anchor.relativePoint)
            local relative = self:rectangle(anchor.relative, placements)
            if share == nil or relativeShare == nil or relative == nil then
                goto __continue107
            end
            local left, top, right, bottom = table.unpack(relative, 1, 4)
            placed[#placed + 1] = {share, {x = left + relativeShare[1] * (right - left) + anchor.x * scale, y = top - relativeShare[2] * (top - bottom) + anchor.y * scale}}
        end
        ::__continue107::
    end
    return placed
end
function Frames.prototype.at(self, x, y, takes)
    local found
    local placements = __TS__New(Placements)
    for ____, frame in ipairs(self.all) do
        do
            if not frame.enabled or not self:shown(frame) then
                goto __continue111
            end
            local rectangle = self:rectangle(frame, placements)
            if rectangle == nil then
                goto __continue111
            end
            local left, top, right, bottom = table.unpack(rectangle, 1, 4)
            if x < left or x > right or y > top or y < bottom or not takes(frame) then
                goto __continue111
            end
            if found == nil or self:drawLevel(frame) >= self:drawLevel(found) then
                found = frame
            end
        end
        ::__continue111::
    end
    return found
end
function Frames.prototype.type(self, text)
    local box = self.focused
    if box == nil or box.type ~= "EDITBOX" or not box.enabled or not self:shown(box) then
        return false
    end
    box.text = box.textLimit >= 0 and __TS__StringSlice(
        box.text .. text,
        0,
        math.max(box.textLimit, #box.text)
    ) or box.text .. text
    return true
end
return ____exports
