local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local ____exports = {}
local ____lookup = require("src.runtime.lookup")
local ____intMath = require("src.sim.intMath")
local ____frameRing = require("src.netcode.frameRing")
local ____ledger = require("src.netcode.ledger")
local ____message = require("src.netcode.message")
local ____shadowSchedule = require("src.netcode.shadowSchedule")
____exports.NET_SETTINGS = {delay = 2, window = 24, sendEvery = 6, catchUp = 6}
local HISTORY = 128
local EPOCH = 0
local NO_ROLLBACK = ____ledger.NO_FRAME
local function rows(codec, count)
    local made = {}
    do
        local index = 0
        while index < count do
            made[#made + 1] = codec.neutral()
            index = index + 1
        end
    end
    return made
end
function ____exports.createSession(sim, settings, players, ____local, initial)
    local codec = sim.codec
    local used = {}
    do
        local player = 0
        while player < players do
            used[#used + 1] = ____frameRing.frameRing(codec, HISTORY)
            player = player + 1
        end
    end
    local states = {}
    local stateFrames = {}
    do
        local slot = 0
        while slot < HISTORY do
            states[#states + 1] = initial
            stateFrames[#stateFrames + 1] = slot == 0 and 0 or -1
            slot = slot + 1
        end
    end
    local schedule = ____shadowSchedule.shadowSchedule(codec, players, HISTORY, settings.window)
    if not ____shadowSchedule.beginShadowEpoch(
        schedule,
        EPOCH,
        settings.delay,
        settings.window,
        ____ledger.allParticipants(players)
    ) then
        do
            local ____thrown = __TS__New(Error, "the net settings do not fit the schedule")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/netcode/session.ts:81"
            end
            error(____thrown, 0)
        end
    end
    return {
        players = players,
        ["local"] = ____local >= 0 and ____local < players and ____local or -1,
        schedule = schedule,
        ledger = schedule.fixed.ledger,
        used = used,
        states = states,
        stateFrames = stateFrames,
        resolved = rows(codec, players),
        rows = rows(codec, players),
        frameRows = rows(codec, players),
        inbox = rows(codec, ____message.MESSAGE_MAX_FRAMES),
        confirmed = initial,
        callbacks = 0,
        rollbackFrom = NO_ROLLBACK,
        sentThrough = settings.delay,
        credit = 2 * settings.sendEvery,
        sinceSend = 0,
        pressWaiting = false,
        lastHadPress = false,
        stats = {
            rollbacks = 0,
            deepest = 0,
            held = 0,
            messages = 0,
            largest = 0,
            refused = 0
        }
    }
end
function ____exports.presentFrame(session)
    return session.schedule.nextSpeculative - 1
end
function ____exports.confirmedFrame(session)
    return session.schedule.nextConfirmed - 1
end
function ____exports.localRow(session, frame)
    return ____shadowSchedule.pendingRow(session.schedule, EPOCH, frame)
end
function ____exports.predictedAt(session, frame)
    local slot = frame % HISTORY
    local ____temp_0
    if session.stateFrames[slot + 1] == frame then
        ____temp_0 = session.states[slot + 1]
    else
        ____temp_0 = nil
    end
    return ____temp_0
end
function ____exports.predictedState(session)
    return ____lookup.at(
        session.states,
        ____exports.presentFrame(session) % HISTORY
    )
end
function ____exports.remoteThrough(session)
    return ____shadowSchedule.remoteThrough(session.schedule, session["local"])
end
function ____exports.receive(session, sim, sender, wire)
    if sender < 0 or sender >= session.players then
        return "wrongSender"
    end
    local decoded = ____message.decodeMessage(sim.codec, wire, session.inbox)
    local receipt = decoded == nil and "malformed" or ____shadowSchedule.acceptSynchronized(
        session.schedule,
        sender,
        decoded.firstFrame,
        session.inbox,
        decoded.count
    )
    if decoded == nil or receipt ~= "accepted" then
        local ____session_stats_1, ____refused_2 = session.stats, "refused"
        ____session_stats_1[____refused_2] = ____session_stats_1[____refused_2] + 1
        return receipt
    end
    local from = ____shadowSchedule.lateFrom(session.schedule, sender)
    if sender == session["local"] then
        return receipt
    end
    local used = ____lookup.at(session.used, sender)
    local present = ____exports.presentFrame(session)
    do
        local frame = from
        while frame < from + decoded.count do
            if frame > present or frame >= session.rollbackFrom then
                break
            end
            local ran = ____frameRing.ringRow(used, frame)
            local accepted = ____ledger.acceptedRow(session.ledger, sender, frame)
            if ran == nil or accepted == nil or not sim.codec.same(ran, accepted) then
                session.rollbackFrom = frame
                break
            end
            frame = frame + 1
        end
    end
    return receipt
end
function ____exports.leave(session, sim, player)
    if player < 0 or player >= session.players then
        return
    end
    local used = ____lookup.at(session.used, player)
    do
        local frame = ____ledger.leaveLedger(session.ledger, player) + 1
        while frame <= ____exports.presentFrame(session) and frame < session.rollbackFrom do
            local ran = ____frameRing.ringRow(used, frame)
            if ran == nil or not sim.codec.same(ran, session.ledger.idle) then
                session.rollbackFrom = frame
            end
            frame = frame + 1
        end
    end
end
local function runFrame(session, sim)
    local schedule = session.schedule
    local frame = schedule.nextSpeculative
    local before = ____exports.predictedAt(session, frame - 1)
    if before == nil then
        do
            local ____thrown = __TS__New(
                Error,
                ("frame " .. tostring(frame)) .. " needs a snapshot older than the rollback history"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/netcode/session.ts:153"
            end
            error(____thrown, 0)
        end
    end
    if ____shadowSchedule.resolveSpeculative(schedule, EPOCH, session["local"], session.resolved) == nil then
        do
            local ____thrown = __TS__New(
                Error,
                ("frame " .. tostring(frame)) .. " cannot be resolved"
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/netcode/session.ts:154"
            end
            error(____thrown, 0)
        end
    end
    do
        local player = 0
        while player < session.players do
            local ring = ____lookup.at(session.used, player)
            ____frameRing.ringStore(
                sim.codec,
                ring,
                frame,
                ____lookup.at(session.resolved, player)
            )
            session.frameRows[player + 1] = ____lookup.at(ring.rows, frame % HISTORY)
            player = player + 1
        end
    end
    local state = sim.step(before, session.frameRows)
    local slot = frame % HISTORY
    session.states[slot + 1] = state
    session.stateFrames[slot + 1] = frame
    ____shadowSchedule.completeSpeculative(schedule, EPOCH, frame)
    sim.predicted(state)
end
local function rollBack(session, sim)
    local schedule = session.schedule
    local present = ____exports.presentFrame(session)
    local from = math.max(session.rollbackFrom, schedule.nextConfirmed)
    session.rollbackFrom = NO_ROLLBACK
    if from > present then
        return
    end
    local depth = present - from + 1
    local ____session_stats_3, ____rollbacks_4 = session.stats, "rollbacks"
    ____session_stats_3[____rollbacks_4] = ____session_stats_3[____rollbacks_4] + 1
    if depth > session.stats.deepest then
        session.stats.deepest = depth
    end
    ____shadowSchedule.rewindSpeculative(schedule, EPOCH, from)
    do
        local player = 0
        while player < session.players do
            local basis = ____frameRing.ringRow(
                ____lookup.at(session.used, player),
                from - 1
            )
            ____shadowSchedule.rememberResolvedInput(
                schedule,
                player,
                basis or sim.codec.neutral()
            )
            player = player + 1
        end
    end
    while schedule.nextSpeculative <= present do
        runFrame(session, sim)
    end
end
local function predict(session, sim, settings, sample)
    local codec = sim.codec
    local schedule = session.schedule
    do
        local ran = 0
        while ran < settings.catchUp and ____exports.presentFrame(session) < session.callbacks do
            if not ____shadowSchedule.mayAdvanceSpeculative(schedule, session["local"]) then
                local ____session_stats_5, ____held_6 = session.stats, "held"
                ____session_stats_5[____held_6] = ____session_stats_5[____held_6] + 1
                return
            end
            if session["local"] >= 0 then
                ____shadowSchedule.captureLocal(schedule, EPOCH, sample)
                if codec.urgent(sample) then
                    session.pressWaiting = true
                end
                codec.hold(sample, sample)
            end
            runFrame(session, sim)
            ran = ran + 1
        end
    end
end
local function confirm(session, sim)
    local schedule = session.schedule
    while ____shadowSchedule.mayAdvanceConfirmed(schedule) do
        local frame = schedule.nextConfirmed
        if not ____shadowSchedule.readConfirmed(schedule, EPOCH, session.rows) then
            do
                local ____thrown = __TS__New(
                    Error,
                    ("frame " .. tostring(frame)) .. " has no accepted rows"
                )
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/netcode/session.ts:206"
                end
                error(____thrown, 0)
            end
        end
        session.confirmed = sim.step(session.confirmed, session.rows)
        ____shadowSchedule.completeConfirmed(schedule, EPOCH, frame)
        sim.confirmed(session.confirmed)
    end
end
local function send(session, sim, settings)
    if session["local"] < 0 then
        return nil
    end
    session.sinceSend = session.sinceSend + 1
    session.credit = math.min(session.credit + 1, 2 * settings.sendEvery)
    local captured = ____exports.presentFrame(session) + settings.delay
    if session.sentThrough >= captured then
        return nil
    end
    local due = session.sinceSend >= settings.sendEvery or session.pressWaiting
    local allowed = session.credit >= settings.sendEvery or session.pressWaiting and session.lastHadPress and session.credit >= 0
    if not due or not allowed then
        return nil
    end
    local message = ____message.encodeMessage(
        sim.codec,
        session.sentThrough + 1,
        captured,
        function(frame)
            local row = ____exports.localRow(session, frame)
            if row == nil then
                do
                    local ____thrown = __TS__New(
                        Error,
                        "no local row for frame " .. tostring(frame)
                    )
                    if _G.__wispThrown ~= ____thrown then
                        _G.__wispThrown = ____thrown
                        _G.__wispThrowSite = "wisp/src/netcode/session.ts:224"
                    end
                    error(____thrown, 0)
                end
            end
            return row
        end
    )
    session.sentThrough = message.lastFrame
    session.credit = session.credit - settings.sendEvery
    session.sinceSend = 0
    session.lastHadPress = session.pressWaiting
    session.pressWaiting = false
    local ____session_stats_7, ____messages_8 = session.stats, "messages"
    ____session_stats_7[____messages_8] = ____session_stats_7[____messages_8] + 1
    if #message.wire > session.stats.largest then
        session.stats.largest = #message.wire
    end
    return message.wire
end
function ____exports.tick(session, sim, settings, sample)
    session.callbacks = session.callbacks + 1
    rollBack(session, sim)
    predict(session, sim, settings, sample)
    confirm(session, sim)
    return send(session, sim, settings)
end
return ____exports
