local ____exports = {}
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
function ____exports.createTimer()
    local world = ____world.boundWorld()
    local ____opt_0 = world.log
    if ____opt_0 ~= nil then
        ____opt_0("CreateTimer", {})
    end
    return ____types.fromHandle(world.clock:create())
end
function ____exports.startTimer(timer, seconds, periodic, handler)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("TimerStart", {timer, seconds, periodic, handler})
    end
    world.clock:start(
        ____types.asHandle(timer),
        seconds,
        periodic,
        handler
    )
end
function ____exports.pauseTimer(timer)
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("PauseTimer", {timer})
    end
    world.clock:pause(____types.asHandle(timer))
end
function ____exports.destroyTimer(timer)
    local world = ____world.boundWorld()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("DestroyTimer", {timer})
    end
    world.clock:destroy(____types.asHandle(timer))
end
function ____exports.localElapsed(timer)
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("TimerGetElapsed", {timer})
    end
    return world.clock:elapsed(____types.asHandle(timer))
end
function ____exports.setNormalSpeed()
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("SetGameSpeed", {"MAP_SPEED_NORMAL"})
    end
    world.clock.speed = "MAP_SPEED_NORMAL"
end
function ____exports.lockSpeed()
    local ____opt_12 = ____world.boundWorld().log
    if ____opt_12 ~= nil then
        ____opt_12("SetMapFlag", {"MAP_LOCK_SPEED", true})
    end
end
function ____exports.gameSpeed()
    local world = ____world.boundWorld()
    local ____opt_14 = world.log
    if ____opt_14 ~= nil then
        ____opt_14("GetGameSpeed", {})
    end
    return ____types.fromValue(world.clock.speed)
end
function ____exports.restartMatch(scoreScreen)
    local ____opt_16 = ____world.boundWorld().log
    if ____opt_16 ~= nil then
        ____opt_16("RestartGame", {scoreScreen})
    end
end
____exports.GameSpeed = {
    slowest = ____types.fromValue("MAP_SPEED_SLOWEST"),
    slow = ____types.fromValue("MAP_SPEED_SLOW"),
    normal = ____types.fromValue("MAP_SPEED_NORMAL"),
    fast = ____types.fromValue("MAP_SPEED_FAST"),
    fastest = ____types.fromValue("MAP_SPEED_FASTEST")
}
return ____exports
