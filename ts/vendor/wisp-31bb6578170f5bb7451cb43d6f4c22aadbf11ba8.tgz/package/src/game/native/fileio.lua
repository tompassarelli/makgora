local ____exports = {}
local ____fileChunks = require("src.runtime.fileChunks")
local ____gameFiles = require("src.runtime.gameFiles")
local ____files = require("src.game.native.files")
local ____world = require("src.game.native.world")
function ____exports.writeLines(filename, lines)
    ____files.clearFileLines()
    ____files.startFile()
    for ____, line in ipairs(lines) do
        ____files.addFileLine(line)
    end
    ____files.endFile(filename)
end
local EMPTY = " "
--- The FileIO chunks of the file at `filename`, as the Warcraft reader returns them: up to the first empty slot, or the slot count.
function ____exports.readChunks(filename)
    local stored = ____world.boundWorld().files:read(filename) or ({})
    local chunks = {}
    do
        local level = 0
        while level < ____gameFiles.CHUNKS_PER_FILE do
            local chunk = level < #stored and (stored[level + 1] or "") or EMPTY
            if chunk == EMPTY then
                break
            end
            chunks[#chunks + 1] = chunk
            level = level + 1
        end
    end
    return chunks
end
function ____exports.readChunk(filename)
    local ____opt_0 = ____world.boundWorld().files:read(filename)
    local chunk = ____opt_0 and ____opt_0[1] or EMPTY
    local ____temp_2
    if chunk == EMPTY or chunk == "" then
        ____temp_2 = nil
    else
        ____temp_2 = chunk
    end
    return ____temp_2
end
function ____exports.writeLine(filename, line)
    ____exports.writeLines(filename, {line})
end
function ____exports.writeChunks(filename, chunks)
    local lines = ____fileChunks.fileChunkLines(chunks)
    if lines == nil then
        return false
    end
    ____exports.writeLines(filename, lines)
    return true
end
return ____exports
