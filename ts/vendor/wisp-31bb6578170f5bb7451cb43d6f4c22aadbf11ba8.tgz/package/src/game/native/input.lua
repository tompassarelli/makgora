local ____exports = {}
local ____types = require("src.game.native.types")
local ____world = require("src.game.native.world")
function ____exports.osKey(code)
    local ____opt_0 = ____world.boundWorld().log
    if ____opt_0 ~= nil then
        ____opt_0("ConvertOsKeyType", {code})
    end
    return ____types.fromValue(code)
end
function ____exports.addKeyEvent(events, player, key, modifiers, down)
    local world = ____world.boundWorld()
    local ____opt_2 = world.log
    if ____opt_2 ~= nil then
        ____opt_2("BlzTriggerRegisterPlayerKeyEvent", {
            events,
            player,
            key,
            modifiers,
            down
        })
    end
    world.events:registerKey(
        ____types.asHandle(events),
        ____types.asNumber(player),
        ____types.asNumber(key),
        modifiers,
        down
    )
end
function ____exports.eventKey()
    local world = ____world.boundWorld()
    local ____opt_4 = world.log
    if ____opt_4 ~= nil then
        ____opt_4("BlzGetTriggerPlayerKey", {})
    end
    local key = world.events:triggerKey()
    local ____opt_6 = world.log
    if ____opt_6 ~= nil then
        ____opt_6("GetHandleId", {key})
    end
    return key
end
function ____exports.keyDown(key)
    local world = ____world.boundWorld()
    local ____opt_8 = world.log
    if ____opt_8 ~= nil then
        ____opt_8("BlzIsKeyPressed", {key})
    end
    return world.input:keyHeld(____types.asNumber(key))
end
function ____exports.windowFocused()
    local world = ____world.boundWorld()
    local ____opt_10 = world.log
    if ____opt_10 ~= nil then
        ____opt_10("BlzIsLocalClientActive", {})
    end
    return world.input:focused()
end
function ____exports.pointerX()
    local world = ____world.boundWorld()
    local ____opt_12 = world.log
    if ____opt_12 ~= nil then
        ____opt_12("BlzGetMouseScreenPosX", {})
    end
    return world.input.pointerX
end
function ____exports.pointerY()
    local world = ____world.boundWorld()
    local ____opt_14 = world.log
    if ____opt_14 ~= nil then
        ____opt_14("BlzGetMouseScreenPosY", {})
    end
    return world.input.pointerY
end
function ____exports.eventPointerX()
    local world = ____world.boundWorld()
    local ____opt_16 = world.log
    if ____opt_16 ~= nil then
        ____opt_16("BlzGetTriggerPlayerMouseX", {})
    end
    return world.events:triggerMouseX()
end
function ____exports.eventPointerY()
    local world = ____world.boundWorld()
    local ____opt_18 = world.log
    if ____opt_18 ~= nil then
        ____opt_18("BlzGetTriggerPlayerMouseY", {})
    end
    return world.events:triggerMouseY()
end
function ____exports.mouseDown(button)
    local world = ____world.boundWorld()
    local ____opt_20 = world.log
    if ____opt_20 ~= nil then
        ____opt_20("BlzIsMouseButtonPressed", {button})
    end
    return world.input:mouseButtonHeld(button)
end
function ____exports.setPointer(x, y)
    local ____opt_22 = ____world.boundWorld().log
    if ____opt_22 ~= nil then
        ____opt_22("BlzSetMousePos", {x, y})
    end
end
function ____exports.showCursor(shown)
    local world = ____world.boundWorld()
    local ____opt_24 = world.log
    if ____opt_24 ~= nil then
        ____opt_24("BlzEnableCursor", {shown})
    end
    world.input.cursorShown = shown
end
function ____exports.addChatEvent(events, player, text, exact)
    local world = ____world.boundWorld()
    local ____opt_26 = world.log
    if ____opt_26 ~= nil then
        ____opt_26("TriggerRegisterPlayerChatEvent", {events, player, text, exact})
    end
    world.events:registerChat(
        ____types.asHandle(events),
        ____types.asNumber(player),
        text,
        exact
    )
end
function ____exports.chatText()
    local world = ____world.boundWorld()
    local ____opt_28 = world.log
    if ____opt_28 ~= nil then
        ____opt_28("GetEventPlayerChatString", {})
    end
    return world.events:triggerChat()
end
function ____exports.addPointerMoveEvent(events, player)
    local world = ____world.boundWorld()
    local ____opt_30 = world.log
    if ____opt_30 ~= nil then
        ____opt_30("TriggerRegisterPlayerEvent", {events, player, "EVENT_PLAYER_MOUSE_MOVE"})
    end
    world.events:registerMouseMove(
        ____types.asHandle(events),
        ____types.asNumber(player)
    )
end
function ____exports.enableSelections(selection, only)
    local ____opt_32 = ____world.boundWorld().log
    if ____opt_32 ~= nil then
        ____opt_32("BlzEnableSelections", {selection, only})
    end
end
function ____exports.enableUserControl(enabled)
    local ____opt_34 = ____world.boundWorld().log
    if ____opt_34 ~= nil then
        ____opt_34("EnableUserControl", {enabled})
    end
end
____exports.MouseButton = {left = ____types.fromValue("MOUSE_BUTTON_TYPE_LEFT")}
return ____exports
