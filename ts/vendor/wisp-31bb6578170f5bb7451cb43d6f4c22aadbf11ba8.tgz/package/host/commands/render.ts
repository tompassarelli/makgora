import { existsSync } from "node:fs";
import { mkdir, writeFile } from "node:fs/promises";
import { dirname, join, resolve } from "node:path";
import { Console, Effect, Schema } from "effect";
import { type Command, describeCause, flagValues, UsageFailure } from "../cli/command";
import { type ChromeAngle, renderScenes } from "../render/headlessRender";
import { compareScene, exceeded, type RecordedBounds, type RegionReport } from "../render/renderCompare";
import { modelPath, readSceneList, sceneOf } from "../render/compareScenes";
import { rerunInGpuLease } from "../render/gpuLease";
import { renderNativeScenes } from "../window/nativeRender";

class RenderCompareFailure extends Schema.TaggedError<RenderCompareFailure, { readonly brand: unique symbol }>()("RenderCompareFailure", { problem: Schema.String }) {
  override get message() { return this.problem; }
}

/** The recorded bounds beside the scene list: `bounds.json` maps "REFERENCE-CANDIDATE" to a bound per region name. */
const readRecorded = async (scenes: string, pair: string): Promise<RecordedBounds> => {
  const file = Bun.file(join(dirname(scenes), "bounds.json"));
  return (await file.exists()) ? ((await file.json()) as Record<string, RecordedBounds>)[pair] ?? {} : {};
};

const NVIDIA_EGL = "/run/opengl-driver/share/glvnd/egl_vendor.d/10_nvidia.json";

const BACKENDS: Readonly<Record<string, ChromeAngle>> = { "chrome": "vulkan", "chrome-gl": "gl-egl", "chrome-vulkan": "vulkan", "chrome-swiftshader": "swiftshader" };
const NATIVE = "native";
const NAMES = [...Object.keys(BACKENDS), NATIVE].join("|");
const USAGE = `compare --reference ${NAMES} --candidate ${NAMES} --scenes FILE [--out DIR]   (wisp:docs/render-compare.md)`;

/** `render compare`: renders every scene of a scene list through two renderers (Chrome on an ANGLE backend, or the native window's offscreen renderer) and writes the per-region, per-metric difference between them as `bound.json`. */
export const renderCommand: Command = (args) => Effect.gen(function*() {
  const [action] = args, [reference] = flagValues(args, "reference"), [candidate] = flagValues(args, "candidate"), [scenes] = flagValues(args, "scenes"), [outFlag] = flagValues(args, "out");
  const known = (name: string | undefined): name is string => name !== undefined && (name === NATIVE || BACKENDS[name] !== undefined);
  if (action !== "compare" || !known(reference) || !known(candidate) || scenes === undefined) return yield* new UsageFailure({ problem: USAGE });
  const out = outFlag ?? join("build/render", `${reference}-${candidate}`);
  const leased = yield* rerunInGpuLease();
  if (leased !== undefined) return leased === 0 ? undefined : yield* new RenderCompareFailure({ problem: `the run inside the gpu lease exited ${leased}` });
  const attempt = <A>(run: () => Promise<A>) => Effect.tryPromise({ try: run, catch: (cause) => new RenderCompareFailure({ problem: describeCause(cause) }) });
  const { list, models } = yield* attempt(() => readSceneList(resolve(scenes)));
  const sceneSet = list.scenes.map((spec, index) => sceneOf(spec, index));
  const project = { readAsset: async (path: string) => models.get(path), width: list.width, height: list.height };
  const render = (name: string, directory: string) => {
    const angle = BACKENDS[name];
    return angle === undefined
      ? renderNativeScenes(project, sceneSet, directory).pipe(Effect.mapError((cause) => new RenderCompareFailure({ problem: cause.message })))
      : renderScenes({ ...project, angle, ...(existsSync(NVIDIA_EGL) ? { chromeEnv: { __EGL_VENDOR_LIBRARY_FILENAMES: NVIDIA_EGL } } : {}) }, sceneSet, directory).pipe(Effect.mapError((cause) => new RenderCompareFailure({ problem: cause.message })));
  };
  const root = resolve(out), referenceDirectory = join(root, "reference"), candidateDirectory = join(root, "candidate");
  yield* attempt(() => mkdir(root, { recursive: true }));
  const referenceImages = yield* render(reference, referenceDirectory);
  const candidateImages = yield* render(candidate, candidateDirectory);
  const recorded = yield* attempt(() => readRecorded(resolve(scenes), `${reference}-${candidate}`));
  const regions: RegionReport[] = yield* attempt(async () => (await Promise.all(list.scenes.map(async (spec, index) => {
    const read = (directory: string, image: string | undefined) => Bun.file(join(directory, image ?? "")).bytes();
    return compareScene(spec.name, await read(referenceDirectory, referenceImages[index]?.image), await read(candidateDirectory, candidateImages[index]?.image), recorded);
  }))).flat());
  const gpu = async (directory: string) => (JSON.parse(await Bun.file(join(directory, "render.json")).text()) as { gpu: string }).gpu;
  const report = { reference, candidate, gpu: yield* attempt(async () => ({ reference: await gpu(referenceDirectory), candidate: await gpu(candidateDirectory) })), width: list.width, height: list.height, scenes: list.scenes.map(modelPath), regions };
  yield* attempt(() => writeFile(join(root, "bound.json"), JSON.stringify(report, null, 2) + "\n"));
  const failed = regions.map((region) => ({ region: region.name, metrics: exceeded(region) })).filter((region) => region.metrics.length > 0);
  yield* Console.log(JSON.stringify({ regions: regions.length, judged: Object.keys(recorded).length > 0, out: join(root, "bound.json"), ...(failed.length > 0 ? { exceeded: failed } : {}) }));
  if (failed.length > 0) return yield* new RenderCompareFailure({ problem: `${failed.length} of ${regions.length} regions measured past their recorded bound: ${failed.map((region) => region.region).join(", ")}` });
});
