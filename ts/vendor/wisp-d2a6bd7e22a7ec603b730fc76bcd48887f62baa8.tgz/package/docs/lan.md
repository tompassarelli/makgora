# Offline LAN clients

For M1 checks, use the [Wisp scripted driver](headless.md#scripted-driver-and-fast-forward)
instead of starting Warcraft. #38 and #39's native setup/fast-forward goals
were replaced by this path when [#75](https://github.com/tompassarelli/wisp/issues/75)
removed Warcraft as a test dependency. Native clients supply fidelity captures.

Measured 8 October 2026 with the sample map's 120-frame `ping-reload` journey,
two Wisp clients, under the existing shared-machine load:

| Path | Starts | Setup failures / divergence | Wall time | Speed | CPU |
| --- | ---: | --- | ---: | ---: | ---: |
| Native baseline from #38 | one new game per check | not measured here | 42–64 s to start; about 24 s/check | real time | not measured here |
| Wisp `headless ping-reload --step 1 --runs 50 --json` | 50 | 0 / 0 | 1.145 s total; 22.9 ms/start and check | 87.3x | 1.536 s total process CPU |
| Wisp `headless ping-reload --runs 20 --json` | 20 | 0 / 0 | 0.561 s total; 28.1 ms/start and check | 71.3x | 0.720 s total process CPU |

All 70 runs and both clients had checksum `-123668497`, including stepped
versus normal execution. The measured throughput is about 157,000 and 128,000
sample checks/hour, calculated from each batch, versus 150/hour at the native
24-second check baseline. The process loaded the map once before each batch;
end-to-end command times including loading and JSON output were 1.180 s and
0.595 s. These are sample-map Wisp measurements, not a native LAN measurement
or the duration of Smashcraft's full parity batch. No frames are drawn and
no wall-clock waits or engine memory writes are used.

`wisp lan` runs Warcraft III clients that never sign in to Battle.net. The
current checked build is **3.0.0.24268** (9 October 2026), after Blizzard
rolled back 3.0.1. The offline pool is the default for native checks. Its
pairs play LAN matches hosted by Wisp itself: the host relays every turn,
logs every player's actions and compares client checksums.
Each pair is isolated in a network namespace with only loopback, unless
`lan pool --network` opens one named pair for solo games (below).

Start from an updated install whose `.build.info` names `3.0.0.24268`:

```sh
bun wisp lan setup --from "<clone>/pfx/drive_c/Program Files (x86)/Warcraft III" --pairs 2
bun wisp lan pool --pair 0 --pair 1 --pool-profile parity
bun wisp lan fresh MAP.w3x --pair 0
```

`lan pool` and `lan dummy` compile the map packager into
`~/.cache/wisp/lan/map-pack` when it is missing or older than
wisp:native/map-pack.c. They do it before entering the pair's network
namespace, where `nix` could not fetch StormLib, so a new host needs `nix`
and nothing built by hand.
When the private LAN plugin fails to load (a missing data directory, for
instance), the next `fresh` loads it again instead of keeping the failure
until the pool restarts.

On 9 October, two pairs played pad scripts concurrently with every native
checksum, row and fighter line equal to headless. A pair ran 70 s after
`lan pool` started and entered its match 36 s after `pad` requested it.
Two pairs are the default under normal agent load: with the signed-in clones
stopped, two pairs measured protected CPU pressure of 11–20%, while three
measured 22–31%. Keep signed-in clones for Battle.net-specific checks.

The private LAN plugin accepts only 24268. If the installed build changes,
check the plugin before requesting pair games. The 3.0.1 observations below
describe the earlier 24342 build, not the current pool path.

**Development and testing on your own offline clients and maps only.** Wisp
never switches a signed-in Battle.net client, and never touches anyone else's
game. It isn't for cheating. The terms are in
[driving-warcraft.md](driving-warcraft.md#2-lan-hosting-offline-clients-and-wisps-host).

## Historical 3.0.1.24342: no LAN provider

**Pool pairs can't play a LAN match on 3.0.1.24342.** Its menus offer no LAN
games in our tests, the private LAN plugin refuses the build, and the checked
build stays 3.0.0.24268.
Single-client games still work: see "Solo games" below.

**The clients themselves start.** A pool client on 3.0.1 shows the intro
cinematic, then the same offline sequence 3.0.0 showed (`LOGIN_DOORS`,
`AUTHENTICATION_OVERLAY`, then the `ERROR` modal "There was an error in
handling the request. Please check your VPN"). On 3.0.0 the pool joined LAN
games straight from that modal. An earlier diagnosis blamed the prefix and a
`war3_loader.dll` assertion. Neither held up:

- The game raises a breakpoint and an `0xc0000420` assertion every 10 s and
  handles them itself (30 in 5 minutes on a client that reached the modal).
  A `PROTON_LOG` that shows them isn't a crash.
- The earlier bisection counted a run as a pass only when War3Log said
  `GameMain Started` within 75 s. A fresh prefix writes nothing to War3Log
  while it plays the intro and sits at the modal (still empty after 5
  minutes), and some of those runs were still queued for capacity. Started
  the same way, 16 of 16 fresh prefixes opened the game window.
- The actual hang came from the pool's launch: its private desktops ran in a
  `moderate` batch scope. With the machine at load 70–90 and protected CPU
  pressure at 20–55%, both games of pair 1 sat at 0% CPU with no window for
  10 minutes, their main thread waiting on a lock before `winex11.drv`
  loaded. With the desktops in a `native` scope (below), the same pair
  loaded its menus about 75 s after launch and reached the modal at 3
  minutes.

## Solo games: one offline client, one local game

`wisp lan solo MAP [--pair K...]` puts every client of the running pairs named
(default: every pair in the pool) into its own single-client game of MAP, on
the loopback provider 3.0.1 kept. Each client plays alone, so this is for
single-client checks and engine tools, not checksums between clients. Start
the pairs with `wisp lan pool` first; `lan solo` returns once every client's
game UI is up and prints the seconds each took.

The pair agent (wisp:host/lan/pairAgent.ts, `POST /solo`) copies MAP
into each client's `Maps/Wisp/`, keeping at most its newest copy
([how a match starts](#how-a-match-starts)), and drives each client's menus
(`playLocalGame`, wisp:host/lan/menus.ts) as Single Player's Custom Game
does, with no click, keyboard or memory write:

1. `LoginDoorClose`. A client that never signed in sits at its login doors
   (the "Please check your VPN" modal). There the game refuses every map,
   stock maps included, with "The map is unavailable or corrupted". The
   main menu sends `LoginDoorClose` the first time it shows. After it, the
   game opens every map in the listed folders, as after a sign-in.
2. `InitializeLocalNetProvider`, answered by `OnNetProviderChanged
   {providerId: "LOOP"}` (9 s after the doors closed, under load).
3. `SetLocalPlayerName {playerName}`: a client without an account plays as
   its pool name (`lan0a`). The menus send it from their player-name prompt.
4. `GetMapList` then `CreateLobby`, as `hostLobby` does for signed-in
   clients, then `LobbyStart`.
5. After `MapLoadComplete`, `LoadingScreenGameStart`: the loading screen's
   "press any key". `IsGameUIActive {isActive: "true"}` means the game is
   playing.

Measured 8 October 2026 on 3.0.1.24342, with the machine at load 40 and
three signed-in clients running:

| Map | Clients | `lan solo` to game UI |
| --- | --- | --- |
| Booty Bay (stock, through the menu socket by hand) | lan0b | 13 s |
| SmashcraftBC (177 MB) | lan1a, lan1b | 35 s, 24 s |
| Smashcraft render40-single | lan0a, lan0b | 43 s, 48 s, then both crashed |

Playing the sample map at the parity profile, the two solo clients of pair 0
used 1.07 and 0.97 cores (measured from /proc over about 10 s). From the
pool reporting the pair running to both game UIs up took 67 s, the first
`lan solo` included.

The first `lan solo` on a fresh pair could fail with "list maps: no answer
within 10 s": the game was still opening every map in the folder (34 s on
clone-c, 8 Oct). A map list now waits up to 90 s and says so, and a return
to the menus up to 180 s. Both render40-single clients crashed about 8 s into the game
with the same read of address 0x54. Clone-a crashed hosting that map too, so
the map is the cause, not the solo path.

**One game per launch.** After `EndGame` returned both SmashcraftBC
clients to their menus, `lan solo` with another map crashed both while
loading (a null read), and a second solo game on a pair already in one ended
the first and then stalled client a on its score screen or crashed both
(smashcraft#542). So `lan solo` relaunches each client that has played a game
since its launch, waits for its login doors, and only then copies MAP and
hosts.

## Signed-in clients cloned from Tom's install

Signed-in clients serve checks that need Battle.net itself, including online
host/join and spectating, and provide the updated install copied into the
offline pool. Leave them stopped for ordinary native checks. They are copies
of Tom's working Steam/Proton prefix
(`~/.local/share/Steam/steamapps/compatdata/3516115571`), as decided in
[#53](https://github.com/tompassarelli/wisp/issues/53). Historically, on 8 October 2026
both reached the main menu on 3.0.1.24342, hosted and joined a private
passworded Smashcraft game, and `archer-neutral.pad` passed parity there.
They run GE-Proton11-7 (wine-staging 11.0) and Steam Linux Runtime 4, as the
pool does.

| Client | Host | Prefix | Account | Menu page port |
| --- | --- | --- | --- | --- |
| A | gex45 | `~/.local/share/wisp/online/clone-c` | c | 47135 |
| B | gex45 | `~/.local/share/wisp/online/clone-b` | b | 47133 |
| third client | laptop | `~/.local/share/wisp/online/clone-a` | a (Tom's) | 47137 |
| fourth client | gex45 | `~/.local/share/wisp/online/clone-d` | d (BattleTag tompaslab2) | 47139 |

Since 24 October 2026 clones b, c and d are signed in only on gex45 (copied
from the laptop, whose c and d copies were then signed out), so A and B pair
on gex45 with clone-d as a spare, and the laptop keeps only clone-a. A clone
whose folder holds a `held-by` file naming another host never starts here:
`launch.sh` exits 5, because Battle.net allows one session per account.

### Clone-a: Tom's account, only while he isn't playing

Clone-a is a third test client, made the same way as the others on 8 October
but keeping Tom's saved account-a sign-in (steps 2 and 3 below remove the
sign-in from the other clones; clone-a skips step 2). It reached the main menu
signed in as account a on 3.0.1.24342. Battle.net allows one session per
account, so Tom's own game and clone-a would sign each other out.
`launch.sh a RUN_DIR` therefore:

- refuses to start (exit 3) while any process runs Proton or Wine in Tom's
  prefix (its environment names `compatdata/3516115571`) or Tom's desktop
  (Niri, display `:0`) shows a Wine window or one titled `Warcraft III` or
  `Battle.net`;
- checks the same every 2 s while clone-a runs, and when Tom's game or
  Battle.net appears, ends clone-a's capacity session and kills any clone-a
  process left after 6 s (exit 4). With a stand-in process carrying Tom's
  prefix in its environment, clone-a's 22 processes were gone 3.4 s after it
  started.

Run clone-a only through `launch.sh`, which `bun wisp client start clone-a
--clients-file FILE` runs as a service (below). Its yield watch runs inside
that service: with the service path, a stand-in process carrying Tom's prefix
stopped clone-a within 10 s (wisp:docs/doctor.md, "Clients as services"). In a doctor clients file, don't name it
`a` or `b`: doctor maps those names to its own prefixes and to accounts c and
b, and would start the wrong launcher or type the wrong account.

### Clone-d: account d, on gex45

Clone-d is a fourth client, made on 8 October with all three steps below, for
Tom's test account d (BattleTag tompaslab2, `d` in
nixos-config:secrets/bnet.yaml). It runs as a plain clone like clone-b and
clone-c: `launch.sh d RUN_DIR`, no yielding to Tom. Sign it in once with
`wc3-login-field RUN d username|password` as in step 2 of a full session.
Clone-a and clone-d made the second two-client lane until clone-d moved to
gex45 (24 October). Its clients file named
them `clone-a` and `clone-d`, so doctor starts each through `launch.sh`
(smashcraft:ts/host/doctor/doctor.ts) and types no account:

```json
{ "clients": [
  { "name": "clone-a", "run": "RUN_A", "documents": "~/.local/share/wisp/online/clone-a/pfx/drive_c/users/steamuser/Documents/Warcraft III", "menuReportPort": 47137 },
  { "name": "clone-d", "run": "RUN_D", "documents": "~/.local/share/wisp/online/clone-d/pfx/drive_c/users/steamuser/Documents/Warcraft III", "menuReportPort": 47139 }
] }
```

with absolute paths in place of `~`.

The lanes' clients files are kept in `~/.local/state/wisp/online/`, one per
signed-in pair; which clones each pairs is in south's battlenet-accounts
skill. A lane owner starts its clients with `bun wisp client start
--clients-file FILE`: each client without a live desktop gets one as the user
service `wisp-desktop-CLIENT-OWNER` (OWNER is named by the clients file, so
`a` in two lanes' files gets two desktops), its new run folder is written into the file,
and doctor starts Battle.net as `wisp-client-CLIENT` and waits for the menu.
The services outlive the owner's turn and any task time limit;
`client status` shows them and `client stop` ends them
(wisp:docs/doctor.md, "Clients as services"). Don't start a clone with
`launch.sh` from an agent's shell or background task: it ends with that task. On 8 October clone-d kept its login: after
Battle.net was closed and `launch.sh d` started again, it signed in by itself
in 16 s, and `bun wisp client doctor --clients-file
~/.local/state/wisp/online/ad-clients.json clone-d` pressed Play and reached
the main menu in 97 s. On that desktop `wc3-login-field`'s typing didn't reach
the login form; typing through the desktop's VNC port did.

### Making a clone

With nothing running in Tom's prefix:

1. `cp -a --reflink=always ~/.local/share/Steam/steamapps/compatdata/3516115571 ~/.local/share/wisp/online/clone-c`
   (the 110 GB prefix copies in about 8 s on btrfs).
2. Remove the copied sign-in, so the clone never signs in as Tom: in the
   clone's `pfx/drive_c/users/steamuser/AppData`, delete
   `Local/Battle.net/Account`, `Local/Battle.net/BrowserCaches`,
   `Local/Battle.net/BlizzardBrowser` and the per-account
   `Roaming/Battle.net/*.config` files other than `Battle.net.config`; in
   `Battle.net.config` set `Client.SavedAccountNames` to `""` and
   `Client.AutoLogin` to `"false"`; and, with no wineserver on the clone,
   drop the `Battle.net\\UnifiedAuth`, `Battle.net\\Identity` and
   `Battle.net\\EncryptionKey` sections from its `pfx/user.reg`.
3. `bun wisp menus install "<clone>/pfx/drive_c/Program Files (x86)/Warcraft III/_retail_" --port PORT`
   with the port in the table (Tom's install uses 47124).
4. On a filesystem without reflinks (gex45's ext4), share the new clone's
   game storage with its siblings on the same build:
   `bun wisp client share "<clone>/pfx/drive_c/Program Files (x86)/Warcraft III" "<sibling>/pfx/drive_c/Program Files (x86)/Warcraft III"...`
   ([shared game storage](client.md#shared-game-storage)).

### Launching

`~/.local/share/wisp/online/launch.sh a|b|c|d RUN_DIR` starts the clone's
Battle.net on a private desktop, in its own `native` capacity scope. Doctor
and `client start` run it as the user service `wisp-client-clone-X`. It runs
what Steam's `Warcraft III (Battle.net)` shortcut runs, with
`STEAM_COMPAT_DATA_PATH` pointed at the clone and no Steam shortcut added:

```sh
exec bun "$capacity" session --class native --owner "wisp-online-clone-$1" -- \
  env -i HOME="$HOME" USER="$USER" PATH=/run/current-system/sw/bin \
  DISPLAY="$(<"$run/display")" WAYLAND_DISPLAY="$(<"$run/wayland-display")" XDG_RUNTIME_DIR="$run/runtime" XAUTHORITY= \
  PULSE_SERVER="unix:/run/user/$(id -u)/pulse/native" PULSE_SINK="wisp-online-clone-$1" \
  dbus-run-session -- steam-run env \
  STEAM_COMPAT_DATA_PATH="$clone" STEAM_COMPAT_CLIENT_INSTALL_PATH="$steam" STEAM_COMPAT_APP_ID=3775098022 \
  SteamAppId=3775098022 SteamGameId=16213922543717842944 \
  "$steam/steamapps/common/SteamLinuxRuntime_4/_v2-entry-point" --verb=waitforexitandrun -- \
  "$steam/compatibilitytools.d/GE-Proton11-7-x86_64/proton" waitforexitandrun \
  "$clone/pfx/drive_c/Program Files (x86)/Battle.net/Battle.net Launcher.exe"
```

Never set `PROTON_LOG` on the clones: it grew ~280 GB per clone and saturated
disk IO. The nixos-config watchdog `proton-log-watchdog` strips it from
`launch.sh` and truncates clone `steam-*.log` files over 1 GiB.

Before that it creates the clone's silent PipeWire sink, `wisp-online-clone-<a|b|c|d>`,
as `lan pool` does for its clients. Without one, the first client takes the
sound device and the second starts with "Unable to initialize audio device":
its `GetSoundFileDuration` reads 0 and a map that reads it desyncs (wisp#60).

A full session, from smashcraft:ts/:

1. Point a clients file at the clones (names `a` and `b`, the clone's
   `Documents/Warcraft III` and its port) and run `bun wisp client start
   --clients-file FILE`: it starts their desktops and Battle.net as services.
2. A clone without a saved login stops start at its sign-in form. Sign each in at its "Log in or sign up" form with
   nixos-config:dotfiles/bin/wc3-login-field: click the field until it has
   focus (the first click after the window opens only activates it), type the
   account name, press Enter, tick "Keep me logged in", type the password in
   the focused field and press Enter. The launcher log then says "Logged into
   Battle.net successfully". A mistyped account name opens Battle.net's
   account-creation page, which draws black on the private desktop; close
   that launcher and start again.
3. Run `bun wisp client start --clients-file FILE` again: doctor presses Play
   and it waits for the main menu (83 s and 118 s on 8 October).
4. Pass the same file to `pad` and `fresh`, which leave
   `~/.local/state/smashcraft/clients.json` alone:
   `bun wisp fresh MAP --no-quick --clients-file FILE` hosts the private
   passworded game (56 s to fighter selection), and
   `bun wisp pad SCRIPT --helper H --build typescript-integrity --out NATIVE --app-id a=steam_app_3775098022 --app-id b=steam_app_3775098022 --map MAP --clients-file FILE`
   followed by
   `bun wisp pad SCRIPT --headless --helper H --out HEADLESS --compare NATIVE`
   checks parity. On 8 October `archer-neutral.pad` landed 32 of 32 edges on
   their frames and passed: 10 native checksums replayed equal, 376 frames of
   rows, 39 fighter lines and 11 expectations.

The copied launcher logs and `smashcraft-*` receipts from Tom's install can
stay: doctor reads only launcher logs written since the running launcher
started, and the pad runner ignores receipts written before its session began.

Tom's `system.reg`, `user.reg`, `Warcraft III/.build.info` and Battle.net
`product.db` hashed the same before and after the session.

## Commands

| Command | What it does |
| --- | --- |
| `wisp lan setup --from INSTALL [--build BUILD] [--pairs N \| --pair K...]` | Creates the pool's clients from an existing Warcraft III install folder (the one holding `_retail_`): pairs 0..N-1, or only the pairs named, leaving clients other runners use alone. `--build` names the install's build when it isn't the pool build (3.0.0.24268); it must have a profile in `builds/`. See "Setting up". |
| `wisp lan pool [--pairs N \| --pair K...] [--pool-profile parity\|visual\|hfr[,...]] [--fps N] [--seconds S] [--network] [--queue] [--owner NAME] [--owner-pid PID] [--release-idle SECONDS]` | Runs up to N pairs, each admitted by the machine-capacity helper. `--network` with exactly one `--pair K` starts that pair with network and only its side a client, for solo games (see Guardrails). It stays in the foreground; Ctrl-C, SIGTERM or `lan stop` stops the pool: it stops each pair's agent, which stops its games, and waits for it before it closes the pair's capacity session. Closing that session stops its whole scope, desktop launchers included, and a desktop launcher SIGKILLs its agent through `bwrap --die-with-parent`, so an agent stopped any later leaves its games running (wisp#19, wisp#42). Each client runs in its own capacity scope, `agent-capacity-<lease>.scope`, named by the RESERVED line its wrapper printed into `pair-K/lanKs.err`; the pool stops both scopes by that exact name after the session closes, and again before it starts the pair, so a client whose wrapper died is still stopped. The agent stops its clients the same way and never signals a process by name, pid pattern or prefix. The pool holding a pair holds its `pair-K/pool.lock` and names itself in `pair-K/claim.json` (`pair`, `pid` and `start`, the fleet `session` from `NORTH_FLEET_SESSION`, the lane label `owner` from `--owner`, default the session, and the session's own process `agent`); it writes that file only after it takes the lock and removes it before it lets go. A pair another live pool holds is refused with that pool's PID and session. `--queue` waits in line instead: each waiter draws a ticket in `pair-K/queue/` from a counter only one waiter advances at a time, and only the first live ticket may take the lock, so waiters get the pair in the order they asked; a pool without `--queue` is refused while anyone waits (wisp#69). The session's own process is the outermost ancestor carrying the same `NORTH_FLEET_SESSION`, or `--owner-pid PID` for a pool started outside that process tree such as a systemd unit; once it exits, the pool, queued or running, stops itself, so no pool outlives the session that wanted it. A pool also lets go once its check ends, not when its session does: when every pair it runs shows `idleSeconds` of at least `--release-idle` (default 600) in `wisp lan status`, that is, no live driver and no game in progress for that long (see "Pool owner and drivers"), it stops them and frees this host's queue leases on them (see "Leasing a pair"). A pair whose agent doesn't answer counts as busy; `--release-idle 0` holds the pairs until the session ends (`checksEnded`, wisp:host/lan/pool.ts). |
| `wisp lan fresh MAP [--pair K] [--computers N] [--turn-ms MS[,MS...]]` | Hosts MAP on pair K, switches both clients to LAN, joins them, and returns once the match plays. It prints the game's action log. `--turn-ms` is one turn length (default 25, Battle.net's measured grid) or a repeating cycle: `--turn-ms 17,17,16` sends one turn per 1/60 s, so each turn carries exactly one 60 Hz callback. See [Turn pacing](#turn-pacing). |
| `wisp lan dummy MAP --program W3GSCLIENT [--pair K] [--count N]` | Joins side a to a lobby, then runs N dummy joins, handicap changes and leaves (default 20). The pair must have no active game. |
| `wisp lan solo MAP [--pair K...]` | Each client of the named running pairs (default: all) plays MAP alone, as a local game on the loopback provider; returns once every client's game UI is up. Works on 3.0.1. See "Solo games". |
| `wisp lan status [--pair K]` | Each pair's clients and processes, and its game: phase, turns, desyncs, players. |
| `wisp lan speed N --pair K` | Diagnostic turn delivery at 1–16 times real time; 1 restores normal delivery. Measure client frame progress to establish actual game speed. |
| `wisp lan netem --pair K --rtt MS [--loss PERCENT] [--jitter MS] [--burst] [--udp-port N \| --tcp-port N]`, `wisp lan netem off --pair K` | Adds round-trip delay, jitter and independent or bursty packet loss to pair K's loopback, or to UDP or TCP on one port of it, or removes it, and prints the loopback's queueing disciplines and filters. See "Simulated latency and loss". |
| `wisp lan end --pair K` | Ends pair K's game. The clients go back to their menus. |
| `wisp lan stop --pair K` | Stops the pool holding pair K (`pair-K/claim.json`), from any session, with SIGTERM, waits up to 90 s for it to exit, then stops each client's last capacity scope by its exact name and fails if one still runs. It refuses a pool that also holds other pairs, unless that pool's custodian (the claim's `agent`) has exited: such an orphaned pool is stopped whole (wisp#86). |
| `wisp lan check --pair K [--pool-profile parity\|visual\|hfr] [--wait SECONDS]` | The pair health check: starts pair K in line behind other pools (as `--queue`), and once both its fresh clients run, clears the pair's start failures and stops it, so the lease queue offers the pair again (see "Leasing a pair"). |

Pool clients are named `lan<K>a` and `lan<K>b`. The pool writes three files
under `$XDG_STATE_HOME/wisp/lan/` (default `~/.local/state/wisp/lan/`):

- `pool.json`: every pair a live pool holds, their agent sockets and desktops, whichever pool started them;
- `clients.json`: every pool client in the clients-file schema
  (`WISP_CLIENTS=~/.local/state/wisp/lan/clients.json`, or
  `client ... --clients-file ~/.local/state/wisp/lan/clients.json`);
- `pair-K/clients.json`: one pair's clients, named `a` and `b`, for tools
  written against two clients A and B;
- `alarms.log`: one line per pair whose driver died and left it idle for 10
  minutes (see "Pool owner and drivers").

`pair-K/<client>-menus.log` keeps every request that client's menus send, as
`wisp menus listen` prints them: the agent holds the clients' report ports.

Each game's files are under `pair-K/games/<time>/`: `actions.log` and
`packets.log` (every packet except empty turns, in hex).

## Pool owner and drivers

A pool belongs to the user who ran `wisp lan pool`: its state is under that
user's `$XDG_STATE_HOME`, its desktops under their `XDG_RUNTIME_DIR`, and
`pool.json` records them as `owner: { uid, user }`. Before any `wisp lan`
command runs, Wisp looks for pools with a live pair (one whose agent socket
exists) in its own state directory and in each account's default
`~/.local/state/wisp/lan/pool.json` it can read. When only another user's pool
is live, the command exits 1 and names the owner and the command to run
instead, for example as root:

```
the running LAN pool (/home/tom/.local/state/wisp/lan/pool.json) belongs to tom (uid 1000), and its state and agent sockets live under that user's home and runtime directory; run it as that user: sudo -u tom env HOME=/home/tom XDG_RUNTIME_DIR=/run/user/1000 bun /home/tom/game/scripts/game.ts lan status
```

The owner comes from `owner.uid`, or from the file's owner for a pool written
before Wisp recorded it, and the user name from `/etc/passwd`. A user who can't
read the owner's home sees no pool there and gets the ordinary "no pool"
answers.

`wisp lan fresh` and `wisp lan solo` make their caller the pair's driver: the
process that ran the command, past a `bun run` or `bun wisp` wrapper. `wisp
lan end` releases it, and the next `fresh` or `solo` replaces it. The pair
agent checks the driver every 5 seconds (`pollUntil`). Once it is gone without
`end`, `wisp lan status` shows the pair with `"idle": "idle since <time>,
driver gone"` beside `"driver": { pid, since, goneAt }`, and `agent.log` says
so. Ten minutes later the agent appends one line to
`$XDG_STATE_HOME/wisp/lan/alarms.log` (default
`~/.local/state/wisp/lan/alarms.log`) for the owner's tick to read:

```
2026-10-11T10:10:05.012Z pair 0: idle since 2026-10-11T10:00:03.981Z, driver gone (pid 4242) for 10 min without wisp lan end
```

Each driver raises the alarm once. The decision is `driverVerdict`
(wisp:host/lan/pool.ts).

Every pair's `wisp lan status` line also says whether it is idle and for how
long: `state` is `"dead"`, with the names in `down`, while a client has no
game process; `"busy"` while a driver is recorded and alive; otherwise
`"idle"`, with `"playing": true` while a game is counting down, loading or
playing. `idleSince` is the latest of the agent's start, the last `wisp lan
end` and the moment the driver was found gone; `idleSeconds` is the whole
seconds since `idleSince`, 0 only while a live driver holds the pair. A game
left playing by a driver that died, or a dead pair nobody drives, counts idle,
so its pool and lease let it go instead of holding it for a session that no
longer uses it (wisp#86). A pair released with `end` 17 minutes
ago reads, among its other fields:

```
{"pair":0,"profile":"parity","state":"idle","idleSince":"2026-10-11T10:00:03.981Z","idleSeconds":1020}
```

The calculation is `idleness`, beside `driverVerdict`.

## Dummy lobby checks

`wisp lan dummy MAP --program /path/to/w3gsclient --pair K` uses the
unmodified [GoWarcraft3 command](https://github.com/nielsAD/gowarcraft3/blob/f13251b6caed199c3347214f4591e7ccaa96c7c7/cmd/w3gsclient/main.go)
at revision `f13251b6caed199c3347214f4591e7ccaa96c7c7` as a separate program.
Build it in its own checkout with `CGO_ENABLED=0 go build -o w3gsclient
./cmd/w3gsclient`. It is MPL-2.0; Wisp neither copies nor distributes its
source or executable. Keep its licence with any copy you distribute and make
the corresponding source available under MPL-2.0.

The command enters the existing pair's loopback-only namespace and uses only
side a. The host stays in the lobby. Each new dummy process uses protocol
version 10200, answers the map and profile handshake, requests handicap 90,
receives the changed slot table, then leaves. Wisp resets its vacated slot.
The original command's peer dialing is disabled: these checks exercise the
host connection. The map must put its first human player in player slot 1.
The dummy acknowledges the advertised map size without reading or executing
the map; map-file validation, gameplay, checksums and peer connections still
need real clients.

Results go to `pair-K/dummy/<time>/`: packet and action logs, one log per
dummy, and `result.json` with each join time, CPU sample and resident memory.
The result also records the native build, setup milliseconds and a `passed`
or `failed` status. A failure preserves completed runs, the first failed step
and its error, including a refusal before the first W3GS packet. Keep that
folder private. On a client with a working LAN provider, these lobby checks
can replace the second native client for join/leave, profile/map-message
handling and handicap slot updates. The
pool still starts pairs; an executor may stop its unused side b to measure
the one-client footprint.

On 7 October 2026, the isolated protocol run completed 20 joins, handicap
changes and leaves with zero errors against Wisp's host. Median join time was
12.4 ms and resident memory was 5.5–5.9 MiB. A corrected CPU sample used
3.685 ms of CPU over 285.64 ms (0.0129 core), with 5.61 MiB resident memory.
The two-native baseline below used 1.26 cores and 2.17 GB resident memory;
the second client alone used 0.52 core and 0.80 GB. These are separate lobby
and match samples, not a measured one-native replacement speedup.

**3.0.1.24342 cannot join this host.** The first unsupported step is choosing
the native LAN provider, before a `ReqJoin` (W3GS packet `0x1e`) can be sent.
The 8 October native investigation rebuilt lan1a's provider and found only
`BNET` and `LOOP`; a different provider id returns unsupported result 4.
`TCPN` is absent. The private LAN plugin refuses this build before changing
the client. Consequently there are zero native-plus-dummy lobby joins on
this build, and no supported native setup time or resource comparison.
Changing the dummy's packet version cannot supply a missing native transport.
This is the measured incompatibility result for
[#46](https://github.com/tompassarelli/wisp/issues/46).

Wisp's host protocol checks can use simulated W3GS players for the two sides:
join/leave, map/profile replies and handicap changes already completed the
20-round check without Wine. Gameplay pairs run through Wisp's headless
clients; a W3GS dummy does not execute their map. Native reference captures
that need a real peer still use signed-in clients. Adding a native `TCPN`
provider or emulating Battle.net is outside this tool's scope.

## Guardrails

- **Offline LAN play only.** Before it writes into a client's code, Wisp checks that the
  client's `/proc/PID/net/dev` lists nothing but `lo`. Pool clients run inside
  `bwrap --unshare-net`, so Battle.net is out of reach, and no client has a
  saved account to sign in with. A client with any other network is refused.
- **Network for one solo pair, by request.** 3.0.1.24371 hangs before its
  window opens when it starts without network (0 of 10 launches started on
  22 October 2026). Network is needed but not enough: with it, lan16a started
  6 of 6 times (window in 12 s, intro playing) while lan16b started 1 of 6,
  alone or as side b, also on a copy of lan16a's prefix; the cause is open.
  `wisp lan pool --pair K --network` starts that one pair's agent outside the
  loopback-only namespace and launches only its side a client (`pairSides`,
  wisp:host/lan/pool.ts): no side b desktop or game, so `lan status`, `lan
  solo` and the clients files list one client. It is for `lan solo` only: it
  requires exactly one `--pair K`, every other pair stays offline, and the
  networked pair refuses `lan fresh`, `lan dummy` and `lan netem`
  (`lanPlayRefusal`). Its client still never signs in.
- **Relaunch on a startup hang.** In one unchanged context lan16a started 7
  of 10 times, opening its window 2-3 s after launch, and hung 3 of 10 times
  with no window (22 October 2026). The agent waits `WINDOW_DEADLINE` (30 s)
  for each client's `Warcraft III` window, then stops that game and launches
  it again, at most `WINDOW_RELAUNCHES` (3) times (`launchUntilShown`,
  wisp:host/lan/pool.ts); the pair fails if the fourth launch shows no
  window either. Every stop of a client, a relaunch's or the pool's
  (`stopGame`, wisp:host/lan/pool.ts), sends its native capacity session
  SIGTERM and, if the session or its game still runs `STOP_GRACE` (10 s)
  later, SIGKILLs both and says so in the agent log, so a client hung before
  its window no longer outlives the pool's stop. Without xdotool, or when xdotool can't reach the
  desktop's display, the agent cannot see windows and keeps the launch it has.
- **A toplevel on the client's own compositor.** An X window is not enough:
  focusing the game for input and capture asks the client's compositor for
  its `Warcraft III` toplevel (`wlrctl toplevel focus`), and pair 14 client b
  (25 October 2026) and pair 12 client b (26 October) came up with a
  connected game but no toplevel, so every pad on them failed at
  `focus Warcraft`. Before it serves its socket, the agent waits up to
  `TOPLEVEL_DEADLINE` (20 s) for each client's compositor to list that
  toplevel (`wlrctl toplevel find`); a client without one is restarted once,
  and the pair fails with `confirm Warcraft toplevel after one restart
  failed for lanKs: the compositor lists no Warcraft III toplevel` if the
  restart lists none either (`confirmToplevel`, wisp:host/lan/pool.ts). When
  wlrctl can't ask the compositor, the agent says so and keeps the launch.
  A strict `focus` that finds no toplevel fails with a `ToplevelMissing`
  cause (`toplevelMissing` in wisp:host/os/warcraft/desktopClient.ts tells
  it apart), which a pad batch counts as INVALID and reruns under
  `--retries`.
- **Ready after the intro.** A fresh 3.0.1 client plays its intro cinematic
  for about 2.5 minutes over whatever runs underneath: a solo game started
  during it played and ended unseen, and every capture frame showed the
  cinematic (22 October 2026). The client reports `LOGIN_DOORS` when the
  intro ends (151 s after the pool started, the doors on screen). The agent
  counts a client as ready only once it has reported `LOGIN_DOORS`
  (`reachedMenus`, wisp:host/lan/pool.ts), waiting at most `MENUS_DEADLINE`
  (5 minutes) and then going on, so `lan pool` reports a pair running after
  its intros. Its menu listeners start before the games launch, so a 3.0.0
  client, which reaches its doors within seconds, is never missed; a client
  that never loads Wisp's menu page costs the whole 5 minutes.
- **Declared clients only.** `wisp lan` works on the clients it created. `wisp
  engine actions` accepts only a pair from the pool's clients file.
- **Checked builds only.** The switch (Wisp's private LAN plugin) refuses
  builds it hasn't been checked on (3.0.0.24268), logs each change, and puts
  the client back within a fraction of a second.

## Setting up

Running `setup` again refreshes an existing client's install when its Warcraft
executable differs (size or modification time) from `--from` or its `Data/`
holds a different file list, deletes the files in the client's own `Data/`
that the source lacks, then reinstalls that client's menu page. A client
moved between builds otherwise keeps the old build's `.idx` and config
files, and the game reports that its data must be repaired (wisp#26). Stop
the pool first, and use an install whose update has finished.


`wisp lan setup --from "<a prefix>/drive_c/Program Files (x86)/Warcraft III" --pairs N`
makes, for each client:

- a fresh GE-Proton prefix under `$XDG_DATA_HOME/wisp/lan/clients/<name>/`
  (default `~/.local/share/wisp/lan/clients/<name>/`), created inside a network
  namespace with nothing but loopback. It holds no Battle.net and no account.
  Its only setting is `HKCU\Software\Blizzard Entertainment\Warcraft III` →
  `Allow Local Files` = 1, which the menu page needs. Setup sets it again on
  an existing prefix whose `user.reg` lacks it: without it the client sits at
  its error modal, its menu page never reports, and `lan fresh` fails with
  "no menu page reported";
- a reflinked copy of the install (`cp --reflink=always`). On btrfs or xfs a
  33 GB install costs no space until a file in it changes. Where the
  filesystem can't clone (ext4, tmpfs), setup copies every entry outside
  `Data/` (about 0.3 GB) and hardlinks `Data/` to the source's files but for
  the game's `shmem` files, which each client keeps its own
  ([shared game storage](client.md#shared-game-storage)). A refresh always
  takes this path, relinking a changed `Data/` file instead of writing into it;
- Wisp's menu page ([driving-warcraft.md](driving-warcraft.md#1-the-menu-socket-recommended)),
  reporting to the client's own port (47200 + 2K for side a, 47201 + 2K for side b).

The source install must have been started once through Battle.net. Setup
reads it and never changes it. Setup refuses, before copying anything, a
source whose `.build.info` names another build than the pool's
(3.0.0.24268), and names both builds. A signed-in clone is a valid source
only while it is on the pool build; once Battle.net updates it, set up from
a copy taken while it was on the pool build.


### Disk use of the client copies

Measured on gex45 on 29 October 2026 (155 GB under `~/.local/share/wisp`, 22 GB free): the 27 LAN clients share one `Data/`, and a byte comparison of every `Data/` file of 1 MiB or more across the LAN clients, `online/clone-*` and `classic-24371` found nothing more that `client share` could link. The online clones and `classic-24371` (build 24371) hold same-named, same-sized `data.0NN` archives that differ in content (`data.001` in clone-b against classic differs in 661,072 bytes), because Battle.net patches CASC archives in place and each copy drifted with its own `.idx` files. Outside `Data/`, same-sized files that may match come to at most about 14 GB among the LAN clients (`_retail_` executables and DLLs, Wine prefix files) and 5 GB among the online clones; none is linked, because a `lan setup` refresh writes through shared files outside `Data/`. Revisit linking `_retail_` only if gex45 falls under the 15 GiB free floor.
## Running a pool

Each client has its own private desktop (the private-desktop-development
launcher), so each display has exactly one game window, as on clients A and
B. Tools that find "the" Warcraft window on a display work unchanged, and so
do controller helpers that type into it. A pair's session
(wisp:host/lan/pairSession.ts) starts client b's desktop, then client
a's. Client a's desktop runs the pair's `bwrap --dev-bind / / --unshare-net`
namespace (none for a `--network` pair, which also has no side b), and the pair agent (wisp:host/lan/pairAgent.ts) runs inside
it. The agent:

- writes each client's `War3Preferences.txt` for the profile;
- launches both games with `-launch -windowmode windowed -nowfpause`, through
  steam-run, Steam Linux Runtime 4 and GE-Proton 11-7, as the signed-in
  clients run, and relaunches a game that shows no window in time (see
  Guardrails). Both share the namespace, and client b draws on its own
  desktop;
- sets each window to the profile's size at its desktop's top left. The game
  can open a window larger than its settings ask;
- plays each client's sound into its own silent sink, `wisp-lan-<name>`, on
  the user's PipeWire (a null sink the agent creates, `PULSE_SINK` at launch).
  The owner's speakers stay quiet, and `pw-record --target wisp-lan-lan0a.monitor
  OUT.wav` records exactly that client's audio. Without the user's PipeWire
  pulse socket the clients run without sound;
- answers on `pair-K/agent.sock`. A Unix socket reaches across network
  namespaces, so `wisp lan fresh` and `status` talk to it from outside.

Each pair's desktops and agent run in one `machine-capacity session --class
native --memory-gib 1`. A game waits on its desktop's Xwayland, and in the
low-weight batch slice a busy machine starved the desktops until 3.0.1 games
hung before opening a window. Admission uses the user's service bus and runtime directory;
inside the scope the game receives its private desktop's runtime directory
and its own session bus. Each game runs in its own `session --class native` scope: the
high-weight slice for game clients, with no CPU quota. Each offline client
requests 1.5 GiB through `--memory-gib`; measured
parity clients used 0.8–1.4 GB resident memory. This sizes admission and
`MemoryHigh` while keeping the native class's CPU treatment. The pool adds
pairs while the helper admits them, in present and away mode. Each pair's
session declares both of its clients (`--new-clients 2`, or 1 for a
`--network` pair), so a pair is never half-started and torn down when the
host has room for only one more client (smashcraft#585). It passes
`--wait-seconds` (`--wait`, default 1800) and waits in the helper's
arrival-order native queue, so a later pair, client launch or GPU job cannot
take the slot it waits for; the pool prints each new reason the helper gives
for holding it. Retrying a deferral every 45 s instead lost pair 0 two full
windows to later pairs on gex45 on 26 October 2026 (wisp#76). If the helper
still defers it after those seconds, the pool keeps its admitted pairs and
lists the remaining pair numbers as waiting. The agent stops its games when
it is stopped, or when its pair's session ends.

- `--pair K` (repeated) picks which pairs start, in that order of admission.
- If the helper defers either game's native scope, the pair agent stops any
  game already started for that pair and the pair fails.
  Direct pair-session and agent entry points require the capacity helper too.
- Several pools may run at once, each on its own pairs (one per agent). Each
  pool writes its pair's entry to `pair-K/pair.json` and rebuilds `pool.json`
  and `clients.json` from the entries of every pair whose `claim.json` holder
  lives, on start and on stop, writing again until a fresh scan matches. So
  starting pair 5 never unlists pair 3, and a stopped pair leaves the list
  even though its agent socket file stays behind.
- `--profile` takes one profile, or one per pair separated by commas; the last
  one repeats.

`pair-K/clients.json` gives each client its own `run` (desktop) and `pid`.

**Why a desktop per client.** labwc opens every game window at the same
place, and Xwayland throttles a window another window covers. On 7 October,
both clients of a pair shared one desktop. The covered client loaded 70 s
after the other, then ran 51 turns behind, so the host kept pausing the game.
With the windows apart, both kept within a few turns at 1:1 game time. Two
controller helpers typing on one display would also take each other's focus.

**Profiles** (wisp:host/os/warcraft/clientProfiles.ts `PROFILES`). Each one writes the
client's War3Preferences `[Video]`, `[Misc]` and `[Sound]` at launch:

- `parity` (the default) is for checksum and input runs, which need no pixels
  and no sound. It has an 800×600 window, every quality setting at its
  lowest, classic models and textures (`hd=0`), and sound off.
- `checks` is parity with sound effects (music off), for checks that record a client's audio.
- `visual` is 1280×720, with more lighting and texture detail, in Classic.
- `hfr` is parity at 144 frames a second, for comparing the game's clocks
  against the 60 fps cap.
- `capture-classic` uses a 1280×720 window at 60 fps with high lighting,
  shadows, point-light shadows and water, medium textures, and ambient
  occlusion enabled. Sound effects are on and music is off, so the same
  profile can record effect audio. Pool metadata records the selected
  profile. Retain that metadata and the saved preferences with captures.
- `capture-classic-1080` is `capture-classic` in a 1920×1080 window, the
  resolution native silhouette captures compare at (wisp#2).

A profile's size is the game's client area. The window is 4 px wider and
taller, because Wine draws a 2 px frame on each side, so a pool client's game
pixels start at (2,2) of its window (`windowSize`). On 24 October 2026 a
1920×1080 window left the game 1916×1076; the 1924×1084 window gives exactly
1920×1080.

**The pool draws only Classic.** Its clients never sign in, and an unsigned
client draws Classic models whatever `[Misc] hd` says. On 9 October 2026
(3.0.0.24268) a Rifleman stand frame on lan0a at `hd=0` and at `hd=2` differed
in 5 of 16,800 pixels, and still did with `settingsversion=3` and
`mostRecentlySeenGraphicsMode=2` added. Reforged checks run on signed-in clones b, c and d
with the `capture-reforged` clients file profile
([doctor.md](doctor.md#graphics-profiles)), set before launch.

Warcraft **3.0.1.24342**'s installed `webui/GlueManager.js` maps
`PREF_GENERAL_HD` to SD=0 and HD=1; the saved preferences store that
choice as `[Misc] hd`. The pool profiles all write Classic (`hd=0`); a signed-in client's `visual`
writes Reforged (`hd=1`). Audio checks therefore use Classic
sounds. The capture profiles set Ambient Occlusion on (`assao=1`); the other profiles set it off (`assao=0`). All omit
`bloom`, `portraitBloom`, `particles` and `spellfilter`. Smashcraft play explicitly chooses Reforged (`hd=1`) and Ambient Occlusion off too.

The others cap the game at 60 frames a second, focused or not. A cap below
the turn rate (40 turns a second at 25 ms) is untested.

`wisp lan pool --pair K --pool-profile parity --fps N` overrides both
foreground and background caps while holding the profile's resolution,
quality, model set and sound fixed. The agent status and metadata record the
effective cap. Use one active script and map revision for both caps, measuring
per-client CPU and DRM GPU-engine time over the same interval, alongside
protected CPU pressure. Keep the cap only when the same script passes parity
and game time keeps pace with wall time; reduced rendering can delay input
even when the LAN turn rate is lower than the cap. A different cap applies
when that pair starts, through the normal capacity admission path.

**Cost at parity** (7 October, two clients in a match on Smashcraft
bisect-588610b7, measured over 10 s from /proc):

| | lan0a | lan0b |
| --- | --- | --- |
| CPU | 0.74 core | 0.52 core |
| Resident memory | 1.37 GB | 0.80 GB |
| GPU memory (VRAM + GTT, from DRM fdinfo) | 666 + 75 MiB | 666 + 75 MiB |

The two game processes therefore used **1.26 cores per pair** at the parity
profile's 60 fps cap. On 8 October, parity solo games used 1.07 and 0.97
cores, **2.04 cores for the two games** (see "Solo games"). These samples
measure game processes, not the desktop, Wine server or launcher. The
7 October 22:39 pool sample in [#37](https://github.com/tompassarelli/wisp/issues/37)
separately measured about 0.88 core per game, 0.38 per browser renderer and
0.34 per Wine server under heavy contention; it did not separate profiles.

### Pool cost per profile and the browser

Offline pool launch on 3.0.0.24268 runs `Warcraft III.exe` directly, without
the Battle.net launcher. The game still starts its own `BlizzardBrowser.exe`
(CEF), because its menus are web pages: the pool drives the game through
Wisp's menu page, which that browser renders.

**Measured 9 October 2026** (3.0.0.24268, editor-free sample map started by
`lan fresh`, every pair playing at speed 1 with 0 desyncs). Each 10 s sample
read `/proc` utime + stime of every process whose `WINEPREFIX` is the
client's, inside an exclusive machine-capacity lease; signed-in clone-c,
owned by another worker, was also running. Cores, per client a / b:

| Profile | fps cap | Game | Browser processes (renderers) | Browser | Client total with browser | Client total without browser | Pair with | Pair without |
| --- | ---: | ---: | ---: | ---: | ---: | ---: | ---: | ---: |
| `parity` | 60 | 1.19 / 1.33 | 5 / 5 (2 / 2) | 0.16 / 0.14 | 1.59 / 1.72 | 1.43 / 1.59 | 3.31 | 3.02 |
| `checks` | 60 | 1.24 / 1.29 | 5 / 5 (2 / 2) | 0.14 / 0.15 | 1.63 / 1.69 | 1.48 / 1.54 | 3.31 | 3.02 |
| `visual` | 60 | 0.68 / 0.56 | 8 / 8 (4 / 4) | 0.20 / 0.20 | 1.22 / 1.08 | 1.02 / 0.88 | 2.30 | 1.90 |
| `hfr` | 144 | 0.65 / 0.81 | 8 / 8 (4 / 4) | 0.47 / 1.34 | 1.51 / 2.77 | 1.04 / 1.43 | 4.28 | 2.47 |
| `capture-classic` | 60 | 1.00 / 1.01 | 4 / 4 (2 / 2) | 0.22 / 0.21 | 1.49 / 1.50 | 1.27 / 1.29 | 3.00 | 2.56 |

"Without browser" is the same sample less the client's browser processes;
the rest is the game, its Wine server (0.11–0.31) and other Wine processes
(0.13–0.31). System CPU pressure (some avg10) was 22–24% for `parity` and
`checks`, 36% for `visual` and `hfr` and 35% for `capture-classic`, so compare
profiles within one row's conditions. `hfr`'s browser cost rises with its
144 fps cap: 0.47 and 1.34 cores, against 0.14–0.22 at 60 fps.

**Pool clients cannot run with 0 browser processes.** In the two-pair
`parity`/`checks` run, all four clients at the menu and in the match had
5 `BlizzardBrowser.exe` processes each, 2 of them renderers: 8 renderers,
20 browser processes. Killing all 10 browser processes of pair 1 mid-match
left the match playing (0 desyncs), but each game restarted its browser
within 10 s, again 5 processes with 2 renderers. The menu page that
`lan fresh` and the return to menus drive runs in that browser, so
the pool keeps it; its cost at 60 fps is 0.14–0.22 core per client, 0.29–0.43
per pair.

**Admission with real clients.** `wisp lan pool --pairs 4 --wait 60 --pool-profile
parity,checks,visual,hfr` with clone-c's two native leases already held
started pairs 0 and 1, then the helper deferred pair 2's second game
(`DEFER_NATIVE_CPUS`, 22 of 20 native CPUs in the attended profile; once
protected CPU pressure was 23.75%). After 60 s the pool printed "the pool
stays at 2 pairs; waiting: 2, 3" and kept both admitted pairs running.

Earlier read-only samples of signed-in clones (9 October, 10.020 s, no pool
clients) found 5 browser processes per clone, 2 of them renderers:

| Client | Game CPU (cores) | Browser renderers | Renderer CPU (cores) | Other browser CPU (cores) | Wine server CPU (cores) |
| --- | ---: | ---: | ---: | ---: | ---: |
| clone-b | 0.331 | 2 | 0.358 | 0.359 | 0.148 |
| clone-c | 0.805 | 2 | 0.344 | 0.355 | 0.140 |
| clone-d | 0.309 | 2 | 0.358 | 0.383 | 0.135 |

A signed-in clone's Battle.net browser costs 0.70–0.74 core, about four times
a pool client's at 60 fps.

**Rendering is on the GPU.** Pool clients render through DXVK (`d3d11=n`,
`dxgi=n` in Proton's `WINEDLLOVERRIDES`) on RADV. The Vulkan loader maps every
ICD it is offered, so lavapipe (`libvulkan_lvp.so`) and `libLLVM` appear in
`/proc/PID/maps`, but that is enumeration, not use: on 7 October every pool
client held 540–670 MiB of VRAM and accumulated `drm-engine-gfx` time on the
AMD device (0000:c1:00.0) in its DRM fdinfo. Forcing the Radeon ICD cannot cut
CPU; the CPU is spent in the game's own threads.

**A spinning client costs three times a normal one.** Measured from
`/proc/PID/task/*/stat` over 10 s with the machine at load ~140 on 24 cores,
nine pool clients used 0.29–0.82 core each, their busiest thread sleeping
thousands of times (voluntary context switches). Two clients (lan3a in a
parity pair, lan1a) used 1.97 and 2.29 cores: three threads each at 60–80% of
a core with zero voluntary context switches, so they never block and spin in
user space. Check `voluntary_ctxt_switches` in each thread's `status` before
blaming settings: such a client is the one to stop or restart.

## How a match starts

`wisp lan fresh MAP --pair K` asks the pair agent for a game. The agent:

1. copies MAP into each client's `Documents/Warcraft III/Maps/Wisp/`. The
   agent keeps at most one copy it made per client, the newest: each
   `fresh` or `solo` first removes the copy it made for the previous map,
   and the agent's scope removes the last one when the pair stops (`lan end`,
   the pair session ending, or the agent failing), so a failed run leaves no
   copy behind ([mapCopies](../host/lan/map.ts),
   wisp:host/lan/map.ts; `lan dummy` removes its copy when its run
   ends). It removes only paths it created: a file of the same name that was
   there first is replaced and stays. The agent lists its copies in the
   pair's `map-copies` file (`lan dummy` in `dummy-map-copies`), so when a
   killed agent (SIGKILL), which runs no finalizer, left one, the pair's next
   agent removes it as it starts;
2. reads the map's facts (map.ts): its size, CRC32 and SHA-1, the xoro
   checksum of its game files (Flo's, plus `war3map.w3l` after `war3map.w3q`
   on 3.0.0.24268), its playable size, and its players and forces from
   `war3map.w3i`;
3. starts the host (host.ts) on a free TCP port and announces the game every
   second to UDP 16000–16007. Each client takes the first free port from 16000
   for its LAN socket, and the game's own search goes to 16000 (held by the
   first client), so the host announces to the clients instead of answering
   searches. Discovery closes when countdown starts. An unused announcement
   port can leave Bun 1.3.13 spending nearly one core on the UDP socket even
   after announcements stop. A two-second isolated sample used 1.66 CPU-seconds
   with that socket open and 0.003 after closing it; gameplay needs only TCP;
4. for each client, switches its provider to LAN (below), then sends its
   menus `SendGameListing` and `GetGameList` until the game is listed, then
   `JoinGame` with the listed id;
5. runs the lobby. Each join gets its slot table, the other players' info,
   skins and profiles, and the map check. A client answers with its map's size
   (0 means it has no matching map). Once every client has the map, the host
   sends the countdown, 6 s apart (shorter makes slow clients quit), and
   waits until every client has loaded.

The join burst and the game loop follow W3Champions' Flo
(github.com/BogdanW3/W3C-Flo, MPL-2.0) and the protocol notes of
wc3-slop-lan (github.com/Promises/wc3-slop-lan, no licence: read for facts
only). Wisp's code is its own; no file of either is copied.

### The switch to LAN

Patch 3.0.0 left the LAN provider in the game, but the menus only ever ask for
the loopback one. Before each join, the agent briefly switches the client to
the LAN provider and puts it back within a fraction of a second. That code reads
and patches the running game, so it isn't in this repository
(wisp:docs/clean-room.md): Wisp loads it from Wisp's private LAN plugin at
`~/.local/share/wisp-private/lan/` (wisp:host/lan/plugin.ts) when
the owner has it. Without the plugin, `wisp lan pool` stops and says the plugin
is missing.

## The action log

### Turn pacing

The host sends turn n when the wall clock reaches the sum of the first n
steps of the `--turn-ms` cycle divided by the speed (wisp:host/lan/host.ts,
`pacedTurns`), and gives that turn the step the pacer handed it as its game
time, so the deadline keeps every fraction of a millisecond a speed leaves and
summed game time never drops a remainder. Each turn waits for an
absolute deadline, so a late wake shortens the next wait instead of shifting
every later turn, and game time stays on wall time. Effect 4.0.3's
`Schedule.fixed` is not used for turns: with a fractional period such as
16.6667 ms it fired 107 times a second instead of 60 (24 October 2026), and
the game ran at 1.54 times wall speed. wisp:test/lanPacing.test.ts drives the pacer on a
virtual clock whose wakes run late by up to 0.9 of a turn, for 25, 30 and
17/17/16 cycles at speeds 1 to 16, and checks that every turn goes out within
one wake of the wall time its summed game milliseconds reach.

Measured on 24 October 2026 (Smashcraft integrity build, 3.0.0.24268, LAN
pair 0), the default ran 39.94 turns a second of exactly 25 ms at game pace
0.998, and `--turn-ms 17,17,16` ran 60.00 turns a second at game pace 1.000
with one callback per turn, light and heavy input alike, with no desync
(smashcraft:docs/warcraft-api-netcode-findings.md, "Input sampling against the
LAN host's turn interval").

### Faster turn delivery

`wisp lan speed 4 --pair K` asks the existing host to deliver four game-time
turns in the wall time normally used for one. Accelerated packets retain the
configured `turn-ms` game-time step. `wisp lan speed 1 --pair K` restores
normal delivery. The action log records every speed change, and status
reports the requested `speed`. The host still waits when a client falls more
than 50 turns behind and compares all returned checksums.

This is an experiment control, not a measured native fast mode. Host
`gameSeconds` measures delivered time; compare the map driver's frame progress
against wall time to find the speed the clients actually sustain. Rendering
is unchanged. A full parity run needs separate measurements with rendering
suppressed before `pad --fast` can be offered.

FLO's observer send queue uses the same protocol fact: speed changes packet
delivery delay, not the game-time increment encoded in each packet
([source at 6db3a401](https://github.com/BogdanW3/W3C-Flo/blob/6db3a4010fab0b0b29824a61f2c9c956f97fd211/crates/client/src/observer/send_queue.rs)).
Wisp's implementation changes its existing timer; no FLO code is copied.

### Simulated latency and loss

A pair's clients and host talk only over the loopback of the pair's own
network namespace, so `wisp lan netem --pair K --rtt 60 --loss 1` puts a
Linux `netem` queueing discipline on that loopback
(wisp:host/lan/netem.ts builds the `tc` command lines). Every loopback send
is delayed once, so each send waits half the round trip (30 ms here).
`--loss` is the round trip's loss: each send is dropped with
1 − √(1 − loss), about 0.5% here, so a request and its answer together are
lost 1% of the time.

- `--jitter MS` varies each send's delay uniformly by half of MS, so the
  round trip varies by up to MS around `--rtt`. Netem then delivers packets
  out of order, as the internet sometimes does. MS may not exceed `--rtt`.
- `--burst` makes the loss bursty with netem's two-state Gilbert model
  (`loss gemodel p r 100% 0%`): a send in the good state always arrives, one
  in the bad state is always lost, the bad state is left with
  probability r = 25% (a mean burst of four sends) and entered with
  p = l·r / (100 − l), so the long-run per-send loss l is the same as
  without `--burst`. The command prints p, r and l.
- `--udp-port N` impairs only UDP to or from port N, and `--tcp-port N`
  only TCP: a two-band `prio` root sends every packet to its plain first
  band, and two `u32` filters (IPv4, protocol 17 or 6, destination or
  source port N) send that port's packets to the second band, where the
  netem sits. Without a port, netem also delays and drops each client's own
  loopback connections: Wine's internal socket pairs, Warcraft's link to
  its browser process and its menu socket. On 24 October 2026 a client
  crashed 2 s after 5% loss went on that way, so put an internet path on
  the game's own connection only: `--tcp-port` with the port `lan fresh`
  hosts on (the action log's first line, `on 127.0.0.1:PORT`) for Wisp's
  TCP host, `--udp-port` for a UDP relay.

Each run first removes the loopback's root queueing discipline and then adds
the new setting, so running it again replaces it; `wisp lan netem off --pair
K` removes it. The pair keeps it until it is removed or the pair stops. The
command prints `tc qdisc show`, and with a port also `tc filter show`.

The namespace belongs to the pair agent's user namespace (bwrap
`--unshare-net`), so Wisp enters both with `nsenter --user --net
--preserve-credentials --keep-caps`, which keeps the user namespace's
`CAP_NET_ADMIN` for `tc`. No root or host network change is needed.

### Reading the log

`wisp client watch` observes each declared pool client through its host's Unix
socket, since the client's menu socket is inside the isolated network.
Typing a developer command requires the host to report that exact running
process as loaded, connected and playing. Lobby, loading, ended and stale
process observations permit no chat. Helpers use the client's Steam window
ID (`steam_app_3516115600` and up) to verify private-desktop focus.

Every `turn-ms` (25 by default, the turn period measured on Battle.net-hosted games) the host sends each client the actions
collected since the last turn (IncomingAction, with a CRC16). Each client
answers every turn with a checksum of its game state (OutgoingKeepAlive). The
host compares the Nth answer of every client, and holds the game while a
client is more than 50 turns behind. `actions.log` starts with a `#` header
that names its start time, then one line per event, in seconds since then:

```
8.358 join lan0a p1 as "" from 127.0.0.1:34084
9.370 map lan0a has it
12.917 phase countdown
99.869 phase playing
100.834 mark turn 32 game 0.965 behind lan0a=1 lan0b=2
104.347 turn 59 lan0a p1 sync prefix="SC_FE" bytes=0 data=""
256.536 chat lan0b p2 "-dev quick"
256.548 turn 4468 lan0b p2 chat trigger=10a3:10a3 text="-dev quick"
256.548 turn 4468 lan0b p2 key object=cbe:cbe event=525113 key=13 meta=0
...  desync turn 100 lan0a=00000001 lan0b=00000002
```

- **Action lines** (actions.ts) carry the turn, the client and its player
  slot, then the action. The kinds are `order` (with its order id, unit and
  target), `select`, `group`, `sync` (BlzSendSyncData, action 0x77: prefix,
  length, data), `chat` (the map's chat event, 0x60), `key` and `frame`
  events, `cache` stores, `pause` and `speed`. An unknown action id ends that
  player's block with a `raw` line in hex.
- **A mark line** about every second pins the turn count to the time, so other
  logs align between actions. It ends with each connected client's turns
  behind: turns sent minus checksums returned. A Warcraft client stops when
  its turns stop, so this lag, not the map's frame-based lateness, shows a
  stall.
- **Event lines** cover joins, map checks, phases, loads, leaves (with their
  reason), chat, and every desync, with each client's checksum.

Tests replay a recorded exchange of two offline clients through the host
(wisp:test/fixtures/lan/offline-pair.packets, wisp:test/lan.test.ts).

## Leasing a pair

Workers that need a native client pair ask one queue for it instead of naming
a pair: `lan lease take --owner NAME [--wait SECONDS] [--hosts local|any]`
prints `{"host":H,"pair":K}` for the next free pair, and `lan lease release
--host H --pair K` or the requester's death frees it
([queue](../host/lan/pairQueue.ts), [command](../host/commands/lanQueue.ts);
wisp:host/lan/pairQueue.ts, wisp:host/commands/lanQueue.ts). Requests are served
in arrival order. A pair is free when it has no live lease and no `lan pool
--pair K` started outside the queue holds it. A pair a `lan pool` of the
requester's own fleet session holds (its `claim.json` `session` equals the
requester's `NORTH_FLEET_SESSION`) is free to that requester and offered before
any other, even with the host at its client cap, since it adds no clients; any
other session still waits for it (wisp#85). This host's pairs (every
`lanKa` install `lan setup` made) come before another host's. `--hosts any` adds
the pairs `$WISP_PAIR_REMOTE` lists (`laptop=0,1`) while `north laptop status` says
available. `lan lease status` prints the waiting count, the leases and the free
pairs. A lease also ends when the `lan pool` running its pair lets the pair go
because its checks ended (`--release-idle`, above), so a lane holds a pair for
its native check or capture batch, not its whole session (wisp#83). A pair
whose pool failed twice in a row to start a game (the agent's `fresh`, `solo`
or `relayed` failed) or to bring its clients up (its session exited, or its
clients weren't both running within 10 minutes of admission) is unhealthy:
`pair-K/health.json` counts the failures and keeps the last problem, `lease
take` skips the pair, and `lease status` lists every pair under `health`
with `healthy`, `failures` and `problem`. A capacity deferral is the host's,
not the pair's, and counts nothing. A started game or a passing `wisp lan
check --pair K` clears the count (wisp#86; wisp:host/lan/pairHealth.ts). A
live pool whose custodian has exited holds its pair for nobody: the queue
offers the pair, and the `lease take` that is granted it stops that pool. A
pool client's own launch waits up to 480 s in the capacity helper's queue, so
a client slot another start took between the pair's admission and the
client's launch delays the pool instead of failing it. A host that sets a Warcraft client cap in orchestration.toml (`north capacity warcraft-limit`, read over ssh for another host) is offered only while its pairs leased or held in a pool of their own come to at most half that cap. The queue lives in `~/.local/state/wisp/lan/queue` and serializes only
the choice of a pair; leased pairs run concurrently. A lease on a pair whose agent has measured it idle (no game playing, no live driver) for five minutes, bounded by the lease's own age, is released by the next `lease take` that finds no free pair or by `lease status`; the line naming the lease's holder goes to stderr and to `queue/released.log`. A lease on a pair with no agent counts as idle from the moment it was taken, and a pair whose state cannot be read keeps its lease.
