# Network and timing model

Two parts: Wisp's own [transport](#wisps-transport), which carries a match
between processes, and the [latency model](#what-it-models) that gives
headless clients in one process Warcraft's measured sync delays.

By default the [headless runtime](headless.md) delivers a synchronized
message before the frame after the one that sent it. Warcraft delivers it
several frames later. `syncDelivery()` (wisp:src/headless/syncChannel.ts)
gives headless clients the latency Smashcraft's native traces measured, so a
map's rollback, prediction and timeout logic meets realistic delays in a
second-long run.

```ts
import { MEASURED_BATTLE_NET, syncDelivery } from "wisp/src/headless/syncChannel";

const clients = headless.clients(entry, [0, 1], { delivery: syncDelivery(MEASURED_BATTLE_NET, 7) });
```

A `Lockstep` takes the same object as its `delivery` option. The seed makes
a run repeat exactly; change it to sample other delays.

## What it models

| Part | Model | Measured |
| --- | --- | --- |
| Callback cadence | Every client runs its timer callbacks 60 times a game second, at the same game times; with `turnBursts()`, in wall-time bursts of one or two per 25 ms turn ([Turn-burst callbacks](#turn-burst-callbacks)). | 16.66 game-ms between callbacks, identical on both clients, across every callback of #26 r7 and r8. |
| Turns | A message reaches every client at the same synchronized turn; turns are 25 game-ms apart. | Echo times fall on a 24.87–24.99 ms grid. |
| Latency | 80 ms after the send, rounded up to the next turn, plus 0, 1, 2, … further turns with probabilities 0.4, then each 0.6 of the one before (the ninth bucket holds the rest). | Own-echo ages p10/p25/p50/p75/p90/p95 86/95/115/137/194/212 ms; the model gives 83/92/117/150/192/225. |
| Order | Each sender's messages arrive in the order it sent them; arrivals land before that frame's callbacks. | |

The latency is fitted to the 765 own echoes of both clients 1.5–9.5 s into
the first match of Smashcraft's #26 runs r7 and r8 (Smashcraft 0.0.42,
5 October 2026, two clients on one host, before any backlog;
smashcraft:evidence/input-integrity-0042-r7-20261005/ and -r8-). Chat and key
events still arrive at once.

Bun and the emitted 32-bit Lua give the same arrival frames for the same
send frames (wisp#71). Both models count time in whole thirds of a
millisecond, in which a 60 Hz frame is exactly 50, and pick the extra turns
by comparing the generator's whole-number state with whole-number bounds, so
no step rounds differently in binary32. A `SyncLatency`'s `latencyMs` and
`turnMs`, and a `TurnBurstModel`'s `turnMs`, must therefore be whole thirds
of a millisecond; the measured models are whole milliseconds.
test/sync-delivery71/schedule.ts runs a fixed 120-message schedule through
`syncDelivery(MEASURED_BATTLE_NET)` and `turnBursts()`, and
test/lua32-fixtures.test.ts checks its rows match in both runtimes.

Hosting: r7 and r8 ran as a Battle.net Custom Game (`[TEST] sc-integrity-r7`/`-r8`,
created on signed-in client A and found by client B through the Custom Games
search), not on a LAN, so the fit describes Battle.net-hosted turns. Offline
pool games are relayed by Wisp's own LAN host, whose turn period is
`lan fresh --turn-ms` (default 25 ms, matching the Battle.net grid above) or a repeating cycle such as `--turn-ms 17,17,16`; their echo ages are not yet measured.

## Turn-burst callbacks

Warcraft runs a turn's callbacks together when the turn arrives, so on
Battle.net the 60 Hz callbacks come in wall-time bursts of one or two,
about 40 a second. `turnBursts()` gives a `Lockstep` (its `callbacks`
option) that wall clock: each client's `os.clock()` reads the wall time of
the turn its callback belongs to, and a synchronized message lands on the
first callback of a turn, never between two callbacks of one burst.
The timing's `wallMs(frame)` says when a callback runs, so a harness can
sample a player's keyboard at the burst, as a native client does. Without
`callbacks` (or with `EVEN_CALLBACKS`) callbacks stay 16.7 ms apart.

```ts
import { MEASURED_TURN_BURSTS, syncDelivery, turnBursts } from "wisp/src/headless/syncChannel";

const clients = headless.clients(entry, [0, 1], { delivery: syncDelivery(), callbacks: turnBursts(MEASURED_TURN_BURSTS, 7) });
```

The model: turn k (25 ms) runs at k·25 ms plus a jitter drawn uniformly
from 0–12 ms, plus, for 0.5% of turns, a hitch drawn from an exponential
with a 30 ms mean; a turn never runs before the one before it, so a hitch
merges the turns behind it into one longer burst. A fixed offset keeps the
mean wall time on game time. Callback n belongs to turn ⌈n·16.7 / 25⌉.

It is fitted to the largest callback gap of each second (`cbgap`, from
`os.clock`) in 1,520 seconds of Smashcraft's Battle.net rates lines with
55–65 callbacks (playable-0047, matches 793–801, 19 October 2026):

| Longest gap in a second | p1 | p10 | p25 | p50 | p75 | p90 | p95 | p99 | 30–45 ms |
| --- | --- | --- | --- | --- | --- | --- | --- | --- | --- |
| Recorded | 31.0 | 33.2 | 34.2 | 35.9 | 37.1 | 43.9 | 79.1 | 119.9 | 90% |
| Model (seeds 1–3) | 31.2–32.0 | 33.1–33.3 | 34.0–34.2 | 35.0–35.1 | 35.9–36.0 | 42.7–45.4 | 57.8–63.3 | 111–127 | 90–91% |

The recorded p95 tail (stalls of 50–130 ms) is heavier than the model's;
whether it is turn delivery or the map's own slow callbacks is not measured.

## Relay delivery

`relayDelivery()` and `relayCallbacks()` (wisp:src/headless/syncChannel.ts)
give headless clients the paced turns of Wisp's planned online relay
(wisp:docs/relay.md), so a map test meets relay timing as it meets
Battle.net's with `syncDelivery()`.

```ts
import { MEASURED_RELAY, relayCallbacks, relayDelivery } from "wisp/src/headless/syncChannel";

const relay = { ...MEASURED_RELAY, outage: { atMs: 10000, lengthMs: 1000 } };
const clients = headless.clients(entry, [0, 1], { delivery: relayDelivery(relay, 7), callbacks: relayCallbacks(relay) });
```

A `RelayTiming` gives the turn steps (`[8]`, or a cycle such as
`[17, 17, 16]`), the mean one-way jitter, one link per player (round trip,
independent loss and depth D in turns; players past the list take the last
link) and an optional outage. `MEASURED_RELAY` is the relay bench's 120 ms,
2% independent-loss cell at 8 ms turns: 2 ms of jitter and D = 4 for every
player.

| Part | Model | Bench (120 ms, 2%) |
| --- | --- | --- |
| Turns | Turn k runs at game time relayTime(k), the sum of the steps before it, on every client: an even grid that never bursts. | 8 ms steps. |
| Latency | A message sent at game time g leaves the sender at its feed lag, its one-way down (RTT / 2 plus the jitter's 5th percentile, the agent's anchor) plus D turns. Its upstream packet takes RTT / 2 plus exponential jitter; each loss resends it one turn later. It lands in the first turn after it reaches the relay. So the age is up + the wait for the next turn + down + D. | Own echo p50/p99 158.5/168.3 ms; the model gives 157.3/167.3 (seed 1). |
| Loss | Nothing is dropped: a lost packet only delays its message by one turn per loss, as the next packet repeats it. | No turn lost in the hour. |
| Order | Each sender's messages arrive in the order it sent them. | |
| Callbacks | `relayCallbacks()` runs callbacks 16.7 ms apart, as the agent's even feed does. | |
| Relay mark | None: relay delivery sends only what the clients send, so a map cannot tell a relayed match from Battle.net (wisp:docs/relay.md, "No relay mark"). | |

**Outage.** An outage blacks out both directions for `lengthMs` from relay
time `atMs`. Messages whose packets fall inside it leave when it ends. The
relay stops its clock once a player's checksums trail by 1 s (the trail at
the outage's start is taken as the worst link's RTT + D), and the next turn
after the restart is rebased to it, so that game time is never run. On the
clients the game freezes after the turn due at `atMs` until the backlog
arrives, `lengthMs` − D later (D of the shallowest link); a backlog more than
D + 2 turns deep then runs at 4 ms of wall time a turn back to D + 1, holds
there 30 s, and slews back to D at 1 ms a turn. The bench's 120 ms, 1% loss
and 1 s blackout cell (D = 3) catches up in 897 ms from the blackout's end;
the model takes 886 ms.

The defaults come from `cargo run --release -p relay-bench -- --grid --rtts 120`
(wisp:relay/relay-bench), 25 October 2026; wisp:src/headless/syncChannel.test.ts
checks the model's own-echo p50 and p99 against that cell within 5%, and
its catch-up within 5% of the blackout cell's. Provenance: the 5% match;
origin none (relay plan); pointer wisp:docs/relay.md, "Protocol core and
bench"; rationale not recorded; revisit if the bench and model disagree by
design; soft. The model has no underruns, no clock drift, no burst loss and
no saturation, and the bench is a simulation: fitting it to native relay
traces waits for wisp#38.

## Replayed arrivals

`replayedDelivery(arrivals, fallback, nowMs)` replays the arrival times a
native capture measured for particular messages and leaves every other one
to `fallback` (usually `syncDelivery()`). Each `ReplayedArrival` names the
message it takes (`accepts`, used once) and the time it arrived (`atMs`). The
message reaches every client at the first frame due at or after that time;
`nowMs` gives when the sending frame was due on the same clock, so with
`RealtimeClients` it is `() => realtime.frameDueMs()` and frames run late
under load still land on the measured time. `arrivals` is read at every
send, so a consumer can anchor the times to its own run, such as the moment
its scripted Start press went in. A sender's messages still arrive in order.

Smashcraft's `pad SCRIPT --headless --replay-arrivals NATIVE_DIR` measures
its pause and resume control messages from a native run's helper journals
this way (wisp#86, [Pause and drawn-frame timing](headless.md#pause-and-drawn-frame-timing)).

## Limits

**Saturation is not modeled.** In r7, r8 and the 6 October send-rate sweep
(smashcraft:evidence/input-integrity-sendcap-20261006/), a client's own
echo grew to 1–2 s while input was dense and stayed there. A per-sender byte
budget does not explain it, though fitted to r8 alone (450 bytes a second
per sender) it reproduced r8's echo, stalls and opponent lateness. On the
sweep it failed: it predicted 22, 64 and 110 prediction stalls at 10, 15 and
20 messages a second; the clients had 109, 123 and 116. In the sweep the two
clients sent the same bytes, about 380 a second at the densest; the hosting
client A held a 1.0–1.4 s echo even while sending 65 bytes a second, and
client B's median per-second echo stayed at 78–106 ms.

What the saturated client shows instead is a game clock behind real time.
Its journal receipts reached its helper about 0.5–1.2 s later, relative to its
game clock, than when the match began: r7 client B 0.72 s while A stayed
within 0.13 s, r8 client A 0.83 s and B 0.50 s, and the sweep's client A
0.74–1.21 s in every match while B stayed within 0.34 s. A client behind
real time sends late, so every client receives its messages late; its own
echo and the others' prediction stalls follow. Why the client falls behind is not measured, so the model has
no client lag and does not predict saturation.

**Latency moves between sessions.** On the held-out sweep (Smashcraft's
TypeScript map, 6 October), unsaturated echo was faster than the model for
client B (p50 65–97 ms, p90 89–127 ms against the model's 114–124 and
189–199) and about as fast for client A (p50 90–162 ms).

Neither session crossed the internet beyond one host and Battle.net; other
hosts, regions and hosting services are unmeasured.

## Wisp's transport

Two processes, one client each, play one match over UDP: the host is slot 0
and listens; the joiner is slot 1 and sends to the host's address and port
(LAN or a direct address; no relay, no Battle.net message, no W3GS).
wisp:src/headless/turnLedger.ts is the pure core; wisp:host/net/peer.ts
(`runNetPeer`) is the Effect shell that owns the socket, the frame clock and
the handshake.

**Events.** Every synchronized event a client raises goes over the wire:
`BlzSendSyncData` messages, player key events, chat and frame clicks. A
`Lockstep` created with `link` (a `TurnLedger`) and `humans` (every slot in the
match) runs only the local slot's client and hands each event to the link
instead of delivering it in process.

**Local keyboard.** A key press reaches its own player's `BlzIsKeyPressed`
and `BlzIsMetaKeyPressed` at once, as Warcraft's local keyboard does; only the
synchronized key event waits for the turn delay. A map that runs its own
rollback polls the local keyboard and tags each input row with its frame, so
local input reaches its simulation on the next frame and the map's own input
delay is the only delay (wisp#112).

**Turns and order.** There is one turn per frame (16.7 ms). An event raised
while frame n runs is due at frame n + d, one raised between frames n and n + 1
at n + 1 + d, where d is the turn delay. Every client delivers a frame's
events before its callbacks, the lowest slot's first, each sender's in the order
it sent them, so every client sees the same events on the same frame. A frame
runs only once every peer has promised all of its events for that frame.

**Packets.** After every frame, and every 8 ms while waiting, each side sends
one packet to all the others: its frontier (the last frame whose events it has promised), every
turn after the slowest peer's acknowledgement, its acknowledgement of each peer's
frontier (one count per slot), and its last four checksums. The relay's peer room forwards the
one datagram to every other member, which tell senders apart by the room's slot. A lost packet is repaired by the next
one, a frame later; there is no retransmission timer.

**Regions and delay.** Before a relayed match, `net host --relay nearest` (and `play --standalone --host --relay nearest`)
pings each published region and takes the lowest; `net join CODE` pings the code's relay and prints the round trip. The host's eight pings through the
relay measure the relayed path and set the turn delay. The same round trip goes to the map through
`NetSession.measured`, so the map's input delay follows from a number it
can't read from its own sync echoes, which under lockstep are a whole number of turns
(wisp:host/net/peer.ts, wisp:src/netcode/delay.ts, wisp:docs/relay.md, "Regions").

**Wire.** A `turns` packet is binary (wisp:host/net/wire.ts): varints for the
frames, acknowledgements and counts, each turn's frame as the step from the
turn before, its time as microseconds from the turn before (the first as a
double), and each event as a kind byte, its sender and its fields, exact. Sixteen
turns of a chat line and a key take 376 bytes where the JSON packet took 2452.
A packet never passes 1200 bytes (`MAX_DATAGRAM`, a relay's cap and under a
typical path MTU): when the turns after the acknowledgement don't fit, the
newest wait for a later packet and the frontier stops one frame before the
first of them, so the peer never takes a frame as complete that it was not
sent. Handshake messages (hello, ping, delay, ready, go, bye) stay JSON behind
a tag byte. The link under the packets is direct UDP or a relay's peer room
(wisp:docs/relay.md, "Peer room"); a relayed datagram carries 11 more bytes.

**Delay.** The host measures each peer's round trip with eight pings and picks
d = ceil((largest round trip / 2 + 4 ms) / 16.7 ms), at least 1: the one-way time plus
room for the sender's frame and timer jitter. On one host that is 1 frame; at
60 ms round trip 3, at 120 ms 4. Every side starts its client, then the host
names a start time that each joiner shifts by half its own round trip (the delay message
carries every slot's).

**Pacing.** Frames run on a 60 Hz schedule. A side more than three frames behind
its schedule (a slow frame, a long wait) drops the backlog instead of racing to
catch up (a slip); a side whose schedule is ahead of the peer's estimated frame
slows by up to 1 ms a frame (`paceShift`).

**Checksums.** Every 60 frames each side records the game's checksum; packets
carry the last four, and the first difference with any peer ends the match with
`NetDesync` naming the frame, the peer's slot and both values.

**Ending.** A peer that sends nothing for 3 s ends the match with `PeerSilent`;
a peer that leaves sends a goodbye, and the other side ends at once with
`PeerLeft` unless it already has every turn it needs from that peer. A finished side keeps
sending until the peer has its last turns and checksums (at most 3 s), then
says goodbye.

### Run it

A game exposes the command with `makeNet(load, name, gameFlags)`
(wisp:host/commands/net.ts); `load` returns a `NetGame` whose `create`
builds a session for one slot from the link. The sample's is
wisp:examples/sample/test/net.ts, which types `-ping` every two seconds per
player:

```sh
bun examples/sample/scripts/sample.ts net pair --frames 10000
bun examples/sample/scripts/sample.ts net pair --frames 1200 --rtt 120 --loss 0.01
bun examples/sample/scripts/sample.ts net pair --frames 1200 --freeze-at 300
```

`host [--port N]` and `join ADDRESS:PORT` run one side each; `pair` runs both
on this machine and prints one line per side.

**Up to four humans.** A match of 3 or 4 humans plays through a relay's peer room:
`host --relay REGION|ADDRESS:PORT --humans N` opens a room for N members and each
`join CODE` takes the room's next slot (the host is slot 0). The host waits for every
joiner's hello, pings all of them, and picks the delay from the largest round trip it
measured; a joiner learns N from the room. `pair --relay local --humans N` runs a relay
and N players on this machine and prints one line per player and a last line that says
whether the checksums match on all N. It needs a relay binary: `WISP_RELAY_BIN`, else
cargo builds relay/ (`pair` takes no fault drills with a relay; `--rtt` and `--loss` put a
proxy between the relay and each joiner, so a joiner's path to the host holds that round trip). With `--rtt MS` or `--loss P`,
`pair` puts `net proxy` between them: a separate process that holds every
datagram half the round trip in each direction and drops it with probability
P (seeded by `--seed`). `--freeze-at F` makes the joiner stop sending after
frame F, `--quit-at F` makes it leave; `--delay N` fixes the turn delay.
Each side's line gives the frames, delay, checksums compared and mismatches,
delivery time p50/p95/p99/max (from the moment the remote event was raised to
the frame that delivered it here, both on this host's clock), its step cost,
slips and late frames.

Players host and join a match from the standalone window by a short code
(wisp:docs/play.md, Host and join).

For timings off a shared machine, dispatch wisp:.github/workflows/net-timing.yml:
it runs one `pair` per round trip on its own hosted runner, for this
repository's sample or a game's (`repository`, `ref`, `directory`, `pair`).

### Measured (9 October 2026)

- Sample, two processes on one host, loopback, 10,000 frames, delay 1: 166
  checksums compared per side, 0 mismatches; delivery p95 20.9 ms (host) and
  19.1 ms (joiner).
- A joiner that stops sending at frame 300 (`--freeze-at 300`) ends the host
  with `PeerSilent` "no packet for 3.0 s", also at 120 ms round trip and 1%
  loss; one that leaves (`--quit-at 300`) ends the host with `PeerLeft` 0.05 s
  later.
- Smashcraft's `cpu-expert.pad`, one slot per process, 1,200 frames through
  `net proxy` with 1% loss (seed 5), each round trip on its own hosted runner
  (wisp:.github/workflows/net-timing.yml run 37941062995, Smashcraft
  97fd7bf20, Wisp 2783de3): 20 checksums compared per side, 0 mismatches at
  every setting. Delivery p50/p95/p99, host and joiner, against the bound of
  one way + 2 frames on p95:

  | Round trip | Delay | Host | Joiner | p95 bound |
  | --- | --- | --- | --- | --- |
  | 0 ms | 1 | 15.0/19.2/34.0 ms | 14.9/18.2/33.2 ms | 33.3 ms |
  | 60 ms | 3 | 48.4/57.3/93.7 ms | 48.3/54.9/67.9 ms | 63.3 ms |
  | 120 ms | 4 | 64.4/82.4/128.1 ms | 64.0/73.1/95.8 ms | 93.3 ms |

  With 8 ms of slack the 120 ms setting picked delay 5 and the host's p95 was
  96.3 ms (run 37940402704).

The delivery time is the turn delay plus how late the receiving frame runs.
Late frames come from the map's own slow frames (Smashcraft's step max was
60–190 ms, at its setup and while warming up) and from packets that arrive
after their frame was due.
