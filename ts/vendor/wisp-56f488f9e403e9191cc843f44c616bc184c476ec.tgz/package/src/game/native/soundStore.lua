local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__Class = ____lualib.__TS__Class
local Map = ____lualib.Map
local __TS__Iterator = ____lualib.__TS__Iterator
local ____exports = {}
local ____f32 = require("src.sim.f32")
local ____frameRate = require("src.game.native.frameRate")
function ____exports.assertSoundCue(log, expected)
    local count = 0
    for ____, cue in ipairs(log) do
        do
            if cue.event ~= "start" then
                goto __continue3
            end
            if expected.source ~= nil and cue.source ~= expected.source then
                goto __continue3
            end
            if expected.label ~= nil and cue.label ~= expected.label then
                goto __continue3
            end
            if expected.frame ~= nil and cue.frame ~= expected.frame then
                goto __continue3
            end
            count = count + 1
        end
        ::__continue3::
    end
    if count ~= (expected.count or 1) then
        do
            local ____thrown = __TS__New(
                Error,
                (((("sound cue " .. (expected.source or expected.label or "any")) .. ": expected ") .. tostring(expected.count or 1)) .. " starts, got ") .. tostring(count)
            )
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/game/native/soundStore.ts:37"
            end
            error(____thrown, 0)
        end
    end
end
____exports.Sounds = __TS__Class()
local Sounds = ____exports.Sounds
Sounds.name = "Sounds"
function Sounds.prototype.____constructor(self, handle, musicSlider, frame)
    self.handle = handle
    self.musicSlider = musicSlider
    self.frame = frame
    self.log = {}
    self.sounds = __TS__New(Map)
    self.musicVolume = 127
end
function Sounds.prototype.create(self, source, label, looping)
    local handle = self.handle("sound")
    local sound = {
        kind = "sound",
        handle = handle,
        source = source,
        label = label,
        volume = 127,
        pitch = 1,
        x = 0,
        y = 0,
        z = 0,
        unit = nil,
        looping = looping,
        duration = 0,
        elapsed = 0,
        playing = false,
        killWhenDone = false
    }
    self.sounds:set(handle, sound)
    self:cue(sound, "create")
    return handle
end
function Sounds.prototype.cue(self, sound, event)
    local ____self_log_15 = self.log
    local ____event_4 = event
    local ____sound_kind_5 = sound.kind
    local ____self_frame_result_6 = self.frame()
    local ____sound_handle_7 = sound.handle
    local ____sound_source_8 = sound.source
    local ____sound_label_9 = sound.label
    local ____sound_volume_10 = sound.volume
    local ____temp_11 = sound.volume / 127 * (sound.kind == "music" and self.musicSlider or 1)
    local ____sound_looping_12 = sound.looping
    local ____sound_pitch_13 = sound.pitch
    local ____opt_0 = sound.unit
    local ____temp_14 = ____opt_0 and ____opt_0.x or sound.x
    local ____opt_2 = sound.unit
    ____self_log_15[#____self_log_15 + 1] = {
        event = ____event_4,
        kind = ____sound_kind_5,
        frame = ____self_frame_result_6,
        handle = ____sound_handle_7,
        source = ____sound_source_8,
        label = ____sound_label_9,
        volume = ____sound_volume_10,
        effectiveVolume = ____temp_11,
        looping = ____sound_looping_12,
        pitch = ____sound_pitch_13,
        x = ____temp_14,
        y = ____opt_2 and ____opt_2.y or sound.y,
        z = sound.z
    }
end
function Sounds.prototype.stopVoice(self, sound)
    if not sound.playing then
        return
    end
    self:cue(sound, "stop")
    sound.playing = false
end
function Sounds.prototype.playMusic(self, source, looping)
    if looping == nil then
        looping = true
    end
    if self.music ~= nil then
        self:stopVoice(self.music)
    end
    self.music = {
        kind = "music",
        handle = {kind = "music", id = 0},
        source = source,
        label = nil,
        volume = self.musicVolume,
        pitch = 1,
        x = 0,
        y = 0,
        z = 0,
        unit = nil,
        looping = looping,
        duration = 0,
        elapsed = 0,
        playing = true,
        killWhenDone = false
    }
    self:cue(self.music, "start")
end
function Sounds.prototype.stopMusic(self)
    if self.music ~= nil then
        self:stopVoice(self.music)
    end
end
function Sounds.prototype.resumeMusic(self)
    if self.music == nil or self.music.playing then
        return
    end
    self.music.playing = true
    self:cue(self.music, "start")
end
function Sounds.prototype.setMusicVolume(self, volume)
    self.musicVolume = math.max(
        0,
        math.min(127, volume)
    )
    if self.music == nil then
        return
    end
    self.music.volume = self.musicVolume
    if self.music.playing then
        self:cue(self.music, "volume")
    end
end
function Sounds.prototype.start(self, handle)
    local sound = self.sounds:get(handle)
    if sound == nil or sound.playing then
        return
    end
    self:cue(sound, "start")
    sound.elapsed = 0
    sound.playing = sound.looping or sound.duration > 0
    if not sound.playing and sound.killWhenDone then
        self.sounds:delete(handle)
    end
end
function Sounds.prototype.stop(self, handle, killWhenDone)
    local sound = self.sounds:get(handle)
    if sound == nil then
        return
    end
    self:stopVoice(sound)
    if killWhenDone or sound.killWhenDone then
        self.sounds:delete(handle)
    end
end
function Sounds.prototype.killWhenDone(self, handle)
    local sound = self.sounds:get(handle)
    if sound == nil then
        return
    end
    sound.killWhenDone = true
    if not sound.playing then
        self.sounds:delete(handle)
    end
end
function Sounds.prototype.setDuration(self, handle, duration)
    local sound = self.sounds:get(handle)
    if sound ~= nil then
        sound.duration = math.max(0, duration)
    end
end
function Sounds.prototype.duration(self, handle)
    local ____opt_16 = self.sounds:get(handle)
    return ____opt_16 and ____opt_16.duration or 0
end
function Sounds.prototype.isPlaying(self, handle)
    local sound = self.sounds:get(handle)
    return sound ~= nil and sound.playing and not sound.killWhenDone
end
function Sounds.prototype.setLabel(self, handle, label)
    local sound = self.sounds:get(handle)
    if sound ~= nil then
        sound.label = label
    end
end
function Sounds.prototype.setVolume(self, handle, volume)
    local sound = self.sounds:get(handle)
    if sound == nil then
        return
    end
    sound.volume = math.max(
        0,
        math.min(127, volume)
    )
    if sound.playing then
        self:cue(sound, "volume")
    end
end
function Sounds.prototype.setPitch(self, handle, pitch)
    local sound = self.sounds:get(handle)
    if sound ~= nil then
        sound.pitch = pitch
    end
end
function Sounds.prototype.setPosition(self, handle, x, y, z)
    local sound = self.sounds:get(handle)
    if sound == nil then
        return
    end
    sound.x = x
    sound.y = y
    sound.z = z
    sound.unit = nil
end
function Sounds.prototype.attachToUnit(self, handle, unit)
    local sound = self.sounds:get(handle)
    if sound ~= nil then
        sound.unit = unit
    end
end
function Sounds.prototype.tick(self)
    for ____, sound in __TS__Iterator(self.sounds:values()) do
        do
            if not sound.playing or sound.looping then
                goto __continue49
            end
            sound.elapsed = sound.elapsed + sound.pitch * 1000 / ____frameRate.FRAMES_PER_SECOND
            if sound.elapsed < sound.duration then
                goto __continue49
            end
            self:stopVoice(sound)
            if sound.killWhenDone then
                self.sounds:delete(sound.handle)
            end
        end
        ::__continue49::
    end
end
return ____exports
