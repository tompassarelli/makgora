local ____lualib = require("lualib_bundle")
local __TS__Class = ____lualib.__TS__Class
local ____exports = {}
--- The lines a game is writing to a file in the data folder; the host's sink receives them whole when the file ends.
____exports.FileLines = __TS__Class()
local FileLines = ____exports.FileLines
FileLines.name = "FileLines"
function FileLines.prototype.____constructor(self, write)
    self.write = write
    self.lines = {}
end
function FileLines.prototype.clear(self)
    self.lines = {}
end
function FileLines.prototype.add(self, text)
    local ____self_lines_0 = self.lines
    ____self_lines_0[#____self_lines_0 + 1] = text
end
FileLines.prototype["end"] = function(self, path)
    self.write(
        path,
        {table.unpack(self.lines)}
    )
end
return ____exports
