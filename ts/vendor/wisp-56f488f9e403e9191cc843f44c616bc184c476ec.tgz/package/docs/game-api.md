# Game API

Wisp's own game API is the contract that gameplay and presentation code calls, shaped for this game and not for Warcraft III's natives. The plan, its order and the measurements that prove each family are in [game-api-plan.md](game-api-plan.md). This page documents the families that exist.

A family is a module `wisp/game/<family>`. Its declarations are `src/game/<family>.d.ts`. On Warcraft, `plugins/game-api.ts` drops the import and rewrites each call as the native call that the family's table in `src/game/warcraft/<family>.ts` names, so a migrated call costs what the native call cost. On Bun the import resolves to `src/game/native/<family>.ts`, which reads the world a host has bound (`src/game/native/world.ts`).

Add the plugin after `warcraft-numbers.ts` in a map's `luaPlugins`:

```json
"luaPlugins": [
  { "name": "./node_modules/wisp/plugins/warcraft-numbers.ts" },
  { "name": "./node_modules/wisp/plugins/game-api.ts" }
]
```

An API function used as a value (passed, stored) is a compile error (TS9310), because under Lua no function exists to pass. Code that treats natives as values stays on raw natives.

## Lowering table format

`export const <family>: Lowering` maps each exported function name to a template `Native($1, $2, false)`: one expression whose arguments are the call's arguments (`$n`, 1-based, each at most once and in order), the literals `false`, `true` or an integer, a global constant (`TriggerRegisterPlayerEvent($1, $2, EVENT_PLAYER_LEAVE)`) or a nested native (`SetPlayerColor($1, ConvertPlayerColor($2))`). `parseTemplate` in `src/game/warcraft/lowering.ts` defines the grammar, and `test/game-api.test.ts` checks every row against `src/natives/warcraft.d.ts` and the native backend.

## Constants and opaque types

A handle or enumeration type of a family is `Opaque<"Name">` (`src/game/opaque.d.ts`): a game holds it, compares it and passes it on, and a Warcraft handle does not convert to it. An enumeration also has a constant of the same name (`export declare const FramePoint: { readonly topLeft: FramePoint; ... }`). `export const <family>Constants: ConstantLowering` in `src/game/warcraft/<family>.ts` maps each member to the Warcraft global it stands for, and `plugins/game-api.ts` lowers `FramePoint.topLeft` to a read of `FRAMEPOINT_TOPLEFT`, so the compiled map is the one the raw global gave. The constant object itself used as a value is rejected like a function used as a value. The native backend exports the same object from `src/game/native/<family>.ts`, holding the value the headless client gives the global, and `test/game-api.test.ts` checks the declaration, the lowering and the backend member for member.

## Native backend and the call log

A host binds the world it is about to run with `bindWorld(world)`: `host/headless` binds each client's world around that client's turns. Each native backend call logs the native name and arguments of its table row to `world.log`, which only the headless client installs, so `callHash.ts` and each game's `localNatives` keep their native names. Outside headless nothing is logged.

## Effects

`wisp/game/effects`: effects (`createEffect`, `destroyEffect`, position, scale, matrix, orientation, alpha, colour, animation, time and blend calls, `effectX`/`effectY`/`effectZ` local reads, `effectScale`), beams (`createBeam`, `moveBeam`, `setBeamColor`, `destroyBeam`) and floating text (`createFloatingText`, `setFloatingText*`). The stores are `src/game/native/effectStore.ts`, `lightnings.ts` and `textTags.ts`. `Effect`, `Beam`, `FloatingText` and `EffectAnimation` are opaque types, and `EffectAnimation.stand`, `.birth`, `.death`, `.walk`, `.spell` and `.attack` are its constants.

## Frames

`wisp/game/frames`: frame creation (`createFrame` from a template the game ships, `createFrameByType` with a `FrameKind`), tree and name reads (`originFrame`, `namedFrame`, `frameChild`, `frameChildCount`, `frameName`), every setter the Warcraft frame natives have (position, size, scale, level, alpha, colour, texture, text, font, alignment, visibility, enabling, focus, and `setFrameModel`, `setFrameSpriteAnimation` and `setFrameSpriteTime` for a frame that shows a model), the local reads `frameText`, `frameEnabled`, `frameVisible`, `screenWidth` and `screenHeight`, `frameColor` (the signed ARGB word of a colour), `addFrameEvent(events, frame, event)` with the event reads `eventFrame`, `eventFrameEvent` and `eventFrameText`, the message area (`displayText`, `displayTimedText`, `clearTextMessages`, `debugMessage`) and the quest log (`createQuest`, `setQuest*`). The frame tree is `src/game/native/frameStore.ts` and its calls are `frameUi.ts`, which the emulated Warcraft natives in `src/headless/natives/frames.ts` run too. `Quests` (`quests.ts`) holds the quest log, and a headless test reads `client.quests.entries()` where Warcraft would draw the log. `Frame`, `Quest`, `FramePoint`, `FrameEvent`, `TextAlignment` and `OriginFrame` are opaque types, and `FramePoint.topLeft`, `FrameEvent.controlClick`, `TextAlignment.middle` and `OriginFrame.gameUi` are among their constants. The native backend refuses to register one frame event twice on the same events.

## Events

`wisp/game/events`: `createEvents()`, `onEvents(events, handler)` and `destroyEvents(events)`. The trigger store is `src/headless/natives/triggersTimers.ts`, which implements `EventStore` (`src/game/native/eventStore.ts`) for the native backend; its sources other than frames (keys, sync, chat, leave) stay raw natives on an events value until their own family moves.

## Sound

`wisp/game/sound`: sounds (`createSound`, `soundFromLabel`, `playSound`, `stopSound`, `setSoundVolume`/`Pitch`/`Position`/`Distances`/`Cutoff`/`Duration`, `releaseWhenDone`, `soundFileDuration`), music (`playMusic`, `stopMusic`, `clearMusic`, `playTheme`, `endTheme`) and volume groups (`setVolumeGroup`, `resetVolumeGroups`). The store is `src/game/native/soundStore.ts`; its cue log reaches `host/window/soundPlayer.ts` through the client's `soundLog`. The native backend keeps the attenuation range, the cutoff, the volume groups and `clearMusic`/`endTheme` only in the call log, because the window mixes with rules of its own, and `soundFileDuration` reads 0 because headless decodes no file. `Sound` and `VolumeGroup` are opaque types, and `VolumeGroup.combat` and `VolumeGroup.spells` are the volume groups.

## Text

`wisp/game/text`: `formatInt`, `formatReal`, `formatRealWidth`, `parseInt`, `parseReal`, `toReal`, `truncate` and `textLength`, which lower to `I2S`, `R2S`, `R2SW`, `S2I`, `S2R`, `I2R`, `R2I` and `StringLength`. They are pure, so the native backend (`src/game/native/text.ts`) needs no world: it logs its row's native only when a headless client is bound. The formatting rules are in `src/game/native/textFormat.ts`, and `src/game/native/text.tests.ts` runs the same table of values in Bun and in 32-bit Lua.

The rules, which both backends keep:

- `formatReal` prints the value as binary32 with three decimals and rounds an exact tie away from zero (0.0625 prints `0.063`, -0.0625 prints `-0.063`), keeping negative zero. Replays and records are text, and a replay recorded on one backend must read alike on the other, so the native backend does not use the host's own number formatting.
- `formatRealWidth` pads on the left to `width + 1` characters and keeps at least one decimal, so a precision of 0 prints `1.0` for 0.5.
- `parseInt` skips leading spaces, reads a sign and digits and stops at the first other character, and truncates toward zero; `parseReal` does not skip spaces, reads one fraction point and returns the binary32 value.
- `truncate` rounds toward zero.

## Files

`wisp/game/files`: the game's file output in its data folder, one call per Warcraft native because sites add lines in loops and between other calls: `clearFileLines`, `startFile`, `addFileLine(text)` and `endFile(path)`, and `preloadAsset(path)` for loading a model, texture or sound ahead of its first use. All five are local. `preloadAsset` lowers to `Preload` too, because Warcraft preloads an asset with the call that adds a file line, but it writes no file: the native backend only logs it, because Wisp loads an asset when it is first needed and an asset path must not become a line of the next file. Reads stay in `src/map/fileio.ts`. The store is `src/game/native/fileLines.ts`: it holds the lines added since the last `clearFileLines` and gives the host's sink a copy when `endFile` names the path. A line is kept whole, because the 259-byte line cut is a Warcraft quirk that stays in `src/headless/natives/preloadText.ts` for the Warcraft-named natives.

## Players

`wisp/game/players`: `player(slot)`, `playerSlot`, `localPlayer` (a local read), `eventPlayer`, `playerControl`, `playerSlotState`, `playerName`, `setPlayerColor(player, color)` and `addLeaveEvent(events, player)`. `setPlayerColor` lowers to `SetPlayerColor(player, ConvertPlayerColor(color))` and `addLeaveEvent` to `TriggerRegisterPlayerEvent(events, player, EVENT_PLAYER_LEAVE)`. The pair `playerControl` and `playerSlotState` stays two calls, because Smashcraft tests them apart. The store is `src/game/native/playerStore.ts`: a headless client fills it from its own slot, the humans it was started with and the player names, and `src/headless/natives/players.ts` runs the emulated natives over the same store. `Player`, `PlayerControl` and `PlayerSlotState` are opaque types; `PlayerControl.user` and `.computer` and `PlayerSlotState.playing` equal what the store returns.

## View

`wisp/game/view`: the camera (`setCameraField`, `setCameraBounds`, `setCameraPosition`, `panCameraTo`, `setCameraSmoothing`, and the local reads `cameraField`, `cameraTargetX`/`Y`/`Z` and `cameraEyeX`/`Y`/`Z`), terrain fog (`setTerrainFog`, `setTerrainFogHeight`, `resetTerrainFog`, `setTerrainFogMaxDensity`, `setTerrainFogOverSky`, `enableFog`, `enableFogMask`), the sky and light (`setSkyModel`, `showSky`, `showTerrain`, `setDayNightModels`, `setTimeOfDay`, `setTimeOfDayScale`, `setShadowLightCount`) and the cinematic filter (`setFilter*`, `showFilter`). One call is one native. The store is `View` in `src/game/native/viewStore.ts`, which the window draws from through `RenderScene` (the camera pose, the filter pose, the fog record and the environment).

The native backend keeps what a player sees: the camera's position and fields, the fog record, the sky model and visibility, terrain visibility, the day and night models, the time of day, the shadow light count and the filter. It only logs the calls with no look of their own: `setCameraBounds`, `panCameraTo`, `setCameraSmoothing`, `enableFog`, `enableFogMask` and `setTimeOfDayScale`. `cameraTargetX` and `cameraTargetY` read the camera position, and `cameraTargetZ` and the three eye reads answer 0 until the window reports its camera. `WispSetSkyLook` and `WispResetSkyLook` are not part of the family: they are Wisp's own window hooks that a map guards with `typeof`. `CameraField`, `FilterBlendMode` and `FilterTexMapFlags` are opaque types with the constants `CameraField.zOffset` and its siblings, `FilterBlendMode.blend` and `FilterTexMapFlags.none`.

## Sync

`wisp/game/sync`: `sendSync(prefix, data)`, `addSyncEvent(events, player, prefix)`, and the reads `syncData()` and `syncPrefix()` of the message whose event is running. `addSyncEvent` lowers to `BlzTriggerRegisterPlayerSyncEvent(events, player, prefix, false)`: server-sent messages are not in the API. The contract: a client's messages reach every client, the sender included, in the order they were sent, and one message carries at most 255 characters. The native backend throws on a longer message so that a headless Bun test catches it, where the emulated `BlzSendSyncData` keeps cutting at 255 as Warcraft does. The store is `src/game/native/syncStore.ts`, which appends to the client's outbox (`ClientOptions.network`); the host delivers the outbox to every client through `deliverSync`, with the latency model of `src/headless/syncChannel.ts` under `lockstep`, and under `net` runs through `host/net`.

## Bodies

`wisp/game/bodies`: the posed models of units and the locations the map reads. `mapCenter()` lowers to `GetRectCenter(GetPlayableMapRect())` and `removeLocation`, `locationX` and `locationY` to the location natives. A body is made by `createBody(player, kind, x, y, facing)` and posed by `setBodyX`, `setBodyY`, `setBodyHeight(body, height, rate)` (a rate of 0 puts it there at once), `setBodyFacing`, `setBodyColor(body, color)` (`SetUnitColor(body, ConvertPlayerColor(color))`), `setBodyTint`, `setBodyScale`, `setBodyTimeScale`, `setBodyAnimation`, `setBodyAnimationIndex`, `showBody` and `setBodyTeamGlow`; `bodyHidden`, `bodyKind`, `bodyMoveSpeed` and `bodyAttackCooldown` are local reads. The calls that only set up Warcraft's unit (`setBodyName`, `setBodySelectionScale`, `setBodyMoveSpeed`, `setBodyAttackCooldown`, `setBodyBlendTime`, `setBodyInvulnerable`, `setBodyPathing`, `pauseBody`, `addBodyAbility`, `removeBodyAbility`, `setAbilityTooltip`) lower one to one and are logged and otherwise ignored on the native backend, except that it keeps the move speed and attack cooldown (weapon 0) for the reads and the blend time for the pose. The store is `src/game/native/bodyStore.ts`, which holds the bodies, their poses, the locations and the life and mana fixtures; `src/headless/natives/units.ts` keeps the Warcraft-named natives, the combat helpers and the alliances over the same store. `mapCenter` allocates a rect and a location handle in the order the emulated natives do and the location reads as the origin, so a headless Bun run and its Lua run hash alike. `Body` and `Location` are opaque types.

## Input

`wisp/game/input`: keys (`osKey(code)`, `addKeyEvent(events, player, key, modifiers, down)`, `eventKey()` and the local `keyDown(key)`), the pointer (the local `pointerX`, `pointerY`, `mouseDown(button)`, `setPointer` and `showCursor`, and the event reads `eventPointerX` and `eventPointerY` of `addPointerMoveEvent(events, player)`), chat (`addChatEvent(events, player, text, exact)` and `chatText()`), the local `windowFocused()`, and `enableSelections` and `enableUserControl`. `eventKey()` lowers to `GetHandleId(BlzGetTriggerPlayerKey())`, the pair that every key-reading site made. `osKey` stays a call of its own, because a game caches its result and `addKeyEvent` and `keyDown` take that value. `addPointerMoveEvent` lowers to `TriggerRegisterPlayerEvent(events, player, EVENT_PLAYER_MOUSE_MOVE)`. The store is `Input` in `src/game/native/inputStore.ts`: the keys and the modifier mask held, the buttons held and the cursor in the pixels of the client's screen, which the host's window feed (`src/headless/pointer.ts`, `client.hold`) sets, and the emulated `BlzIsKeyPressed`, `BlzIsMouseButtonPressed` and `BlzGetMouseScreenPos` read the same store. The events store holds the key, chat and mouse-move registrations and the running event's key, chat string and cursor. `setPointer`, `showCursor`, `enableSelections` and `enableUserControl` have no look of their own on the native backend and are only logged, as the emulation did. `OsKey` and `MouseButton` are opaque types, and `MouseButton.left` is the left button. The typed character, relative motion, the cursor icon and cage and the frame under the pointer are not in this family.

## Clock

`wisp/game/clock`: timers (`createTimer`, `startTimer(timer, seconds, periodic, handler)`, `pauseTimer`, `destroyTimer`), the local reads `localElapsed(timer)` (Warcraft's `TimerGetElapsed`) and `gameSpeed()`, and the match calls `setNormalSpeed()` (`SetGameSpeed(MAP_SPEED_NORMAL)`), `lockSpeed()` (`SetMapFlag(MAP_LOCK_SPEED, true)`) and `restartMatch(scoreScreen)`. The native clock (`Clock` in `src/game/native/clockStore.ts`) counts whole simulation frames and the headless client's frame step runs it, so the window's frame clock fires it through the same step. A timer fires on the frame at or after its deadline, at most once per frame, in deadline then start order; a periodic timer keeps its deadlines (`due + period`) and, when it falls behind, restarts a period from the current frame. A period's float noise (binary32 1/60 is 1.00000005 frames) is removed at 1e-6 frame, and nothing else is rounded: a period that is not a whole number of frames fires on the frame at or after each deadline. The Warcraft backend's binary32 deadlines and 1/1024 s minimum timeout stay in `src/headless/natives/timerDeadline.ts` for the emulated natives. `setNormalSpeed` sets what `gameSpeed()` returns, and `lockSpeed` and `restartMatch` have no look of their own on the native backend and are only logged. `Timer` and `GameSpeed` are opaque types, and `GameSpeed.slowest`, `.slow`, `.normal`, `.fast` and `.fastest` are the game speeds. `FRAME_SECONDS` stays Smashcraft's own constant, because a constant has no call to lower.
