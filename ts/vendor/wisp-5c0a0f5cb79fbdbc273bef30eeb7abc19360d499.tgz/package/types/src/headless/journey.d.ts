/** @noSelfInFile */
import type { Lockstep } from "./lockstep";
import type { MissingNative } from "./clientTypes";
export type JourneyEvent = {
    readonly frame: number;
    readonly player: number;
    readonly chat: string;
} | {
    readonly frame: number;
    readonly player: number;
    readonly key: number;
    readonly meta: number;
    readonly down?: boolean;
} | {
    readonly frame: number;
    readonly player: number;
    readonly mouse: {
        readonly x: number;
        readonly y: number;
        readonly left?: boolean;
    };
} | {
    readonly frame: number;
    readonly player: number;
    readonly click: {
        readonly x: number;
        readonly y: number;
    };
} | {
    readonly frame: number;
    readonly reload: true;
};
export interface Journey {
    readonly frames: number;
    readonly events: readonly JourneyEvent[];
}
interface ClientResult {
    readonly slot: number;
    readonly calls: number;
    readonly checksum?: string;
    readonly errors: readonly string[];
    readonly missingNatives: readonly MissingNative[];
}
export interface JourneyResult {
    readonly frames: number;
    readonly clients: readonly ClientResult[];
    readonly divergence: string | undefined;
    readonly reloaded: number;
    readonly reloads: readonly string[];
}
export interface JourneyOptions {
    readonly stepFrames?: number;
    readonly checksums?: boolean;
    readonly observationFrames?: readonly number[];
    readonly observe?: (this: void, clients: Lockstep, frame: number) => void;
    readonly observationClock?: (this: void, clients: Lockstep) => number | undefined;
}
export declare function runJourney(clients: Lockstep, journey: Journey, options?: JourneyOptions): JourneyResult;
export declare function journeyProblems(result: JourneyResult): number;
export declare function journeyLines(result: JourneyResult): string[];
export {};
