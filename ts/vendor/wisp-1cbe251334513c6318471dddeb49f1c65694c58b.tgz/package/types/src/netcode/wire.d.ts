/** @noSelfInFile */
export declare const ALPHABET = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_";
export declare const WIRE_MAX_VALUE = 2147483646;
export declare function digit(value: number): string;
export declare function varint(value: number): string;
export declare function signedVarint(value: number): string;
export interface WireReader {
    readonly text: string;
    offset: number;
}
export declare function wireReader(text: string, offset: number): WireReader;
export declare function atEnd(reader: WireReader): boolean;
export declare function readDigit(reader: WireReader): number | undefined;
export declare function readVarint(reader: WireReader, maximum: number): number | undefined;
export declare function readSignedVarint(reader: WireReader, magnitude: number): number | undefined;
