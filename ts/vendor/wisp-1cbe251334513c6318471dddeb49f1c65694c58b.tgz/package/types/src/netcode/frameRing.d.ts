/** @noSelfInFile */
import type { RowCodec } from "./codec";
export interface FrameRing<Row> {
    readonly frames: number[];
    readonly rows: readonly Row[];
}
export declare function frameRing<Row>(codec: RowCodec<Row>, capacity: number): FrameRing<Row>;
export declare function ringRow<Row>(ring: FrameRing<Row>, frame: number): Readonly<Row> | undefined;
export declare function ringStore<Row>(codec: RowCodec<Row>, ring: FrameRing<Row>, frame: number, row: Readonly<Row>): void;
