/** @noSelfInFile */
import { type RowCodec } from "./codec";
export declare const MESSAGE_MAX_BYTES = 200;
export declare const MESSAGE_MAX_FRAMES = 64;
export interface EncodedMessage {
    readonly wire: string;
    readonly lastFrame: number;
}
export interface DecodedMessage {
    readonly firstFrame: number;
    readonly count: number;
}
export declare function encodeMessage<Row>(codec: RowCodec<Row>, firstFrame: number, lastFrame: number, rowAt: (this: void, frame: number) => Readonly<Row>): EncodedMessage;
export declare function decodeMessage<Row>(codec: RowCodec<Row>, wire: string, rows: readonly Row[]): DecodedMessage | undefined;
