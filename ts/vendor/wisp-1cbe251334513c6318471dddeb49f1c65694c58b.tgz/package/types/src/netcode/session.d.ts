/** @noSelfInFile */
import type { RowCodec } from "./codec";
import { type FrameRing } from "./frameRing";
import { type InputLedger, type Receipt } from "./ledger";
export interface NetSettings {
    readonly delay: number;
    readonly window: number;
    readonly sendEvery: number;
    readonly catchUp: number;
}
export declare const NET_SETTINGS: NetSettings;
export interface Simulation<Row, State> {
    readonly codec: RowCodec<Row>;
    step(this: void, state: State, rows: readonly Row[]): State;
    predicted(this: void, state: State): void;
    confirmed(this: void, state: State): void;
}
export interface NetStats {
    rollbacks: number;
    deepest: number;
    held: number;
    messages: number;
    largest: number;
    refused: number;
}
export interface Session<Row, State> {
    readonly players: number;
    readonly local: number;
    readonly ledger: InputLedger<Row>;
    readonly pending: FrameRing<Row>;
    readonly used: readonly FrameRing<Row>[];
    readonly states: State[];
    readonly stateFrames: number[];
    readonly rows: readonly Row[];
    readonly frameRows: Readonly<Row>[];
    readonly inbox: readonly Row[];
    confirmed: State;
    confirmedFrame: number;
    present: number;
    callbacks: number;
    rollbackFrom: number;
    sentThrough: number;
    credit: number;
    sinceSend: number;
    pressWaiting: boolean;
    lastHadPress: boolean;
    readonly stats: NetStats;
}
export declare function createSession<Row, State>(sim: Simulation<Row, State>, settings: NetSettings, players: number, local: number, initial: State): Session<Row, State>;
export declare function predictedAt<Row, State>(session: Session<Row, State>, frame: number): State | undefined;
export declare function predictedState<Row, State>(session: Session<Row, State>): State;
export declare function remoteThrough<Row, State>(session: Session<Row, State>): number;
export declare function receive<Row, State>(session: Session<Row, State>, sim: Simulation<Row, State>, sender: number, wire: string): Receipt;
export declare function leave<Row, State>(session: Session<Row, State>, sim: Simulation<Row, State>, player: number): void;
export declare function tick<Row, State>(session: Session<Row, State>, sim: Simulation<Row, State>, settings: NetSettings, sample: Row): string | undefined;
