local ____exports = {}
local ____intMath = require("src.sim.intMath")
____exports.TWO_POWERS = {
    1,
    2,
    4,
    8,
    16,
    32,
    64,
    128,
    256,
    512,
    1024,
    2048,
    4096,
    8192,
    16384,
    32768,
    65536,
    131072,
    262144,
    524288,
    1048576,
    2097152,
    4194304,
    8388608,
    16777216,
    33554432,
    67108864,
    134217728,
    268435456,
    536870912,
    1073741824
}
function ____exports.shiftRightJam(value, count)
    if count >= 72 then
        return {high = 0, middle = 0, low = (value.high ~= 0 or value.middle ~= 0 or value.low ~= 0) and 1 or 0}
    end
    local high = value.high
    local middle = value.middle
    local low = value.low
    local remaining = count
    while remaining >= 24 do
        local lost = low ~= 0
        low = middle
        middle = high
        high = 0
        if lost and low % 2 == 0 then
            low = low + 1
        end
        remaining = remaining - 24
    end
    if remaining > 0 then
        local divisor = ____exports.TWO_POWERS[remaining + 1] or 1
        local carry = ____exports.TWO_POWERS[24 - remaining + 1] or 1
        local lost = low % divisor ~= 0
        low = low // divisor + middle % divisor * carry
        middle = middle // divisor + high % divisor * carry
        high = high // divisor
        if lost and low % 2 == 0 then
            low = low + 1
        end
    end
    return {high = high, middle = middle, low = low}
end
function ____exports.addLimbs(a, b)
    local lowSum = a.low + b.low
    local middleSum = a.middle + b.middle + lowSum // 16777216
    return {high = a.high + b.high + middleSum // 16777216, middle = middleSum % 16777216, low = lowSum % 16777216}
end
function ____exports.lessThan(a, b)
    return a.high < b.high or a.high == b.high and (a.middle < b.middle or a.middle == b.middle and a.low < b.low)
end
function ____exports.subtractLimbs(a, b)
    local low = a.low - b.low
    local middle = a.middle - b.middle
    local high = a.high - b.high
    if low < 0 then
        low = low + 16777216
        middle = middle - 1
    end
    if middle < 0 then
        middle = middle + 16777216
        high = high - 1
    end
    return {high = high, middle = middle, low = low}
end
function ____exports.bitLength(value)
    local remaining = value
    local result = 0
    if remaining >= 65536 then
        remaining = remaining // 65536
        result = result + 16
    end
    if remaining >= 256 then
        remaining = remaining // 256
        result = result + 8
    end
    if remaining >= 16 then
        remaining = remaining // 16
        result = result + 4
    end
    if remaining >= 4 then
        remaining = remaining // 4
        result = result + 2
    end
    if remaining >= 2 then
        remaining = remaining // 2
        result = result + 1
    end
    return result + remaining
end
return ____exports
