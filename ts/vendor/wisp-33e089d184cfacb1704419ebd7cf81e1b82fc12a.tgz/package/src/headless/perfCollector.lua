local ____exports = {}
____exports.PERF_COLLECTOR_VARIABLE = "WISP_PERF_COLLECTOR"
return ____exports
