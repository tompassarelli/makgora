local ____lualib = require("lualib_bundle")
local __TS__New = ____lualib.__TS__New
local __TS__ArraySetLength = ____lualib.__TS__ArraySetLength
local ____exports = {}
local ____recordText = require("src.runtime.recordText")
local FAILED = 0
local WROTE = 1
local FIELDS = 2
local LIST = 3
local KEYED = 4
local ROOT = 5
____exports.createFieldCursor = function() return {
    frames = {},
    depth = 0,
    steps = 0,
    keyed = {},
    keyedFrom = nil,
    path = {}
} end
____exports.fieldSlicesOpen = function(cursor) return cursor.depth > 0 end
local function isList(_value, length)
    return length ~= nil
end
local NO_FIELDS = {}
local NO_ITEMS = {}
local function push(cursor, record, items, kind, ____end)
    local ____cursor_0, ____depth_1 = cursor, "depth"
    local ____cursor_depth_2 = ____cursor_0[____depth_1]
    ____cursor_0[____depth_1] = ____cursor_depth_2 + 1
    local at = ____cursor_depth_2
    local frame = cursor.frames[at + 1]
    if frame == nil then
        frame = {
            record = record,
            items = items,
            kind = kind,
            next = 0,
            ["end"] = ____end,
            keys = {},
            name = "",
            value = nil
        }
        cursor.frames[at + 1] = frame
    end
    frame.record = record
    frame.items = items
    frame.kind = kind
    frame.next = 0
    frame["end"] = ____end
    if kind ~= FIELDS and kind ~= KEYED then
        return frame
    end
    local ____frame_3 = frame
    local keys = ____frame_3.keys
    local count = 0
    for key in pairs(record) do
        local ____keys_5 = keys
        local ____count_4 = count
        count = ____count_4 + 1
        ____keys_5[____count_4 + 1] = key
    end
    frame["end"] = count
    return frame
end
local function undeclared(cursor, why)
    local path = table.concat(cursor.path, ".")
    cursor.depth = 0
    do
        local ____thrown = __TS__New(____recordText.IntegerKeysUndeclared, (("record text: " .. path) .. " ") .. why)
        if _G.__wispThrown ~= ____thrown then
            _G.__wispThrown = ____thrown
            _G.__wispThrowSite = "wisp/src/runtime/recordSlices.ts:64"
        end
        error(____thrown, 0)
    end
end
local function open(cursor, name, value)
    if cursor.depth > ____recordText.MAX_DEPTH then
        return FAILED
    end
    local ____cursor_path_6 = cursor.path
    ____cursor_path_6[#____cursor_path_6 + 1] = name
    if cursor.keyed[name] == true then
        if not ____recordText.isKeyed(value) then
            undeclared(cursor, "is declared keyed by integers but has other keys or is an array")
        end
        ____recordText.token(name, "#", "")
        push(
            cursor,
            value,
            NO_ITEMS,
            KEYED,
            0
        )
        return KEYED
    end
    local length = ____recordText.arrayLength(value)
    if length == false then
        undeclared(cursor, "is keyed by integers but not declared so in recordTokens, or mixes integer and named keys")
    end
    local items = value
    if isList(items, length) then
        ____recordText.token(name, "[", "")
        push(
            cursor,
            NO_FIELDS,
            items,
            LIST,
            length or 0
        )
        return LIST
    end
    ____recordText.token(name, "{", "")
    push(
        cursor,
        value,
        NO_ITEMS,
        FIELDS,
        0
    )
    return FIELDS
end
local function enter(cursor, name, value)
    if value == nil then
        return WROTE
    end
    if ____recordText.isFields(value) then
        return open(cursor, name, value)
    end
    local text = ____recordText.valueText(value)
    if text == nil then
        return FAILED
    end
    ____recordText.token(name, "=", text)
    return WROTE
end
local function stepFrame(cursor, frame, budget)
    local ____frame_7 = frame
    local kind = ____frame_7.kind
    local record = ____frame_7.record
    local items = ____frame_7.items
    local keys = ____frame_7.keys
    local ____end = ____frame_7["end"]
    local next = frame.next
    local steps = 0
    local result = WROTE
    while next < ____end and steps < budget and result == WROTE do
        local ____next_8 = next
        next = ____next_8 + 1
        local index = ____next_8
        steps = steps + 1
        if kind == LIST then
            result = enter(
                cursor,
                ____recordText.indexName(index),
                items[index + 1]
            )
        elseif kind == ROOT then
            result = enter(cursor, frame.name, frame.value)
        else
            local key = keys[index + 1] or ""
            if kind == KEYED then
                result = enter(
                    cursor,
                    ____recordText.keyedName(key),
                    record[key]
                )
            else
                result = ____recordText.isFieldName(key) and enter(cursor, key, record[key]) or FAILED
            end
        end
    end
    frame.next = next
    if result == FAILED then
        return -1
    end
    if result ~= WROTE or next < ____end or steps >= budget then
        return steps
    end
    cursor.depth = cursor.depth - 1
    if kind == ROOT then
        return steps + 1
    end
    ____recordText.token("", kind == LIST and "]" or "}", "")
    table.remove(cursor.path)
    return steps + 1
end
local NO_KEYED = {}
function ____exports.beginFieldSlices(cursor, name, value, keyedByInteger)
    if keyedByInteger == nil then
        keyedByInteger = NO_KEYED
    end
    if not ____recordText.isFieldName(name) then
        return false
    end
    cursor.depth = 0
    cursor.steps = 0
    __TS__ArraySetLength(cursor.path, 0)
    if cursor.keyedFrom ~= keyedByInteger then
        local keyed = {}
        for ____, field in ipairs(keyedByInteger) do
            keyed[field] = true
        end
        cursor.keyed = keyed
        cursor.keyedFrom = keyedByInteger
    end
    local frame = push(
        cursor,
        NO_FIELDS,
        NO_ITEMS,
        ROOT,
        1
    )
    frame.name = name
    frame.value = value
    return true
end
function ____exports.writeFieldSlice(cursor, budget)
    ____recordText.writer.count = 0
    local steps = 0
    while cursor.depth > 0 and steps < budget do
        local frame = cursor.frames[cursor.depth]
        local taken = frame == nil and -1 or stepFrame(cursor, frame, budget - steps)
        if taken < 0 then
            cursor.depth = 0
            cursor.steps = steps
            return nil
        end
        steps = steps + taken
    end
    cursor.steps = steps
    return ____recordText.writer.count
end
return ____exports
