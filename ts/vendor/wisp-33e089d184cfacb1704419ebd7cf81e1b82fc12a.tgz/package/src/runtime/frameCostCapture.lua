local ____lualib = require("lualib_bundle")
local __TS__ArrayMap = ____lualib.__TS__ArrayMap
local ____exports = {}
local ____frameCost = require("src.runtime.frameCost")
____exports.MAX_FRAME_COST_CAPTURE = 18000
____exports.frameCostCaptureFile = function(slot, run, prefix)
    if prefix == nil then
        prefix = "wisp"
    end
    return ((((prefix .. "-perf-capture-p") .. tostring(slot)) .. "-run") .. tostring(run)) .. ".txt"
end
____exports.frameCostCaptureHeading = function(run, frames, version, clockStepUs, elapsedMs, changed, sections, stamps) return (((((((((((((("frame capture run=" .. tostring(run)) .. " frames=") .. tostring(frames)) .. " version=") .. tostring(version)) .. " clock-us=") .. ____frameCost.reportNumber(clockStepUs)) .. " elapsed-ms=") .. ____frameCost.reportNumber(elapsedMs)) .. " changed=") .. tostring(changed and 1 or 0)) .. " sections=") .. table.concat(sections, ",")) .. " stamps=") .. table.concat(stamps, ",") end
local function signed(value)
    return value < 0 and "-" .. ____frameCost.reportNumber(-value) or ____frameCost.reportNumber(value)
end
____exports.frameCostCaptureSample = function(frame, luaUs, natives, catchUp, gcKb, sectionsUs, stamps) return (((((((((((("sample " .. tostring(frame)) .. " lua-us=") .. (luaUs == nil and "none" or ____frameCost.reportNumber(luaUs))) .. " natives=") .. tostring(natives)) .. " catchup=") .. tostring(catchUp)) .. " gc-kb=") .. (gcKb == nil and "none" or signed(gcKb))) .. " sections-us=") .. table.concat(
    __TS__ArrayMap(
        sectionsUs,
        function(____, value) return ____frameCost.reportNumber(value) end
    ),
    ","
)) .. " stamps=") .. table.concat(
    __TS__ArrayMap(
        stamps,
        function(____, value) return signed(value) end
    ),
    ","
) end
return ____exports
