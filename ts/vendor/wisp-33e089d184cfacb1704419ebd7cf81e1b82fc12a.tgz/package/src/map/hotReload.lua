local ____lualib = require("lualib_bundle")
local Error = ____lualib.Error
local RangeError = ____lualib.RangeError
local ReferenceError = ____lualib.ReferenceError
local SyntaxError = ____lualib.SyntaxError
local TypeError = ____lualib.TypeError
local URIError = ____lualib.URIError
local __TS__New = ____lualib.__TS__New
local __TS__StringSplit = ____lualib.__TS__StringSplit
local ____exports = {}
local ____gameFiles = require("src.runtime.gameFiles")
local ____config = require("src.runtime.config")
local ____modules = require("src.runtime.modules")
local ____intMath = require("src.sim.intMath")
local ____dispatch = require("src.map.dispatch")
local ____fileio = require("src.map.fileio")
local ____payloadChecksum = require("src.map.payloadChecksum")
local ____modelFailures = require("src.map.modelFailures")
local POLL_SECONDS = 0x1p-5
local IDLE_POLLS = 16
local MAX_SLOTS = 4
local function hot()
    local globals = _G
    local state = globals[____config.runtimeConfiguration().globalPrefix .. "Hot"]
    if state == nil then
        do
            local ____thrown = __TS__New(Error, "hot reload used before startHotReload")
            if _G.__wispThrown ~= ____thrown then
                _G.__wispThrown = ____thrown
                _G.__wispThrowSite = "wisp/src/map/hotReload.ts:67"
            end
            error(____thrown, 0)
        end
    end
    return state
end
local function isReloadable(value)
    return type(value) == "table" and value ~= nil and value.install ~= nil and type(value.install) == "function"
end
local function manifestExists(version)
    return ____fileio.readChunk(____gameFiles.manifestFile(
        version,
        ____config.runtimeConfiguration().filePrefix
    )) ~= nil
end
local function hostSeen()
    return ____fileio.readChunk(____gameFiles.hostFile(____config.runtimeConfiguration().filePrefix)) ~= nil
end
local function latestVersion()
    if not manifestExists(1) then
        return 0
    end
    local low = 1
    while manifestExists(low * 2) do
        low = low * 2
    end
    local high = low * 2
    while high - low > 1 do
        local middle = (low + high) // 2
        if manifestExists(middle) then
            low = middle
        else
            high = middle
        end
    end
    return low
end
local function playingHumans()
    local count = 0
    do
        local slot = 0
        while slot < MAX_SLOTS do
            local player = Player(slot)
            if GetPlayerSlotState(player) == PLAYER_SLOT_STATE_PLAYING and GetPlayerController(player) == MAP_CONTROL_USER then
                count = count + 1
            end
            slot = slot + 1
        end
    end
    return count
end
local function startClock()
    local clock = CreateTimer()
    TimerStart(
        clock,
        86400.0,
        false,
        function()
        end
    )
    return clock
end
local function report(text)
    DisplayTextToPlayer(
        GetLocalPlayer(),
        0,
        0,
        text
    )
end
local function link(modules)
    local values = {}
    local ____require
    ____require = function(name)
        local known = values[name]
        if known ~= nil then
            return known.value
        end
        local module = modules[name]
        if module == nil then
            do
                local ____thrown = ("module '" .. name) .. "' not found"
                if _G.__wispThrown ~= ____thrown then
                    _G.__wispThrown = ____thrown
                    _G.__wispThrowSite = "wisp/src/map/hotReload.ts:116"
                end
                error(____thrown, 0)
            end
        end
        local value = module.chunk(____require)(name)
        values[name] = {value = value}
        return value
    end
    return ____require
end
local function loadLocal(state, manifest)
    local prefix = ____config.runtimeConfiguration().filePrefix
    local installed = state.modules
    local delta = installed ~= nil and manifest.changes > 0 and manifest.base == state.state
    local modules = {}
    local function refuse(reason)
        return {bundle = reason, modules = modules}
    end
    local parts = {}
    do
        local index = 0
        while index < (delta and manifest.changes or manifest.files) do
            parts[#parts + 1] = ____fileio.readChunk(delta and ____gameFiles.deltaFile(manifest.state, manifest.base, index, prefix) or ____gameFiles.payloadFile(manifest.state, index, prefix)) or ""
            index = index + 1
        end
    end
    local payload = ____modules.parsePayload(table.concat(parts, ""))
    if payload == nil or ____payloadChecksum.stringChecksum(payload.index) ~= manifest.state then
        return refuse("payload missing or damaged")
    end
    for ____, ____value in ipairs(payload.hashes) do
        local name = ____value[1]
        local hash = ____value[2]
        do
            local text = payload.texts[name]
            if text == nil then
                local ____delta_0
                if delta then
                    ____delta_0 = installed[name]
                else
                    ____delta_0 = nil
                end
                local kept = ____delta_0
                if kept == nil or kept.hash ~= hash then
                    return refuse(("module " .. name) .. " missing")
                end
                modules[name] = kept
                goto __continue29
            end
            if ____payloadChecksum.stringChecksum(____modules.moduleHashText(name, text)) ~= hash then
                return refuse(("module " .. name) .. " damaged")
            end
            local chunk, ____error = load(
                text,
                "=hot-" .. ____gameFiles.payloadKey(hash)
            )
            if chunk == nil then
                return refuse(____error or ("module " .. name) .. " doesn't load")
            end
            modules[name] = {hash = hash, chunk = chunk}
        end
        ::__continue29::
    end
    local ran, entry = pcall(
        link(modules),
        payload.entry
    )
    if not ran then
        return refuse("failed while loading: " .. tostring(entry))
    end
    return {
        bundle = isReloadable(entry) and entry or "bundle exports no install()",
        modules = modules
    }
end
local function answer(state, manifest)
    if state.next <= manifest.version then
        state.next = manifest.version + 1
    end
    local ____loadLocal_result_1 = loadLocal(state, manifest)
    local bundle = ____loadLocal_result_1.bundle
    local modules = ____loadLocal_result_1.modules
    state.prepared = {version = manifest.version, state = manifest.state, bundle = bundle, modules = modules}
    BlzSendSyncData(
        ____config.runtimeConfiguration().readyPrefix,
        (____gameFiles.formatManifest(manifest) .. " ") .. (type(bundle) == "string" and "refuse" or "ready")
    )
end
local function poll()
    ____modelFailures.pollModelFailures()
    local state = hot()
    if state.prepared ~= nil then
        return
    end
    if state.unseen ~= nil then
        state.unseen = (state.unseen + 1) % (2 * IDLE_POLLS)
        if state.unseen == IDLE_POLLS and hostSeen() then
            state.unseen = nil
        end
        if state.unseen ~= 0 then
            return
        end
    end
    if state.next <= state.decided then
        state.next = state.decided + 1
    end
    local text = ____fileio.readChunk(____gameFiles.manifestFile(
        state.next,
        ____config.runtimeConfiguration().filePrefix
    ))
    if text == nil then
        return
    end
    state.unseen = nil
    local manifest = ____gameFiles.parseManifest(text)
    if manifest == nil or manifest.version ~= state.next then
        state.next = state.next + 1
        return
    end
    answer(state, manifest)
end
local function acknowledge(version, elapsed)
    PreloadGenClear()
    PreloadGenStart()
    Preload(____gameFiles.acknowledgementLine(version, elapsed))
    PreloadGenEnd(____gameFiles.ackFile(
        GetPlayerId(GetLocalPlayer()),
        ____config.runtimeConfiguration().filePrefix
    ))
end
local function decide(state, pending)
    local ____pending_manifest_2 = pending.manifest
    local version = ____pending_manifest_2.version
    local expected = ____pending_manifest_2.state
    state.pending = nil
    state.decided = version
    local prepared = state.prepared
    if prepared ~= nil and prepared.version <= version then
        state.prepared = nil
    end
    local loaded = prepared ~= nil and prepared.version == version and prepared.state == expected and prepared or nil
    local bundle = loaded == nil and "no local copy" or loaded.bundle
    if pending.refused or type(bundle) == "string" or loaded == nil then
        local reason = type(bundle) == "string" and bundle or "another client couldn't load it"
        report((("hot reload " .. tostring(version)) .. " not applied: ") .. reason)
        return
    end
    state.modules = loaded.modules
    state.state = loaded.state
    bundle.install()
    state.applied = version
    if state.clock == nil then
        state.clock = startClock()
    end
    acknowledge(
        version,
        TimerGetElapsed(state.clock)
    )
    report(("hot reload " .. tostring(version)) .. " applied")
end
local function answered()
    local state = hot()
    local text = BlzGetTriggerSyncData()
    local manifest = ____gameFiles.parseManifest(text)
    local verdict = __TS__StringSplit(text, " ")[6]
    if manifest == nil or manifest.version <= state.decided then
        return
    end
    local pending = state.pending
    if pending ~= nil and manifest.version < pending.manifest.version then
        return
    end
    if pending == nil or manifest.version > pending.manifest.version then
        pending = {
            manifest = manifest,
            answered = 0,
            waiting = playingHumans(),
            refused = false
        }
        state.pending = pending
    end
    local ____bit = 1 << GetPlayerId(GetTriggerPlayer())
    if pending.answered & ____bit ~= 0 then
        return
    end
    pending.answered = pending.answered | ____bit
    pending.waiting = pending.waiting - 1
    if verdict ~= "ready" or manifest.state ~= pending.manifest.state then
        pending.refused = true
    end
    if state.prepared == nil or state.prepared.version ~= pending.manifest.version then
        answer(state, pending.manifest)
    end
    if pending.waiting <= 0 and state.pending == pending then
        decide(state, pending)
    end
end
function ____exports.installHotReload()
    ____dispatch.on("hotReload.poll", poll)
    ____dispatch.on("hotReload.answered", answered)
end
function ____exports.startHotReload()
    local configuration = ____config.runtimeConfiguration()
    local globals = _G
    local published = latestVersion()
    local ____temp_3
    if published > 0 or hostSeen() then
        ____temp_3 = nil
    else
        ____temp_3 = 1
    end
    local unseen = ____temp_3
    globals[configuration.globalPrefix .. "Hot"] = {
        applied = 0,
        decided = 0,
        pending = nil,
        next = published + 1,
        prepared = nil,
        unseen = unseen
    }
    ____exports.installHotReload()
    local trigger = CreateTrigger()
    do
        local slot = 0
        while slot < MAX_SLOTS do
            BlzTriggerRegisterPlayerSyncEvent(
                trigger,
                Player(slot),
                configuration.readyPrefix,
                false
            )
            slot = slot + 1
        end
    end
    TriggerAddAction(
        trigger,
        ____dispatch.trampoline("hotReload.answered")
    )
    TimerStart(
        CreateTimer(),
        POLL_SECONDS,
        true,
        ____dispatch.trampoline("hotReload.poll")
    )
    acknowledge(0, 0)
end
return ____exports
