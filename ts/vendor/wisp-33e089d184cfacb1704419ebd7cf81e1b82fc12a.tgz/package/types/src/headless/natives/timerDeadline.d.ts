/** @noSelfInFile */
export declare const after: (at: number, length: number) => number;
