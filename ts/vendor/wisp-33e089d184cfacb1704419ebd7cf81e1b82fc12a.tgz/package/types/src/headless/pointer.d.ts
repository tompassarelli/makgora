/** @noSelfInFile */
import type { HeadlessClient } from "./client";
export declare function point(client: HeadlessClient, x: number, y: number, left: boolean | undefined): void;
