/** @noSelfInFile */
export declare const FRAME_WINDOW = 120;
export interface FrameMeterOptions {
    readonly frame: string;
    readonly simulationFrame?: (this: void) => number;
    readonly toggle: string;
    readonly sections?: readonly string[];
    readonly stamps?: readonly FrameStamp[];
}
export interface FrameStamp {
    readonly name: string;
    readonly read: (this: void) => number;
}
export declare function startFrameCostCapture(frames: number): number;
export declare function installFrameMeter(): void;
export declare function startFrameMeter(options: FrameMeterOptions): void;
