/** @noSelfInFile */
export interface FrameSectionTimes {
    clock: ((this: void) => number) | undefined;
    readonly started: number[];
    readonly totals: number[];
}
export declare function attachFrameSections(times: FrameSectionTimes): void;
export declare function beginFrameSection(section: number): void;
export declare function endFrameSection(section: number): void;
