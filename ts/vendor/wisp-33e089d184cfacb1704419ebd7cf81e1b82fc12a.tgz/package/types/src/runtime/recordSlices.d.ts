/** @noSelfInFile */
type Fields = Readonly<Record<string, unknown>>;
interface Frame {
    record: Fields;
    items: readonly unknown[];
    kind: number;
    next: number;
    end: number;
    readonly keys: string[];
    name: string;
    value: unknown;
}
export interface FieldCursor {
    readonly frames: Frame[];
    depth: number;
    steps: number;
    keyed: Readonly<Record<string, boolean>>;
    keyedFrom: readonly string[] | undefined;
    readonly path: string[];
}
export declare const createFieldCursor: () => FieldCursor;
export declare const fieldSlicesOpen: (cursor: FieldCursor) => boolean;
export declare function beginFieldSlices(cursor: FieldCursor, name: string, value: unknown, keyedByInteger?: readonly string[]): boolean;
export declare function writeFieldSlice(cursor: FieldCursor, budget: number): number | undefined;
export {};
