/** @noSelfInFile */
export declare const MAX_FRAME_COST_CAPTURE = 18000;
export declare const frameCostCaptureFile: (slot: number, run: number, prefix?: string) => string;
export declare const frameCostCaptureHeading: (run: number, frames: number, version: number, clockStepUs: number, elapsedMs: number, changed: boolean, sections: readonly string[], stamps: readonly string[]) => string;
export declare const frameCostCaptureSample: (frame: number, luaUs: number | undefined, natives: number, catchUp: number, gcKb: number | undefined, sectionsUs: readonly number[], stamps: readonly number[]) => string;
