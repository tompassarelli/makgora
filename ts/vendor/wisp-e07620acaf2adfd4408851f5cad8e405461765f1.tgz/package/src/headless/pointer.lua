local ____exports = {}
local ____f32 = require("src.sim.f32")
local UI_WIDTH = 0xcccccdp-24
local UI_HEIGHT = 0x4ccccdp-23
function ____exports.point(client, x, y, left)
    client.mouseScreenX = x
    client.mouseScreenY = y
    if left == true then
        client.heldMouseButtons:add(client.natives.MOUSE_BUTTON_TYPE_LEFT)
    elseif left == false then
        client.heldMouseButtons:delete(client.natives.MOUSE_BUTTON_TYPE_LEFT)
    end
end
____exports.POINTER_LEFT = 1
____exports.POINTER_RIGHT = 2
local POINTER_MIDDLE = 4
--- The cursor on Warcraft's 0.8 by 0.6 UI screen, Y up: the window draws the frames across its whole client area (`ui_area` in the window's draw.rs), so the cursor maps by fractions of the window.
function ____exports.uiPoint(reading)
    return {
        x = UI_WIDTH * reading.x / math.max(1, reading.width),
        y = UI_HEIGHT - UI_HEIGHT * reading.y / math.max(1, reading.height)
    }
end
--- The cursor in the pixels of a client's screen, Y down, which is what `BlzGetMouseScreenPosX`/`Y` return: the inverse of the game's `pointerX`/`pointerY`, which centre a 4:3 area in the screen and scale it by the screen's height, so the point it computes is the one the window drew under the cursor.
function ____exports.screenPoint(reading, screen)
    local ui = ____exports.uiPoint(reading)
    local scale = screen.height / UI_HEIGHT
    return {
        x = math.floor(ui.x * scale + (screen.width - screen.height * 4 / 3) / 2 + 0x1p-1),
        y = math.floor((UI_HEIGHT - ui.y) * scale + 0x1p-1)
    }
end
--- Feeds one player's window mouse to the clients: the cursor and held buttons are that client's local mouse natives, and a left press and release on the same frame that takes clicks is the player's `FRAMEEVENT_CONTROL_CLICK`,
-- which goes through the lockstep like a key so every client runs the handler on the same frame. The frame under the cursor is the topmost one that takes clicks (`Frames.at`).
function ____exports.createPointerFeed(clients, slot)
    local pressedOn
    return function(reading)
        local client = clients:client(slot)
        local natives = client.natives
        local buttons = {{____exports.POINTER_LEFT, natives.MOUSE_BUTTON_TYPE_LEFT}, {____exports.POINTER_RIGHT, natives.MOUSE_BUTTON_TYPE_RIGHT}, {POINTER_MIDDLE, natives.MOUSE_BUTTON_TYPE_MIDDLE}}
        if reading.inside then
            local screen = ____exports.screenPoint(reading, client.screen)
            client.mouseScreenX = screen.x
            client.mouseScreenY = screen.y
        end
        for ____, ____value in ipairs(buttons) do
            local ____bit = ____value[1]
            local button = ____value[2]
            if reading.held & ____bit ~= 0 then
                client.heldMouseButtons:add(button)
            else
                client.heldMouseButtons:delete(button)
            end
        end
        local at = ____exports.uiPoint(reading)
        if reading.pressed & ____exports.POINTER_LEFT ~= 0 then
            pressedOn = client:clickTarget(at.x, at.y)
        end
        if reading.released & ____exports.POINTER_LEFT ~= 0 then
            local target = client:clickTarget(at.x, at.y)
            if target ~= nil and target == pressedOn then
                clients:click(slot, at.x, at.y)
            end
            pressedOn = nil
        end
    end
end
return ____exports
