/** @noSelfInFile */
export interface ChatLine {
    readonly rgb: number;
    readonly name: string;
    readonly text: string;
    readonly born: number;
}
export interface ChatRow {
    readonly text: string;
    readonly born: number;
}
export interface ChatLog {
    readonly lines: ChatLine[];
    readonly capacity: number;
    clock: number;
    revision: number;
}
export declare const createChatLog: (capacity: number) => ChatLog;
export declare const colourCode: (rgb: number) => string;
/** `rgb` moved `percent` of the way to white, so a saturated player colour reads on a dark backdrop. */
export declare const lighten: (rgb: number, percent: number) => number;
/** Battle.net names carry a `#1234` tag that chat never shows. */
export declare function chatName(name: string): string;
export declare function addChatLine(log: ChatLog, rgb: number, name: string, text: string): void;
export declare function advanceChat(log: ChatLog, seconds: number): void;
export declare const chatAge: (log: Readonly<ChatLog>, born: number) => number;
/** A font's advance per glyph class, in units of the font size. */
export interface GlyphWidths {
    readonly space: number;
    /** `i j l` and thin punctuation. */
    readonly narrow: number;
    /** `f r t` and brackets. */
    readonly short: number;
    readonly lower: number;
    /** `m w`. */
    readonly wideLower: number;
    readonly upper: number;
    /** `M W`. */
    readonly wideUpper: number;
    /** Digits, symbols and every byte outside ASCII letters. */
    readonly other: number;
}
/**
 * Warcraft's Friz Quadrata (`Fonts\FRIZQT__.TTF`), fitted to native captures at a 10-pixel font, where glyphs
 * render widest for their size, and rounded up: Warcraft wraps a row that overruns its frame and hides the rest.
 */
export declare const FRIZ_QUADRATA_WIDTHS: GlyphWidths;
export declare function glyphWidth(glyph: string, widths: GlyphWidths): number;
/** The width of `text` in units of the font size. */
export declare function textWidth(text: string, widths: GlyphWidths): number;
/**
 * Splits `text` at spaces into pieces no wider than `first` for the first piece and `width` after it,
 * in units of the font size; a word wider than its row is cut.
 */
export declare function wrapChat(text: string, first: number, width: number, widths: GlyphWidths): string[];
/** One row per wrapped piece: the first holds the coloured name, later ones start at the row's left edge. */
export declare function chatRows(line: ChatLine, width: number, widths: GlyphWidths): ChatRow[];
/** The last `count` rows of the lines younger than `seconds`, oldest first; `seconds` below 0 keeps every line. */
export declare function visibleChatRows(log: Readonly<ChatLog>, count: number, width: number, widths: GlyphWidths, seconds: number): ChatRow[];
/** Full opacity until `fade` seconds before the line expires after `seconds`, then a straight ramp to 0. */
export declare function chatOpacity(age: number, seconds: number, fade: number): number;
