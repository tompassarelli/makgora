/** @noSelfInFile */
import { type GlyphWidths } from "./chatLog";
export interface ChatStyle {
    /** Prefix of the frames' names, unique per panel. */
    readonly name: string;
    readonly font: string;
    readonly fontSize: number;
    readonly rowHeight: number;
    /** The font's glyph advances, which decide where a row wraps. */
    readonly glyphWidths: GlyphWidths;
    /** Space between the text and the backdrop's edge, on every side. */
    readonly margin: number;
    readonly panelTexture: string;
    /** Backdrop opacity, 0 to 255. */
    readonly panelAlpha: number;
    readonly level: number;
    /** Lines kept for the history view. */
    readonly capacity: number;
    /** Rows the history view shows, growing up from the box's bottom edge. */
    readonly historyRows: number;
    /** Seconds a line stays in the recent view, the last `fadeSeconds` of them fading out. */
    readonly recentSeconds: number;
    readonly fadeSeconds: number;
    /** The name colour (0xRRGGBB) of a player slot. */
    readonly colour: (slot: number) => number;
    /** Lines to leave out, such as commands. */
    readonly ignore: (text: string) => boolean;
}
/** Screen coordinates (0.8 wide, 0.6 high, origin bottom left); rows grow upward from `bottom`. */
export interface ChatBox {
    readonly left: number;
    readonly bottom: number;
    readonly width: number;
    /** Rows the recent view shows. */
    readonly rows: number;
}
export declare function registerChatEvents(trigger: trigger, slots: readonly number[]): void;
export declare function registerChatHistoryKey(trigger: trigger, slots: readonly number[], key: oskeytype): void;
export declare class ChatPanel {
    private readonly style;
    private readonly log;
    private readonly backdrop;
    private readonly rowFrames;
    private readonly shownText;
    private readonly shownAlpha;
    private rows;
    private rowsKey;
    private placedKey;
    private shownRows;
    private backdropAlpha;
    private historyOpen;
    constructor(style: ChatStyle);
    /** Adds the line the running chat event carries; call it from the trigger's action. */
    receive(): void;
    /** Opens or closes the scrollback on the machine of the player whose key event is running. */
    toggleHistory(): void;
    /** Draws the panel in `box`, or hides it when `box` is undefined; `seconds` is the time since the last call. */
    update(seconds: number, box: ChatBox | undefined): void;
    private currentRows;
    private place;
    private fill;
    private hide;
}
